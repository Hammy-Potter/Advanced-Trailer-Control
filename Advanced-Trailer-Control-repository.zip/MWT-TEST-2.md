# Advanced Trailer Control — MWT Test 2

Experimental Windows x64 DLL for the supplied ETS2 1.61.1.9 three-section MWT combination: front jeep / tower frame / rear bogie with seven separate axle models.

## Install and test

1. Close ETS2 and back up the working Advanced-Trailer-Control.dll.
2. Replace it in bin/win_x64/plugins with the DLL from this package. Keep only one ATC DLL installed. No EXE, remote add-on, model edits or def edits are required.
3. Enable MWT Mode - Experimental. Leave Reverse bridge correction at the setting used for Test 1.
4. Crawl forwards and turn gently left, straighten, then repeat right. Look specifically at the first part of the turn when the rear swings outward. There is no need to keep turning for 20 seconds.
5. Try Trailer 3 manual control briefly and release. Auto resumes front-derived following.
6. Use Diagnostics > Capture geometry / log details immediately before a manoeuvre. Send game.log.txt and describe how the outward swing and return look; a short clip is helpful.

## Changed from Test 1

Test 1 retained native axle steering only. Test 2 adds movement-based following to each of the seven separate axle models. Direction comes from finite differences of model-derived wheel reference positions in world space, using the rear chassis pose and each axle's native local translation. The axle's own steering yaw is excluded from those reference positions so turning an axle does not itself look like trailer travel.

Each wheel's movement angle is filtered, then added to its freshly calculated native steering correction. This retains the Bridge-style articulation controller's ability to influence the rear module rather than making the axles simply follow whatever direction the rear happens to slide. The new angle can oppose the native correction during the initial outward swing. This is not a fixed reversal of all seven axles.

All seven axle groups consume their own combined wheel targets before native model advance. After that advance, the observed native common model rotation is subtracted from each target to form the wheel-local angle. This avoids applying the model rotation twice. Source steering tables, joint limits and model poses are not rewritten.

The rear-module target and manual release/hold/Auto behaviour remain as in Test 1: opposite front-jeep articulation relative to the tower, ratio 0.6. Module control gain has not been increased in this test. Some target lag can remain.

## Limits and fallback

Movement samples run at 10 Hz. Following is limited to +/-25 degrees, filtered with a 0.35-second time constant and limited to 25 degrees/second. Combined targets are limited to +/-50 degrees, matching this setup's native table endpoints, not BBM's 60-degree setting.

Forward movement only: low speed below approximately 0.3 m/s, reverse movement or implausible movement fades the following component towards zero, leaving the ordinary steering correction. Sector changes, invalid poses, large sampling gaps or clock resets clear movement history. The exact rear profile, seven groups, source mount layout and original output buffer are validated; incompatible geometry does not receive the new wheel override.

Reference positions approximate rigid-body wheel travel. They do not measure tyre contact, slip, independent suspension motion or a real steering sensor. Their usefulness and native transform conventions must be confirmed in game. Feedback steering can still require a small difference between wheel angle and travel direction to change the rear module's articulation.

Capture retains all seven axle-model transforms, jeep/tower poses and a bounded set of [mwt-wheels] diagnostics. Routine logging stays quiet. No in-game handling result is claimed for this DLL before testing.

## Local validation

- Windows x64 Release cross-build passed; expected plugin exports present.
- Replayed all 183 samples of the supplied capture; 158 met the forward-movement conditions. In 13 turn-in samples the first axle's new target opposed its recorded native steering direction. Combined replay targets were approximately -16.3 to +17.7 degrees.
- Replay uses recorded group angles as an approximation to native per-wheel correction. Runtime uses each freshly computed wheel row instead. Replay does not simulate the changed vehicle physics.
- Actual pre/post writer tests cover seven model groups, combined angle accounting, output buffer and geometry guards, one-use post stage and movement history retained while other trailers advance.
- Existing MWT/bridge routing, BBM profiles, actual hook ordering, captures, movement maths, snapshot and quiet logging tests passed.

The included MWT-TEST-1.md is historical documentation of the first test; this file describes the current build.
