# Advanced Trailer Control — MWT Test 1

Experimental addition to the 1.0.0 baseline, targeting the supplied ETS2 1.61.1.9 executable.

Select **MWT Mode - Experimental** for the supplied three-section setup:
1. Front jeep (Trailer 1)
2. Tower frame (Trailer 2)
3. Seven-axle-model rear bogie (Trailer 3)

The rear-module articulation target is -0.6 times the front jeep's articulation relative to the tower. The feedback controller uses the existing Bridge Mode bounded steering-demand method (0.5 degree deadband, demand limited to +/-0.25), preserving native individual axle calculations. It does not force all seven axle models to the same angle, apply BBM's 60-degree correction, or rewrite joint limits/model poses/steering tables.

Trailer 3 manual control overrides rear following. Its manual direction is reversed in this mode, as for the bridge rear module. Releasing manual input captures the current rear articulation; the controller then tries to maintain that angle using native axle steering. Trailer 3 Auto clears the hold and resumes the front-derived target. This is feedback steering, not a rigid articulation lock.

Only the captured rear steering-table fingerprint, seven native groups, identity wheel mapping and three-section chain are accepted. Unsupported executable metadata, invalid poses or articulation beyond 75 degrees decline automatic MWT control. An unmatched setup retains the ordinary steering path; it is not converted into a different profile. Other selectable modes remain available and selecting one disables MWT Mode. All modes remain off on launch.

## First test

Back up the working DLL. Close ETS2 and replace Advanced-Trailer-Control.dll in bin/win_x64/plugins with the test DLL. Keep only one ATC DLL installed. No remote add-on, EXE, model changes or def edits are needed for this test.

Load the same MWT combination and enable MWT Mode - Experimental. Leave Reverse bridge correction unchecked initially. Use Trailer 3 Auto to clear an old manual hold. Crawl forwards through a gentle left turn, straighten, then repeat right. Observe both the rear module's alignment and each axle's wheel direction. Then manually steer Trailer 3 briefly, release, and try Auto again. Stop and disable MWT Mode if it pushes the rear module away from the intended direction. The existing Reverse bridge correction switch can be tested while stopped if feedback polarity is wrong.

Use Diagnostics > Capture geometry / log details just before a short forward turn. A capture records 20 seconds; there is no need to keep turning for the entire duration. Turn briefly and then straighten. Capture a second run in the opposite direction and send game.log.txt with a short clip if possible.

## What this test establishes

This version tests whether the seven axles' native steering geometry, driven by Bridge-style rear-module control, gives the requested realistic trailing. It does not introduce a new measured-movement wheel-path controller for the seven separate axle groups. If native wheel tracking is inadequate, the expanded trace is intended to identify the next correction; realistic tracking has not been established by the local code tests.

The capture now retains all seven rear axle-model transforms and the front jeep/tower chassis poses. It remains read-only, opt-in and limited to a 20-second window. Normal correction logging remains quiet. Logged axle transforms are native driven transforms, not independent tyre contact or physical slip measurements.

## Local validation

Windows x64 Release DLL cross-build. Native C++ regression tests cover MWT target routing and fingerprint rejection, left/right symmetry, relative tower frame, manual release/hold/Auto, unchanged native axle arrays, existing bridge modes, BBM profiles, capture bounds and seven-group reads, hook pipeline, movement-path maths, geometry snapshot guards and quiet logging.

No ETS2 session was available locally; in-game handling, feedback polarity, seven-axle tracking and suitability of the 0.6 ratio need the driving test above. Reverse driving and high-speed operation are not validated.
