# Advanced Trailer Control v1.0.2

This release targets ETS2 1.62.1.0 Windows x64 / DirectX 11 and supersedes older build-target notes in this source archive.

Advanced Trailer Control v1.0.2
Target: ETS2 1.62.1.0 | Windows x64 | DirectX 11

Close the game. Copy Advanced-Trailer-Control.dll to:
Euro Truck Simulator 2/bin/win_x64/plugins/
Create the plugins folder if needed. Keep your existing JSON settings.
Press Insert to open the panel and Home to toggle the cursor.

Updated for the 1.62 trailer layout and bridge/MWT function addresses.
Retains the v1.0.1 ST7 tracking fix. Confirmed working in-game.
For ETS2 1.61.1.9, use v1.0.1 instead.

The remote add-on is optional and is not required for local controls.
See the GitHub README and included disclaimer.

Build with CMake and a Windows C++17 toolchain. Set MINHOOK_SOURCE_DIR to the absolute path of vendor/minhook. Portable tests are in tests/. The offline binary check accepts the new and old EXEs as arguments; game executables are not distributed.
