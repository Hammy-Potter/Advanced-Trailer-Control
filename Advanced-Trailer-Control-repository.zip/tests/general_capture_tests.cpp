#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdarg>
#include <cassert>
#include "../main/Advanced-Trailer-Control/end_centre_math.h"
#include "../main/Advanced-Trailer-Control/geometry_snapshot.h"
using SIZE_T=size_t;using ULONGLONG=uint64_t;
struct IMAGE_DOS_HEADER{int e_magic=0,e_lfanew=0;};
struct IMAGE_NT_HEADERS64{int Signature=0;struct {uint32_t TimeDateStamp=0;} FileHeader;struct {uint32_t SizeOfImage=0;}OptionalHeader;};
struct MEMORY_BASIC_INFORMATION{int State=0,Protect=0;};
constexpr int IMAGE_DOS_SIGNATURE=1,IMAGE_NT_SIGNATURE=2,MEM_COMMIT=1,PAGE_GUARD=2,PAGE_NOACCESS=4,PAGE_EXECUTE=8,PAGE_EXECUTE_READ=16,PAGE_EXECUTE_READWRITE=32,PAGE_EXECUTE_WRITECOPY=64;
namespace prism{struct game_trailer_actor_u{char fields[0x800]{};float steering=0;};}
std::vector<std::pair<uintptr_t,size_t>> regions;
void region(void*p,size_t n){regions.push_back({uintptr_t(p),n});}
bool ReadProcessMemory(void*,const void*src,void*dst,size_t n,SIZE_T*got){auto a=uintptr_t(src);for(auto r:regions)if(a>=r.first&&n<=r.second&&a-r.first<=r.second-n){memcpy(dst,src,n);*got=n;return true;}*got=0;return false;}
char exe[4096]{};void*GetModuleHandleW(void*){return exe;}void*GetCurrentProcess(){return nullptr;}
int VirtualQuery(void*,MEMORY_BASIC_INFORMATION*,size_t){return 0;}
uint64_t now_tick=2000;uint64_t GetTickCount64(){return now_tick;}
std::string logs;void scs_log(int,const char*f,...){char b[2048];va_list a;va_start(a,f);vsnprintf(b,sizeof(b),f,a);va_end(a);logs+=b;logs+='\n';}
bool isTrailerLocked(prism::game_trailer_actor_u*){return false;}bool isTrailerTempLocked(prism::game_trailer_actor_u*){return false;}
struct EndModule{end_centre::Module geometry;};bool end_centre_load(prism::game_trailer_actor_u*,EndModule&,std::string&why){why="fixture intentionally not fitted";return false;}
int multi_module_leader=0;
#include "../main/Advanced-Trailer-Control/geometry_diagnostic.inc"
template<class T>void put(char*p,size_t off,T x){memcpy(p+off,&x,sizeof x);}
int main(){
 region(exe,sizeof exe);IMAGE_DOS_HEADER dos{1,128};put(exe,0,dos);IMAGE_NT_HEADERS64 nt{};nt.Signature=2;nt.FileHeader.TimeDateStamp=0x6ACDF049;nt.OptionalHeader.SizeOfImage=0x398B000;put(exe,128,nt);
 prism::game_trailer_actor_u a{},b{};region(&a,sizeof a);region(&b,sizeof b);b.steering=.25f;
 char data[0x200]{};region(data,sizeof data);put(b.fields,0x6c0,uintptr_t(data));put(data,0x28,8);put(data,0x168,8.f);
 std::vector<float> table(34),outputs{.1f,-.2f};std::vector<uint64_t> mapping{0,1,0,1};for(size_t i=0;i<table.size();++i)table[i]=float(i);
 region(table.data(),table.size()*4);region(outputs.data(),outputs.size()*4);region(mapping.data(),mapping.size()*8);
 put(data,0,atc_geometry::Array{0,uintptr_t(table.data()),34,34});put(data,0x30,atc_geometry::Array{0,uintptr_t(outputs.data()),2,2});put(data,0xa0,atc_geometry::Array{0,uintptr_t(mapping.data()),4,4});

 // Native-driven bogie transform, mapped object and common-angle read fixture.
 std::vector<float> common{.5f};std::vector<int32_t> indices{0};char bogie[0x80]{};
 std::vector<uintptr_t> objects{uintptr_t(bogie)};
 region(common.data(),4);region(indices.data(),4);region(objects.data(),8);region(bogie,sizeof bogie);
 put(b.fields,0x3d8,atc_geometry::Array{0,uintptr_t(common.data()),1,1});
 put(b.fields,0x430,atc_geometry::Array{0,uintptr_t(indices.data()),1,1});
 put(b.fields,0x40,atc_geometry::Array{0,uintptr_t(objects.data()),1,1});
 atc_geometry::Pose driven{1,2,3,0,0,{float(std::cos(.25)),0,float(std::sin(.25)),0}};
 put(bogie,0x30,driven);
 assert(std::abs(geometry_yaw(driven)-.5)<.000001);
 geometry_bogies(uintptr_t(&b),2,&driven);
 assert(logs.find("common-valid=1 common-deg=28.6478898")!=std::string::npos);
 assert(logs.find("driven-pose-valid=1")!=std::string::npos);
 assert(logs.find("bogie-local-yaw-deg=28.647")!=std::string::npos);
 logs.clear();indices[0]=99;geometry_bogies(uintptr_t(&b),2,nullptr);
 assert(logs.find("driven-pose-valid=0")!=std::string::npos);logs.clear();indices[0]=0;
 driven.q[0]=0;driven.q[2]=0;put(bogie,0x30,driven);
 geometry_bogies(uintptr_t(&b),2,nullptr);assert(logs.find("driven-pose-valid=0")!=std::string::npos);logs.clear();
 driven.q[0]=1;put(bogie,0x30,driven);
 std::vector<prism::game_trailer_actor_u*> chain{&a,&b};geometry_capture_requested=true;geometry_diagnostic_tick(chain);
 assert(logs.find("BEGIN capture=1 chain=2")!=std::string::npos);assert(logs.find("T1 steering-data-present=0")!=std::string::npos);assert(logs.find("T2 steering-data-present=1 demand=0.2500000")!=std::string::npos);assert(logs.find("row[1] native-degrees")!=std::string::npos);assert(logs.find("wheel[3] row=1 angle-valid=1")!=std::string::npos);assert(logs.find("END capture=1")!=std::string::npos);assert(!geometry_capture_requested);
 now_tick+=1100;geometry_capture_requested=true;geometry_diagnostic_tick(chain);assert(geometry_capture_number==2);assert(geometry_capture_status.find("Capture 2:")==0);
 assert(geometry_trace.until>0);
 now_tick+=21000;geometry_trace_tick(chain,now_tick);assert(geometry_trace.until==0);assert(logs.find("[bogie-motion] END")!=std::string::npos);
 geometry_trace_start(chain,now_tick);geometry_trace_tick({},now_tick+100);assert(geometry_trace.until==0);

 // MWT trace reads all seven separate axle-model transforms. BBM's singular
 // helper still refuses this shape, so its existing controller cannot claim it.
 std::vector<float> seven_angles(7,.1f);std::vector<int32_t> seven_indices{0,1,2,3,4,5,6};
 char seven_bogies[7][0x80]{};std::vector<uintptr_t> seven_objects;
 for(size_t i=0;i<7;++i){region(seven_bogies[i],0x80);seven_objects.push_back(uintptr_t(seven_bogies[i]));driven.z=float(i);put(seven_bogies[i],0x30,driven);}
 region(seven_angles.data(),28);region(seven_indices.data(),28);region(seven_objects.data(),56);
 put(b.fields,0x3d8,atc_geometry::Array{0,uintptr_t(seven_angles.data()),7,7});
 put(b.fields,0x430,atc_geometry::Array{0,uintptr_t(seven_indices.data()),7,7});
 put(b.fields,0x40,atc_geometry::Array{0,uintptr_t(seven_objects.data()),7,7});
 std::vector<atc_geometry::Pose> local_poses;std::vector<float> group_angles;
 assert(geometry_trace_locals(uintptr_t(&b),local_poses,group_angles)&&local_poses.size()==7&&local_poses[6].z==6);
 float singular_angle=0;assert(!geometry_trace_local(uintptr_t(&b),driven,singular_angle));
 seven_indices[6]=7;assert(!geometry_trace_locals(uintptr_t(&b),local_poses,group_angles));seven_indices[6]=6;
 seven_angles[6]=NAN;assert(!geometry_trace_locals(uintptr_t(&b),local_poses,group_angles));seven_angles[6]=.1f;
 geometry_trace_start(chain,now_tick);assert(geometry_trace.multiple_groups);geometry_trace_tick(chain,now_tick);assert(geometry_trace.next==now_tick+250);geometry_trace_stop("test complete");
 put(exe,0,IMAGE_DOS_HEADER{});geometry_trace_start(chain,now_tick);assert(geometry_trace.until==0);geometry_dump(chain);assert(geometry_capture_status.find("skipped")!=std::string::npos);assert(logs.find("END capture=3: unsupported")!=std::string::npos);
 puts("PASS: independent two-trailer capture, no steering data, raw table/mapping/output, numbered repeated capture, unsupported EXE refusal, seven independent group reads and singular BBM refusal");
}
