"""Offline checks against the supplied EXEs; does not execute either game.
Usage: python tests/verify_162_binary.py NEW_EXE OLD_EXE
"""
import pathlib, re, struct, sys, hashlib
class PE:
 def __init__(self,path):
  self.b=pathlib.Path(path).read_bytes(); n=struct.unpack_from('<I',self.b,60)[0]; opt=n+24
  self.timestamp=struct.unpack_from('<I',self.b,n+8)[0];self.size=struct.unpack_from('<I',self.b,opt+56)[0];self.base=struct.unpack_from('<Q',self.b,opt+24)[0]
  start=opt+struct.unpack_from('<H',self.b,n+20)[0]
  self.sections=[struct.unpack_from('<IIII',self.b,start+i*40+8) for i in range(struct.unpack_from('<H',self.b,n+6)[0])]
 def data(self,rva,n):
  for vs,va,sz,raw in self.sections:
   if va<=rva and rva+n<=va+sz:return self.b[raw+rva-va:raw+rva-va+n]
  raise ValueError(hex(rva))
 def guard(self,rva):
  b=self.data(rva,0x85)
  return (self.timestamp,self.size)==(0x6aeb1934,0x39f8000) and b[0x3e:0x45]==bytes.fromhex('48 8b 81 c0 06 00 00') and b[0x57:0x5e]==bytes.fromhex('48 8b 89 50 10 00 00') and b[0x6e:0x75]==bytes.fromhex('48 8b 89 b0 0f 00 00')
new,old=map(PE,sys.argv[1:3]);assert new.guard(0x779f20);assert not old.guard(0x78ee10)
root=pathlib.Path(__file__).resolve().parents[1]/'main/Advanced-Trailer-Control'
text=(root/'dllmain.cpp').read_text(encoding='utf-8-sig')
for pat in re.findall(r'patternScan\("([^"]+)"',text):
 rx=b''.join(b'.' if x=='??' else re.escape(bytes.fromhex(x)) for x in pat.split())
 assert len(list(re.finditer(rx,new.b,re.S)))==1,pat
assert new.data(0x166f5d0,64)==old.data(0x163e4b0,64)
# Native chain traversal reads next at +0x1058, corresponding to old +0x1088.
assert new.data(0x4e4340,7)==bytes.fromhex('48 8b 88 58 10 00 00')
slots=[6,7,8,9,29,30,40,41,42,43,44,45]
expected=[0x1b4a650,0x1b49f00,0x1b4a220,0x1b499e0,0x1b4c340,0x1b4c330,0x1b4c5d0,0x1b4c590,0x1b4c780,0x1b4c740,0x1b4c890,0x1b4c840]
for slot,rva in zip(slots,expected):assert struct.unpack('<Q',new.data(0x255dea0+slot*8,8))[0]==new.base+rva
joint=(root/'reverse_joint.inc').read_text().lower();assert '0xfe0' not in joint and 'actor+0xfb0' in joint
for rva in expected:assert hex(rva) in joint
print('PASS: four unique signatures; 1.62 accepted and 1.61 rejected; joint/predecessor/next fields; pose getter; all 12 D6 vtable entries; source joint mappings')
print('New EXE SHA256:',hashlib.sha256(new.b).hexdigest())
