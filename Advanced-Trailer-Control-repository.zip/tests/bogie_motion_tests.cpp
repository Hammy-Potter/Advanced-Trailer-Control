#include "../main/Advanced-Trailer-Control/bogie_motion.h"
#include <cassert>
#include <cstdio>
atc_geometry::Pose pose(double x,double z,double yaw){return {float(x),0,float(z),0,0,{float(std::cos(yaw/2)),0,float(std::sin(yaw/2)),0}};}
int main(){
 bogie_motion::State s{};auto local=pose(0,0,0),actor=pose(0,0,0);
 assert(!bogie_motion::sample(s,actor,local,1000).valid);
 actor.x=.2f;auto m=bogie_motion::sample(s,actor,local,1100);assert(m.valid&&m.path&&std::abs(m.speed-2)<1e-6&&m.curvature==0);
 m=bogie_motion::sample(s,actor,local,1200);assert(m.valid&&!m.path);
 actor.sector_x=1;assert(!bogie_motion::sample(s,actor,local,1300).valid);
 assert(!bogie_motion::sample(s,actor,local,2000).valid);
 actor.x=100;assert(!bogie_motion::sample(s,actor,local,2100).valid);
 // Constant-radius arc: 10m radius, 0.1rad/s, ~1m/s => 0.1/m curvature.
 for(double sign:{-1.,1.}){
  s={};
  for(int i=0;i<20;++i){const double a=sign*.01*i;actor=pose(10*std::cos(a),10*std::sin(a),a);
   m=bogie_motion::sample(s,actor,local,1000+100*i);
   if(i)assert(m.valid&&m.path&&std::abs(m.curvature-sign*.1)<.0001);
  }
 }
 // Rotation of an offset pivot changes its position even if actor origin stays put.
 s={};local=pose(0,2,0);actor=pose(0,0,0);bogie_motion::sample(s,actor,local,1000);
 actor=pose(0,0,.01);m=bogie_motion::sample(s,actor,local,1100);assert(m.valid&&std::abs(m.speed-.2)<.00001);
 // Heading wrap and quaternion sign both preserve small angular change.
 s={};local=pose(0,0,0);actor=pose(0,0,3.14);bogie_motion::sample(s,actor,local,1000);
 actor=pose(.2,0,-3.14);for(float& q:actor.q)q=-q;m=bogie_motion::sample(s,actor,local,1100);assert(m.valid&&std::abs(m.yaw_rate)<.04);
 actor.q[0]=100;assert(!bogie_motion::sample(s,actor,local,1200).valid&&!s.ready);
 puts("PASS: composed pivot motion, constant-radius mirrored arcs, slow-speed gating, sector/time/jump reset, heading wrap, invalid quaternion");
}
