#include <vector>
#include <string>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <algorithm>
#include "../main/Advanced-Trailer-Control/geometry_snapshot.h"
using SIZE_T=size_t;
namespace prism {struct game_trailer_actor_u {char pad[0x30]{};void* object=nullptr;float steering=0;};}
struct Physics {uintptr_t* vt;atc_geometry::Pose pose;};
void getter(void*o,void*out){std::memcpy(out,&((Physics*)o)->pose,sizeof(atc_geometry::Pose));}
void* GetModuleHandleW(void*){return (void*)((uintptr_t)getter-0x166f5d0);}
bool ReadProcessMemory(void*,const void*src,void*dst,size_t n,SIZE_T*got){std::memcpy(dst,src,n);*got=n;return true;}
void* GetCurrentProcess(){return nullptr;}
uint64_t clock_tick=1000;
uint64_t GetTickCount64(){return clock_tick;}
void scs_log(int,const char*,...){}
bool multi_module_mode=false,locked=false,temp=false;
std::vector<prism::game_trailer_actor_u*> chain;
auto get_trailer_chain(){return chain;}
prism::game_trailer_actor_u* locked_actor=nullptr;
bool isTrailerLocked(prism::game_trailer_actor_u* a){return locked||a==locked_actor;}
bool isTrailerTempLocked(prism::game_trailer_actor_u*){return temp;}
bool geometry_exe(){return true;}
#include "joint_mock.inc"
#include "../main/Advanced-Trailer-Control/bridge_mode.inc"
int main(){
 uintptr_t vt[40]{};vt[0x130/8]=(uintptr_t)getter;
 Physics phys[4]{};prism::game_trailer_actor_u actors[4];
 for(int i=0;i<4;++i){phys[i].vt=vt;phys[i].pose.q[0]=1;actors[i].object=&phys[i];chain.push_back(&actors[i]);}
 float target=99;
 auto warm=[&](){for(int i=0;i<80;++i){clock_tick+=100;phys[3].pose.z-=.1f;assert(bridge_target(&actors[3],target));}};
 assert(bridge_manual_sign(&actors[3])==1);
 assert(!bridge_target(&actors[3],target));bridge_mode=true;
 assert(bridge_manual_sign(&actors[3])==-1);assert(bridge_manual_sign(&actors[2])==1);
 assert(!bridge_target(&actors[2],target));assert(bridge_target(&actors[3],target)&&target==0);
 warm();
 phys[1].pose.q[0]=float(cos(15/57.295779513));phys[1].pose.q[2]=float(sin(15/57.295779513));
 assert(bridge_target(&actors[3],target)&&target<0&&target>=-.25f);
 locked=true;assert(!bridge_target(&actors[3],target));locked=false;
 temp=true;assert(!bridge_target(&actors[3],target));temp=false;
 multi_module_mode=true;assert(!bridge_target(&actors[3],target));multi_module_mode=false;
 phys[3].pose.q[0]=0;assert(!bridge_target(&actors[3],target));phys[3].pose.q[0]=1;
 warm(); // Reverse travel is covered by bridge_reverse_runtime_tests, not an obsolete UI flag.
 multi_module_mode=true;assert(bridge_manual_sign(&actors[3])==1);multi_module_mode=false;
 float expert=0;assert(bridge_target(&actors[3],expert));
 bridge_mode=false;bridge_basic_mode=true;
 assert(bridge_basic_follower(3));assert(!bridge_basic_follower(2));
 locked_actor=&actors[2]; // Manual bridge must not disable rear tracking.
 warm();float basic=0;assert(bridge_target(&actors[3],basic));assert(basic==expert);
 assert(bridge_manual_sign(&actors[2])==1);assert(bridge_manual_sign(&actors[3])==1);
 assert(!bridge_target(&actors[2],basic));
 multi_module_mode=true;assert(!bridge_basic_follower(3));assert(!bridge_target(&actors[3],basic));multi_module_mode=false;
 locked_actor=nullptr;bridge_basic_mode=false;assert(!bridge_target(&actors[3],basic));
 bridge_mode=true;
 // Expert: release captures articulation, not wheel input; Auto releases hold.
 bridge_mode=true;bridge_basic_mode=false;bridge_sync();warm();
 bridge_manual_input(&actors[3],-.5f);assert(bridge_target(&actors[3],target)&&target==-.5f);
 phys[3].pose.q[0]=float(cos(10/2./57.295779513));phys[3].pose.q[2]=float(sin(10/2./57.295779513));
 clock_tick+=121;assert(bridge_target(&actors[3],target)&&std::abs(target)<.00001);assert(bridge_hold.held);
 const double captured=bridge_hold.angle;assert(std::abs(captured-10)<.001);
 phys[1].pose.q[0]=1;phys[1].pose.q[2]=0; // Front movement does not replace selected rear angle.
 assert(bridge_target(&actors[3],target)&&std::abs(target)<.00001);
 phys[3].pose.q[0]=float(cos(12/2./57.295779513));phys[3].pose.q[2]=float(sin(12/2./57.295779513));
 assert(bridge_target(&actors[3],target)&&target<0&&target>=-.25f);
 bridge_auto_input(&actors[3]);assert(!bridge_hold.held);assert(bridge_target(&actors[3],target)&&target<0);
 // Basic shares bridge manual input, but rear release holds articulation.
 bridge_mode=false;bridge_basic_mode=true;bridge_sync();assert(!bridge_hold.held);
 bridge_manual_input(&actors[2],.4f);assert(bridge_target(&actors[3],target)&&target==-.4f);
 clock_tick+=121;assert(bridge_target(&actors[3],target)&&std::abs(target)<.00001&&bridge_hold.held);
 bridge_auto_input(&actors[2]);assert(!bridge_hold.held);
 bridge_manual_input(&actors[2],.3f);multi_module_mode=true;bridge_sync();assert(!bridge_hold.driven&&!bridge_hold.held);multi_module_mode=false;
 bridge_basic_mode=false;bridge_mode=true;
 bridge_status="stale angles"; chain.pop_back();bridge_sync();assert(bridge_status.find("Unavailable:")==0);bridge_basic_mode=true;assert(!bridge_basic_follower(3));bridge_basic_mode=false;assert(bridge_manual_sign(&actors[3])==1);assert(!bridge_target(&actors[3],target));
 puts("PASS: actual bridge controller routing, manual/temporary override, conflicting mode, invalid pose, chain identity, polarity, bounded demand and both modes manual-release articulation hold / Auto / reset (mock pose getter)");
}
