#include "../main/Advanced-Trailer-Control/bbm_path.h"
#include "../main/Advanced-Trailer-Control/bbm_profiles.h"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <sstream>
atc_geometry::Pose pose(float x,float z,double yaw=0){return {x,0,z,0,0,{float(cos(yaw/2)),0,float(sin(yaw/2)),0}};}
int main(int argc,char**argv){
 const auto& points=bbm::profiles[2].points;
 bbm_path::State s{};wheel_path::State old{};
 double legacy_max=0;
 // Straight chassis path with rapidly changing native bogie animation must
 // not manufacture differential steering or a common lateral correction.
 for(int i=0;i<100;++i){auto a=pose(0,-float(i)*.4f),b=pose(0,3.0783,sin(i*.2)*.6);
  bbm_path::sample(s,a,b,1000+i*100,points,14);wheel_path::sample(old,a,b,1000+i*100,points,14);
  for(auto v:s.offsets)assert(std::abs(v)<1e-6);
  for(auto v:old.offsets)legacy_max=std::max(legacy_max,std::abs(v));
 }assert(legacy_max>10*wheel_path::rad);
 // Mirrored chassis turns must produce mirrored axle differences. Front and
 // rear rows turn oppositely relative to the retained common bogie command.
 bbm_path::State left{},right{};
 for(int i=0;i<80;++i){double t=i*.01;auto a=pose(float(20*(cos(t)-1)),float(-20*sin(t)),t),b=pose(0,3.0783,.2);
  auto ar=pose(-a.x,a.z,-t),br=pose(0,3.0783,-.2);
  bbm_path::sample(left,a,b,1000+i*100,points,14);bbm_path::sample(right,ar,br,1000+i*100,points,14);
 }
 assert(left.offsets[0]*left.offsets[12]<0);
 for(size_t i=0;i<14;i+=2)assert(std::abs(left.offsets[i]+right.offsets[i+1])<1e-5);
 const auto held=left.offsets;
 auto a=pose(0,0),b=pose(0,3.0783);left={};bbm_path::sample(left,a,b,1000,points,14);
 a.z=.2;assert(!bbm_path::sample(left,a,b,1100,points,14).valid);
 a.sector_x=1;assert(!bbm_path::sample(left,a,b,1200,points,14).valid);for(auto v:left.offsets)assert(v==0);
 if(argc>1){std::ifstream f(argv[1]);assert(f);std::string line;bbm_path::State fixed{};wheel_path::State legacy{};double maxold=0,maxnew=0;int count=0,oldcap=0,newcap=0;
  while(std::getline(f,line)){std::replace(line.begin(),line.end(),',',' ');std::istringstream in(line);int capture;uint64_t tick;atc_geometry::Pose ap{},bp{};
   in>>capture>>tick>>ap.x>>ap.y>>ap.z>>ap.sector_x>>ap.sector_z;for(auto&q:ap.q)in>>q;
   in>>bp.x>>bp.y>>bp.z>>bp.sector_x>>bp.sector_z;for(auto&q:bp.q)in>>q;assert(in);
   wheel_path::sample(legacy,ap,bp,1000+tick,points,14);bbm_path::sample(fixed,ap,bp,1000+tick,points,14);++count;
   for(int i=0;i<14;++i){maxold=std::max(maxold,std::abs(legacy.offsets[i]));maxnew=std::max(maxnew,std::abs(fixed.offsets[i]));oldcap+=std::abs(legacy.offsets[i])>24*wheel_path::rad;newcap+=std::abs(fixed.offsets[i])>24*wheel_path::rad;assert(std::isfinite(fixed.offsets[i]));}
  }
  printf("Report replay: samples=%d old-max=%.3f new-max=%.3f deg; rows near limit old=%d new=%d\n",count,maxold/wheel_path::rad,maxnew/wheel_path::rad,oldcap,newcap);assert(count>100&&oldcap>0&&newcap<oldcap&&maxnew<maxold);
 }
 puts("PASS: commanded yaw cannot create crab correction; mirrored turning paths; forward/reverse and history guards; report replay");
}
