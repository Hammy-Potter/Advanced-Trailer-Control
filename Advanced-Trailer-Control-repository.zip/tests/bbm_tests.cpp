#define main legacy_fixture_main
#include "axle_correction_tests.cpp"
#undef main
struct Fixture {
 char data[512]{},object[128]{};
 prism::game_trailer_actor_u actor{};
 std::vector<float> table,out,common{0};std::vector<uint64_t> map;
 std::vector<int32_t> index{0};std::vector<uintptr_t> objects;
 const bbm::Profile& profile;
 Fixture(const bbm::Profile& p):table(p.rows*121),out(p.rows),map(p.rows),objects{uintptr_t(object)},profile(p){
  actor.steering_data=reinterpret_cast<prism::steering_data_t*>(data);
  for(size_t r=0;r<p.rows;++r){map[r]=r;table[r*121]=float(p.negative[r]);table[r*121+120]=float(p.positive[r]);}
  for(auto r:std::vector<std::pair<void*,size_t>>{{data,sizeof data},{object,sizeof object},{&actor,sizeof actor},{table.data(),table.size()*4},{out.data(),out.size()*4},{map.data(),map.size()*8},{common.data(),4},{index.data(),4},{objects.data(),8}})regions.push_back({uintptr_t(r.first),r.second});
  put(data,0,atc_geometry::Array{0,uintptr_t(table.data()),table.size(),table.size()});
  put(data,0x30,atc_geometry::Array{0,uintptr_t(out.data()),p.rows,p.rows});
  put(data,0xa0,atc_geometry::Array{0,uintptr_t(map.data()),p.rows,p.rows});
  put(data,0x28,60);put(data,0x168,float(p.lever));
  char* a=reinterpret_cast<char*>(&actor);
  put(a,0x3d8,atc_geometry::Array{0,uintptr_t(common.data()),1,1});put(a,0x430,atc_geometry::Array{0,uintptr_t(index.data()),1,1});put(a,0x40,atc_geometry::Array{0,uintptr_t(objects.data()),1,1});
  put(object,0x30,atc_geometry::Pose{0,0,0,0,0,{1,0,0,0}});
 }
};
int main(){
 front_axle_test_enabled=true;axle_correction_enabled=false;regions.clear();
 prism::game_trailer_actor_u drawbar{};
 Fixture three(bbm::profiles[0]),four(bbm::profiles[1]),seven(bbm::profiles[2]);
 for(Fixture* f:{&three,&four,&seven}){
  chain=f==&three?std::vector<prism::game_trailer_actor_u*>{&f->actor}:std::vector<prism::game_trailer_actor_u*>{&drawbar,&f->actor};
  for(float input:{-1.f,-.5f,0.f,.5f,1.f}){assert(axle_correction_apply(&f->actor,input));for(float v:f->out)assert(std::abs(v+input*60*end_centre::rad)<1e-6);}
  fake_tick+=1000;mock_chassis={0,0,0,0,0,{1,0,0,0}};
  std::fill(f->out.begin(),f->out.end(),-.4f);assert(axle_correction_apply(&f->actor,0,true));
  for(float v:f->out)assert(v==-.4f);
  fake_tick+=110;mock_chassis.x=.02f;mock_chassis.z=-.2f;
  assert(axle_correction_apply(&f->actor,0,true));
  for(size_t i=0;i<f->profile.rows;++i)if(f->profile.rows==14)assert(std::abs(f->out[i]+.4f)<1e-6);else if(i<f->profile.active)assert(f->out[i]<-.401f);else assert(f->out[i]==-.4f);
  auto saved=f->out;f->map[0]=99;assert(!axle_correction_apply(&f->actor,0));assert(saved==f->out);f->map[0]=0;
  f->table[0]+=1;assert(!axle_correction_apply(&f->actor,0));assert(saved==f->out);f->table[0]-=1;
  bridge_mode=true;assert(!axle_correction_apply(&f->actor,0));bridge_mode=false;
 }
 // Alternating supported actors must retain independent history.
 chain={&three.actor,&seven.actor};mock_chassis={0,0,0,0,0,{1,0,0,0}};fake_tick+=1000;
 for(auto f:{&three,&seven}){std::fill(f->out.begin(),f->out.end(),0);assert(axle_correction_apply(&f->actor,0,true));}
 fake_tick+=110;mock_chassis.x=.02f;mock_chassis.z=-.2f;
 for(auto f:{&three,&seven}){assert(axle_correction_apply(&f->actor,0,true));if(f->profile.rows==14)assert(std::abs(f->out[0])<1e-6);else assert(f->out[0]<-.001f);}
 // Shape alone is insufficient: cross-profile lever/table mismatch rejected.
 assert(!bbm::match(60,three.profile.lever,seven.map,seven.table,seven.profile.rows));
 puts("PASS: all three BBM profiles, symmetric common outputs, correct active rows, single-chain ST3, independent actors, unknown/map/table/mode guards");
}
