from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'main/Advanced-Trailer-Control/dllmain.cpp').read_text()
a=s.index('using SteeringClock =');b=s.index('using get_wheel_angle_t',a)
c=s.index('prism::g_advance_steering_t g_advance_steering_original;',b)
d=s.index('\n\n\n\nstd::string to_lower',c)
(root/'tests/extracted_hooks.inc').write_text('// Generated from this branch actual hook bodies.\n'+(s[a:b]+s[c:d]).replace('#include "mwt_wheels.inc"', '// MWT wheel writer is exercised separately by mwt_wheel_runtime_tests.cpp.').replace('#include "bridge_mode.inc"', '// Bridge controller is exercised separately by bridge_runtime_tests.cpp.\nbool bridge_target(prism::game_trailer_actor_u*, float&) { return false; }'))
