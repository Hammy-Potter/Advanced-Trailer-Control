#include <vector>
#include <string>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <algorithm>
#include "../main/Advanced-Trailer-Control/geometry_snapshot.h"
using SIZE_T=size_t;
namespace prism {struct game_trailer_actor_u {char pad[0x30]{};void* object=nullptr;float steering=0;};}
struct Physics {uintptr_t* vt;atc_geometry::Pose pose;};
void getter(void*o,void*out){std::memcpy(out,&((Physics*)o)->pose,sizeof(atc_geometry::Pose));}
void* GetModuleHandleW(void*){return (void*)((uintptr_t)getter-0x166f5d0);}
bool ReadProcessMemory(void*,const void*src,void*dst,size_t n,SIZE_T*got){std::memcpy(dst,src,n);*got=n;return true;}
void* GetCurrentProcess(){return nullptr;}
uint64_t clock_tick=1000;
uint64_t GetTickCount64(){return clock_tick;}
void scs_log(int,const char*,...){}
bool multi_module_mode=false,locked=false,temp=false;
std::vector<prism::game_trailer_actor_u*> chain;
auto get_trailer_chain(){return chain;}
prism::game_trailer_actor_u* locked_actor=nullptr;
bool isTrailerLocked(prism::game_trailer_actor_u* a){return locked||a==locked_actor;}
bool isTrailerTempLocked(prism::game_trailer_actor_u*){return temp;}
bool geometry_exe(){return true;}
#include "joint_mock.inc"
#include "../main/Advanced-Trailer-Control/bridge_mode.inc"

void yaw(Physics& p,double deg){p.pose.q[0]=float(cos(deg/2/57.295779513));p.pose.q[2]=float(sin(deg/2/57.295779513));}
int main(){
 uintptr_t vt[40]{};vt[0x130/8]=(uintptr_t)getter;Physics phys[4]{};prism::game_trailer_actor_u actors[4];
 for(int i=0;i<4;++i){phys[i].vt=vt;phys[i].pose.q[0]=1;actors[i].object=&phys[i];chain.push_back(&actors[i]);}
 for(int mode:{1,2}){
  bridge_basic_mode=mode==1;bridge_mode=mode==2;bridge_sync();yaw(phys[1],10);yaw(phys[3],0);float target=0;
  for(int i=0;i<120;++i){clock_tick+=16;phys[3].pose.z-=.01f;assert(bridge_target(&actors[3],target));}
  assert(bridge_hold.travel.direction==1&&target<0);
  const float forward=target;
  for(int i=0;i<120;++i){clock_tick+=16;phys[3].pose.z+=.01f;assert(bridge_target(&actors[3],target));}
  assert(bridge_hold.travel.direction==-1&&target==0&&reverse_joint.owned&&ReverseJointApi::motion==2&&bridge_native_wheel_follow);
  auto* control=&actors[mode==1?2:3];const float expected=mode==1?-.4f:.4f;
  bridge_manual_input(control,.4f);clock_tick+=50;assert(bridge_target(&actors[3],target)&&target==0&&reverse_joint.owned&&ReverseJointApi::motion==2);
  clock_tick+=121;assert(bridge_target(&actors[3],target)&&bridge_hold.held&&std::abs(target)<1e-6);
  bridge_auto_input(control);assert(!bridge_hold.held&&bridge_target(&actors[3],target)&&target==0&&reverse_joint.owned);
  for(int i=0;i<120;++i){clock_tick+=16;phys[3].pose.z-=.01f;assert(bridge_target(&actors[3],target));}
  assert(!reverse_joint.owned&&ReverseJointApi::motion==2&&target<0);
 }
 puts("PASS: both actual bridge modes run continuous reverse joint drives, retain the drive during manual steering, release-to-hold and Auto");
}
