#include "../main/Advanced-Trailer-Control/powered_joint.h"
#include <cassert>
#include <cstdio>
struct Api {
 bool valid=true,accept_goal=true,accept_drive=true;int motion=2,writes=0;double sign=1;atc_joint::Handle h{1,2};
 atc_power::Drive drives[6]{};atc_joint::Transform goal{{0,0,0,1},{1,2,3}},relative{{float(sin(.1)),0,0,float(cos(.1))},{0,0,0}};atc_power::Velocity velocity{{1,2,3},{.2f,.3f,.4f}};
 bool bind(uintptr_t,atc_joint::Handle& out){out=h;return valid;}
 int get_motion(atc_joint::Handle){return motion;}
 bool read_relative(atc_joint::Handle,atc_joint::Transform& out){out=relative;return true;}
 bool read_drive(atc_joint::Handle,int i,atc_power::Drive& out){out=drives[i];return true;}
 void write_drive(atc_joint::Handle,int i,const atc_power::Drive& d){if(accept_drive)drives[i]=d;++writes;}
 bool read_goal(atc_joint::Handle,atc_joint::Transform& out){out=goal;return true;}
 void write_goal(atc_joint::Handle,const atc_joint::Transform& p){if(accept_goal)goal=p;++writes;}
 bool read_velocity(atc_joint::Handle,atc_power::Velocity& out){out=velocity;return true;}
 void write_velocity(atc_joint::Handle,const atc_power::Velocity& v){velocity=v;++writes;}
 bool axis_sign(atc_joint::Handle,uintptr_t,uintptr_t,const atc_geometry::Pose&,const atc_geometry::Pose&,double& out){out=sign;return std::abs(sign)==1;}
};
int main(){
 using namespace atc_power;
 // Replacing twist preserves the saved swing and target translation.
 atc_joint::Transform original_swing{{0,float(sin(.15)),0,float(cos(.15))},{2,3,4}};
 auto composed=goal(original_swing,.6);const auto swing=wheel_path::multiply({composed.q[3],composed.q[0],composed.q[1],composed.q[2]},{cos(.3),-sin(.3),0,0});
 assert(std::abs(swing[2]-sin(.15))<1e-6&&std::abs(swing[1])<1e-6&&composed.p[0]==2);
const atc_geometry::Pose p{0,0,0,0,0,{1,0,0,0}};Api api;State state;const auto original=api.goal;const auto original_v=api.velocity;const auto original_d=api.drives[4];
 auto run=[&](uint64_t t,double desired,bool manual=false,double command=0){return apply(state,api,123,3,456,p,p,.1,desired,manual,command,t,.2);};
 assert(run(1000,.5)&&state.owned&&api.motion==2);assert(std::abs(twist(api.goal)-.2)<1e-6); // seed current twist, not zero or requested future goal
 for(int k=1;k<=20;++k){const double prev=state.world_target;assert(run(1000+k*16,.5));assert(state.world_target-prev<=.2*.016+1e-8);assert(api.motion==2);}
 assert(state.world_target>.15&&state.world_target<.18);
 const auto prior=state.world_target;assert(run(1336,.5,true,-1));assert(state.world_target<prior&&state.owned&&api.motion==2); // manual moves target, never unlocks
 const auto same_tick=state.world_target;assert(run(1336,.5,true,-1)&&state.world_target==same_tick);
 const double hold=state.world_target;assert(run(1352,hold)&&std::abs(state.world_target-hold)<1e-9);
 for(int i=0;i<3;++i)assert(api.goal.p[i]==original.p[i]);assert(api.velocity.angular[0]==0&&api.velocity.angular[1]==original_v.angular[1]);
 assert(release(state,api)&&same(api.drives[4],original_d)&&atc_joint::same(api.goal,original)&&same(api.velocity,original_v)&&api.motion==2);
 api.sign=-1;assert(run(2000,.5));assert(run(2050,.5));assert(twist(api.goal)<.2);assert(release(state,api));
 api.motion=0;const int writes=api.writes;assert(!run(3000,.5)&&api.writes==writes);api.motion=1;assert(run(3000,.5)&&api.motion==1);assert(release(state,api)&&api.motion==1);api.motion=2;
 api.drives[5].stiffness=1;assert(!run(4000,.5));api.drives[5]={};api.sign=0;assert(!run(4000,.5));api.sign=1;
 api.accept_goal=false;assert(!run(4000,.5)&&!state.owned&&api.drives[4].stiffness==0);api.accept_goal=true;
 api.accept_drive=false;assert(!run(4000,.5)&&!state.owned&&same(api.velocity,original_v)&&atc_joint::same(api.goal,original));api.accept_drive=true;
 assert(run(5000,.5));api.valid=false;const int n=api.writes;assert(!release(state,api)&&api.writes==n&&!state.owned);
 puts("PASS: finite moving-target twist drive, captured seed, bounded Auto/manual target motion, same-tick safety, continuous manual/hold drive, free/limited motion unchanged, original settings restored and incompatibility/rollback/stale identity guards");
}
