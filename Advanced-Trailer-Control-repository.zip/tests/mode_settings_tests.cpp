#include <string>
#include <cassert>
#include <cstdio>
bool multi_module_mode=false,front_axle_test_enabled=false,bridge_basic_mode=false,bridge_mode=false,mwt_mode=false,axle_correction_enabled=false;
#include "../main/Advanced-Trailer-Control/mode_settings.inc"
int main(){
 for (const char* mode : {"normal","multi_module","bbm","bridge","bridge_expert","mwt"}) {
  multi_module_mode=front_axle_test_enabled=bridge_basic_mode=bridge_mode=mwt_mode=axle_correction_enabled=true;
  restore_steering_mode(mode);assert(std::string(selected_steering_mode())==mode);
  assert(int(multi_module_mode)+int(front_axle_test_enabled)+int(bridge_basic_mode)+int(bridge_mode)+int(mwt_mode)==(std::string(mode)!="normal"));
  assert(!axle_correction_enabled);
 }
 restore_steering_mode("unknown");assert(std::string(selected_steering_mode())=="normal");
 puts("PASS: all modes restore exclusively; unknown modes use native steering.");
}
