#include "../main/Advanced-Trailer-Control/reverse_joint.h"
#include <cassert>
#include <cstdio>
struct Api {
 bool valid=true,accept_pose=true,accept_lock=true;int mode=2,writes=0;atc_joint::Handle handle{1,2};
 atc_joint::Transform pose{{0,0,.70710678f,.70710678f},{1,2,3}},relative{{float(sin(.2)),0,0,float(cos(.2))},{0,0,0}};
 bool bind(uintptr_t,atc_joint::Handle& h){h=handle;return valid;}
 bool read_local(atc_joint::Handle,atc_joint::Transform& p){p=pose;return true;}
 bool read_relative(atc_joint::Handle,atc_joint::Transform& p){p=relative;return true;}
 int get_motion(atc_joint::Handle){return mode;}
 void set_motion(atc_joint::Handle,int v){++writes;if(v!=0||accept_lock)mode=v;}
 void write_local(atc_joint::Handle,const atc_joint::Transform& p){++writes;if(accept_pose)pose=p;}
};
int main(){
 Api api;atc_joint::State s;atc_geometry::Pose body{0,0,0,0,0,{1,0,0,0}};const auto original=api.pose;
 assert(atc_joint::lock(s,api,123,3,body,body)&&s.owned&&api.mode==0);
 for(int i=0;i<3;++i)assert(api.pose.p[i]==original.p[i]);
 // New frame removes current twist without moving its anchor: t^-1*q has x=0.
 const auto delta=wheel_path::Q{cos(.2),sin(.2),0,0};const auto zero=wheel_path::multiply({delta[0],-delta[1],0,0},delta);assert(std::abs(zero[1])<1e-12);
 const int writes=api.writes;assert(atc_joint::lock(s,api,123,3,body,body)&&api.writes==writes);
 assert(atc_joint::release(s,api)&&api.mode==2&&atc_joint::same(api.pose,original));
 api.mode=1;assert(atc_joint::lock(s,api,123,3,body,body));assert(atc_joint::release(s,api)&&api.mode==1);
 api.mode=0;api.writes=0;assert(atc_joint::lock(s,api,123,3,body,body)&&!s.owned&&api.writes==0);
 api.mode=2;api.pose.q[2]=0;api.pose.q[3]=1;assert(!atc_joint::lock(s,api,123,3,body,body)&&api.writes==0); // wrong twist axis
 api.pose=original;api.accept_pose=false;assert(!atc_joint::lock(s,api,123,3,body,body)&&api.mode==2&&!s.owned);api.accept_pose=true;
 api.accept_lock=false;assert(!atc_joint::lock(s,api,123,3,body,body)&&api.mode==2&&atc_joint::same(api.pose,original));api.accept_lock=true;
 assert(atc_joint::lock(s,api,123,3,body,body));api.valid=false;const int count=api.writes;assert(!atc_joint::release(s,api)&&!s.owned&&api.writes==count);
 puts("PASS: current-angle joint rebase, unchanged anchor, yaw-only operation, idempotent lock, free/limited restoration, external lock, axis checks, rejected writes and stale-identity refusal");
}
