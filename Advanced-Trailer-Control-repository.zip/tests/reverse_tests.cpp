#include "../main/Advanced-Trailer-Control/travel_direction.h"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <sstream>
atc_geometry::Pose pose(double x,double z,double yaw=0){return {float(x),0,float(z),0,0,{float(cos(yaw/2)),0,float(sin(yaw/2)),0}};}
int main(int argc,char** argv){
 atc_travel::State direction;double gain=0;
 for(int i=0;i<100;++i)gain=atc_travel::update(direction,pose(0,-i*.01),1000+i*16);
 assert(direction.direction==1&&gain>.99);
 for(int i=0;i<100;++i)gain=atc_travel::update(direction,pose(0,-.99+i*.01),2600+i*16);
 assert(direction.direction==-1&&gain<-.99);
 for(int i=0;i<100;++i)gain=atc_travel::update(direction,pose(0,0),4200+i*16);
 assert(std::abs(gain)<.001);const int old=direction.direction;
 for(int i=0;i<100;++i)atc_travel::update(direction,pose(0,(i%2?1:-1)*.0001),5800+i*16);
 assert(direction.direction==old&&std::abs(direction.gain)<.001);
 auto sector=pose(0,0);sector.sector_x=2;assert(atc_travel::update(direction,sector,7500)==0&&direction.direction==0);
 auto invalid=pose(0,0);invalid.q[0]=0;assert(atc_travel::update(direction,invalid,7600)==0&&!direction.ready);
 // Same wheel line has the same heading when rolling along it backwards.
 wheel_path::State forward{},reverse{},legacy{};std::array<wheel_path::V,14> points{};const auto identity=pose(0,0);
 for(int i=0;i<30;++i){
  wheel_path::sample(forward,pose(.02*i,-.2*i),identity,1000+i*100,points,14,true);
  wheel_path::sample(reverse,pose(-.02*i,.2*i),identity,1000+i*100,points,14,true);
  wheel_path::sample(legacy,pose(-.02*i,.2*i),identity,1000+i*100,points,14);
 }
 for(size_t r=0;r<14;++r){assert(std::abs(forward.offsets[r]-reverse.offsets[r])<1e-6);assert(forward.offsets[r]<-.09);assert(legacy.offsets[r]==0);}
 if(argc>1){
  std::ifstream file(argv[1]);assert(file);std::string line;atc_travel::State replay;wheel_path::State path;int count=0,reverse_count=0,forward_count=0,reverse_path=0;
  while(std::getline(file,line)){
   std::replace(line.begin(),line.end(),',',' ');std::istringstream in(line);uint64_t t;atc_geometry::Pose actor{};
   in>>t>>actor.x>>actor.y>>actor.z>>actor.sector_x>>actor.sector_z;for(float& q:actor.q)in>>q;assert(in);
   const double polarity=atc_travel::update(replay,actor,1000+t);
   const auto result=wheel_path::sample(path,actor,identity,1000+t,points,14,true);++count;
   if(t>=6000&&t<=12000){assert(replay.direction==-1&&polarity<0);++reverse_count;reverse_path+=result.valid;}
   if(t>=18000){assert(replay.direction==1&&polarity>0);++forward_count;}
  }
  assert(count>60&&reverse_count>10&&reverse_path>10&&forward_count>3);
  printf("Reverse capture replay: %d poses; %d reverse interval samples, %d reverse-following samples, %d later forward samples\n",count,reverse_count,reverse_path,forward_count);
 }
 puts("PASS: automatic forward/reverse polarity, stopped/noise hysteresis, invalid/sector reset, wheel-line reverse equivalence and unchanged legacy forward-only path");
}
