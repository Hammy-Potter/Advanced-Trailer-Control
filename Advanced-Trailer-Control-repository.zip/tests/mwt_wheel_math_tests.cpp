#include "../main/Advanced-Trailer-Control/mwt_wheel_math.h"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <sstream>
using namespace mwt_wheels;
std::vector<atc_geometry::Pose> mounts(){
 const float z[]={-5.844203f,-4.554170f,-3.229162f,-1.924160f,-.634249f,.690773f,2.097464f};
 std::vector<atc_geometry::Pose> p;for(float v:z)p.push_back({0,-.532495f,v,0,0,{1,0,0,0}});return p;
}
atc_geometry::Pose pose(double x,double z,double yaw=0){return {float(x),0,float(z),0,0,{float(std::cos(yaw/2)),0,float(std::sin(yaw/2)),0}};}
int main(int argc,char** argv){
 auto local=mounts();std::array<wheel_path::V,14> points{};assert(locators(local,points));
 auto broken=local;broken[6].z+=1;assert(!locators(broken,points));assert(locators(local,points));
 wheel_path::State state{};const auto identity=pose(0,0);std::vector<float> native(14);std::array<float,14> desired{},residual{};
 // A rigid body moving forwards while yawing needs different axle directions.
 for(int i=0;i<=10;++i)wheel_path::sample(state,pose(0,-i*.2,i*.002),identity,1000+i*100,points,14);
 assert(state.offsets[0]>0&&state.offsets[13]<0);
 assert(targets(native,state,desired));std::vector<float> common(7);
 for(size_t g=0;g<7;++g)common[g]=std::abs(desired[2*g])<std::abs(desired[2*g+1])?desired[2*g]:desired[2*g+1];
 assert(residuals(desired,common,residual));
 for(size_t r=0;r<14;++r){assert(residual[r]==common[r/2]);assert(desired[r]==desired[(r/2)*2]);assert(std::abs(common[r/2]-desired[r])<1e-7);}
 auto bad_common=common;bad_common[0]+=.2f;assert(!residuals(desired,bad_common,residual));
 auto bad_pair=desired;bad_pair[1]+=.01f;assert(!residuals(bad_pair,common,residual));
 // Mirrored manoeuvre reverses the outside/inside wheel pairs.
 wheel_path::State mirror{};for(int i=0;i<=10;++i)wheel_path::sample(mirror,pose(0,-i*.2,-i*.002),identity,1000+i*100,points,14);
 for(size_t g=0;g<7;++g)assert(std::abs(state.offsets[g*2]+mirror.offsets[g*2+1])<.00001);
 // Articulation correction retains authority and final targets stay bounded.
 native.assign(14,1.f);assert(targets(native,state,desired));for(auto v:desired)assert(std::abs(v)<=50*rad+1e-7);
 native[0]=NAN;assert(!targets(native,state,desired));native[0]=0;common[0]=NAN;assert(!residuals(desired,common,residual));
 // Replay actual turn-in/straightening and verify a counter angle where native
 // steering was pointing away from the measured axle path.
 if(argc>1){std::ifstream f(argv[1]);assert(f);std::string line;state={};int count=0,valid=0,counter=0;double lo=0,hi=0;
  while(std::getline(f,line)){
   std::replace(line.begin(),line.end(),',',' ');std::istringstream in(line);uint64_t t;atc_geometry::Pose actor{};
   in>>t>>actor.x>>actor.y>>actor.z>>actor.sector_x>>actor.sector_z;for(auto& q:actor.q)in>>q;
   std::vector<double> recorded(7);for(size_t g=0;g<7;++g)in>>local[g].x>>local[g].y>>local[g].z>>recorded[g];double demand;in>>demand;assert(in);
   assert(locators(local,points));auto result=wheel_path::sample(state,actor,identity,t+1000,points,14);count++;valid+=result.valid;
   // Recorded group angle is a conservative native correction proxy. Runtime
   // uses the exact freshly computed native angle of each individual wheel.
   for(size_t r=0;r<14;++r)native[r]=float(recorded[r/2]*rad);
   assert(targets(native,state,desired));for(auto v:desired){assert(std::isfinite(v)&&std::abs(v)<=50*rad+1e-6);lo=std::min(lo,double(v)/rad);hi=std::max(hi,double(v)/rad);}
   if(result.valid&&t>=5000&&t<=7000&&recorded[0]>.1&&desired[0]<-.5*rad)counter++;
  }
  assert(count>=180&&valid>140&&counter>5&&lo< -3&&hi>3);
  printf("Replay: %d samples, %d moving, %d corrected turn-in samples; combined targets %.3f..%.3f deg\n",count,valid,counter,lo,hi);
 }
 puts("PASS: distinct rigid axle path angles, mirrored turns, paired wheel targets and absolute wheel/axle yaw alignment, limits, nonfinite guards and captured turn-in countersteer");
}
