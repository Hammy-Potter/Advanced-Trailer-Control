#include "../main/Advanced-Trailer-Control/bridge_math.h"
#include <cassert>
#include <cstdio>
int main(){
 using namespace bridge_math;
 assert(demand(32,-19.2)==0);assert(demand(-32,19.2)==0);
 assert(demand(0,-16.73)>.0);assert(demand(0,16.73)<0);
 assert(demand(30,0)<0);assert(demand(-30,0)>0);
 assert(demand(0,.1)==0);assert(demand(0,50)==-.25f);
 assert(demand(0,50,true)==.25f);
 const float front[]={.1945849f,-.0004222f,.9808803f,.0032109f};
 const float beam[]={.1919819f,.0003286f,.9813984f,-.0004311f};
 const float rear[]={.3327242f,-.0001518f,.9430238f,.0008823f};
 assert(std::abs(wrap(yaw(front)-yaw(beam))*57.2957795+.304)<.01);
 assert(std::abs(wrap(yaw(rear)-yaw(beam))*57.2957795+16.731)<.01);
 assert(std::abs(wrap(179/57.2957795-(-179/57.2957795))*57.2957795+2)<.001);
 puts("PASS: supplied orientation sample, wraparound, 0.6 mirrored targets, correction signs, deadband, limits and polarity switch");
}
