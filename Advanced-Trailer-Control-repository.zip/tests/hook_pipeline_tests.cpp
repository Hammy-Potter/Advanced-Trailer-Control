#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>
#include "../main/Advanced-Trailer-Control/response_math.h"
using __int64=long long;
namespace prism {
struct steering_data_t {float output=0;};
struct game_trailer_actor_u {float steering=0;steering_data_t* steering_data=nullptr;};
using g_set_vehicle_steering_t=void(*)(steering_data_t*,float);
using g_advance_steering_t=__int64(*)(game_trailer_actor_u*);
}
struct CrabTable {uintptr_t data=0;float lock_radians=0;};
bool crab_supported=false,multi_module_mode=false;int multi_module_leader=0;float steering_seconds=5;
std::atomic<bool> crab_enabled{false};std::atomic<unsigned> crab_members{0},crab_reversed{0};std::atomic<float> crab_command{0};
std::mutex response_mutex;std::unordered_map<prism::game_trailer_actor_u*,CrabTable> crab_tables;
std::vector<prism::game_trailer_actor_u*> chain,locked;std::unordered_map<prism::game_trailer_actor_u*,float> targets;
auto get_trailer_chain(){return chain;}
bool isTrailerSteerable(prism::game_trailer_actor_u*t){return t->steering_data;}
bool isTrailerLocked(prism::game_trailer_actor_u*t){return std::find(locked.begin(),locked.end(),t)!=locked.end();}
bool isTrailerTempLocked(prism::game_trailer_actor_u*){return false;}
float manual_target(prism::game_trailer_actor_u*t){auto i=targets.find(t);return i==targets.end()?t->steering:i->second;}
void parallel_outputs(const CrabTable&,float){}
void scs_log(int,const char*,void*){}
struct EndModule {prism::game_trailer_actor_u* actor;uintptr_t data;};struct EndPair {EndModule module[2];};
std::shared_ptr<const EndPair> end_pair;int applied=0;
// Geometry maths is independently tested in end_centre_tests.cpp. This stub
// checks when/where the ACTUAL hook calls the validated writer in the pipeline.
bool end_centre_apply(const EndPair&p,int index,float demand){++applied;p.module[index].actor->steering_data->output=index==0?-demand:demand;return true;}
// Targeted axle output override is covered by axle_correction_tests.cpp.
bool front_axle_test_enabled=false;
bool native_complete=false;int post_calls=0,pre_calls=0;
bool axle_correction_selected(prism::game_trailer_actor_u*){return front_axle_test_enabled;}
bool axle_correction_apply(prism::game_trailer_actor_u*,float,bool post=false){if(front_axle_test_enabled){if(post){assert(native_complete);++post_calls;}else {assert(!native_complete);++pre_calls;}}return true;}
bool bridge_native_wheel_follow=false;bool mwt_mode=false;int mwt_pre=0,mwt_post=0;
bool mwt_wheels_prepare(prism::game_trailer_actor_u*){if(!mwt_mode)return false;assert(!native_complete);++mwt_pre;return true;}
bool mwt_wheels_finish(prism::game_trailer_actor_u*){assert(mwt_mode&&native_complete);++mwt_post;return true;}
#include "extracted_hooks.inc"
float native_demand=.4f,observed=0;
void native_set(prism::steering_data_t*d,float v){d->output=v;}
__int64 native_advance(prism::game_trailer_actor_u*a){g_set_vehicle_steering_hook(a->steering_data,native_demand);observed=a->steering_data->output;native_complete=true;return 42;}
void step(prism::game_trailer_actor_u&a){a.steering=0;steering_returns[&a]={a.steering_data,0,SteeringClock::now()-std::chrono::milliseconds(100)};}
int main(){
 prism::steering_data_t d1,d2,d3;prism::game_trailer_actor_u a{0,&d1},b{0,&d2},c{0,&d3};chain={&a,&b,&c};
 g_set_vehicle_steering_original=native_set;g_advance_steering_original=native_advance;
 auto p=std::make_shared<EndPair>();p->module[0]={&a,reinterpret_cast<uintptr_t>(&d1)};p->module[1]={&b,reinterpret_cast<uintptr_t>(&d2)};end_pair=p;
 assert(g_advance_steering_hook(&a)==42&&observed==.4f&&applied==0);
 multi_module_mode=true;locked={&a};targets[&a]=.8f;step(a);g_advance_steering_hook(&a);assert(observed<0&&applied==1);
 step(b);g_advance_steering_hook(&b);assert(observed>0&&applied==2);
 // Auto uses the native source demand immediately once return has completed.
 locked.clear();steering_returns.erase(&a);g_advance_steering_hook(&a);assert(observed==-.4f&&a.steering==.4f);
 const int before=applied;g_advance_steering_hook(&c);assert(observed==.4f&&applied==before);
 chain={&a,&c};steering_returns.erase(&b);g_advance_steering_hook(&b);assert(observed==.4f&&applied==before);
 chain={&a,&b,&c};p->module[1].data=0;g_advance_steering_hook(&a);assert(applied==before);
 multi_module_mode=false;g_advance_steering_hook(&a);assert(observed==.4f&&applied==before);
 front_axle_test_enabled=true;native_complete=false;steering_returns.erase(&a);g_advance_steering_hook(&a);assert(pre_calls==1&&post_calls==1&&observed==.4f);
 front_axle_test_enabled=false;mwt_mode=true;locked={&a};targets[&a]=.2f;step(a);native_complete=false;g_advance_steering_hook(&a);assert(mwt_pre==1&&mwt_post==1);mwt_mode=false;
 std::puts("PASS: actual hooks apply both modules before downstream reads, linked manual target, native Auto, disabled mode, unrelated actor, detachment and data identity guards");
}
