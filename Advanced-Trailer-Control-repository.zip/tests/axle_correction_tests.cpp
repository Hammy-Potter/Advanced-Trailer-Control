#include <vector>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdint>
#include <cassert>
#include <string>
#include <cstdio>
#include "../main/Advanced-Trailer-Control/geometry_snapshot.h"
#include "../main/Advanced-Trailer-Control/end_centre_math.h"
namespace prism{struct steering_data_t{};struct game_trailer_actor_u{steering_data_t*steering_data=nullptr;char memory[0x800]{};};}
bool multi_module_mode=false,bridge_mode=false,bridge_basic_mode=false,mwt_mode=false;
std::vector<prism::game_trailer_actor_u*> chain;auto get_trailer_chain(){return chain;}
std::vector<std::pair<uintptr_t,size_t>> regions;
bool end_centre_copy(uintptr_t a,void*out,size_t n){for(auto r:regions)if(a>=r.first&&n<=r.second&&a-r.first<=r.second-n){memcpy(out,(void*)a,n);return true;}return false;}
template<class T>bool end_centre_read(uintptr_t a,T&v){return end_centre_copy(a,&v,sizeof v);}
bool end_centre_writable(uintptr_t a,size_t n){float tmp[14];return n>=4&&n<=sizeof tmp&&n%4==0&&end_centre_copy(a,tmp,n);}
uint64_t fake_tick=2000;uint64_t GetTickCount64(){return fake_tick;}void scs_log(int,const char*,...){}
bool geometry_exe(){return true;}
atc_geometry::Pose mock_chassis{0,0,0,0,0,{1,0,0,0}},mock_local{0,0,0,0,0,{1,0,0,0}};
bool geometry_trace_local(uintptr_t,atc_geometry::Pose& p,float& common){p=mock_local;common=0;return true;}
bool geometry_pose(uintptr_t,unsigned,atc_geometry::Pose*p,bool){*p=mock_chassis;return true;}
#include "../main/Advanced-Trailer-Control/axle_correction.inc"
template<class T>void put(char*p,size_t o,T v){memcpy(p+o,&v,sizeof v);}
int main(){char d[512]{};std::vector<float> table(968),out(8);std::vector<uint64_t> map{0,1,2,3,4,5,6,7};
 for(auto r:std::vector<std::pair<void*,size_t>>{{d,sizeof d},{table.data(),table.size()*4},{out.data(),32},{map.data(),64}})regions.push_back({uintptr_t(r.first),r.second});
 put(d,0,atc_geometry::Array{0,uintptr_t(table.data()),968,968});put(d,0x30,atc_geometry::Array{0,uintptr_t(out.data()),8,8});put(d,0xa0,atc_geometry::Array{0,uintptr_t(map.data()),8,8});put(d,0x28,60);put(d,0x168,27.7040977f);
 const float neg[]={31.1722775f,33.8355331f,35.4428139f,38.2633095f,39.2066231f,42.1115417f,41.8871651f,44.8209267f};const float pos[]={-33.8355331f,-31.1722775f,-38.2633095f,-35.4428139f,-42.1115417f,-39.2066231f,-44.8209267f,-41.8871651f};for(int r=0;r<8;++r){table[r*121]=neg[r];table[r*121+120]=pos[r];}
 prism::game_trailer_actor_u front{},rear{reinterpret_cast<prism::steering_data_t*>(d)};chain={&front,&rear};assert(!axle_correction_apply(&rear,1));axle_correction_enabled=true;
 for(float input:{-1.f,-.5f,0.f,.5f,1.f}){assert(axle_correction_apply(&rear,input));for(float a:out)assert(std::abs(a+input*float(60*end_centre::rad))<1e-6);}
 assert(!axle_correction_apply(&front,1));bridge_mode=true;assert(!axle_correction_apply(&rear,1));bridge_mode=false;
 map[0]=7;assert(!axle_correction_apply(&rear,1));map[0]=0;table[0]+=1;assert(!axle_correction_apply(&rear,1));

 std::vector<float> common{-.4f};std::vector<int32_t> indices{0};char object[0x80]{};
 std::vector<uintptr_t> objects{uintptr_t(object)};
 for(auto r:std::vector<std::pair<void*,size_t>>{{&rear,sizeof rear},{common.data(),4},{indices.data(),4},{objects.data(),8},{object,sizeof object}})regions.push_back({uintptr_t(r.first),r.second});
 char*actor=reinterpret_cast<char*>(&rear);
 put(actor,0x3d8,atc_geometry::Array{0,uintptr_t(common.data()),1,1});
 put(actor,0x430,atc_geometry::Array{0,uintptr_t(indices.data()),1,1});
 put(actor,0x40,atc_geometry::Array{0,uintptr_t(objects.data()),1,1});
 atc_geometry::Pose pose{0,0,0,0,0,{float(std::cos(.2)),0,float(-std::sin(.2)),0}};put(object,0x30,pose);
 table[0]-=1;front_axle_test_enabled=true;axle_correction_enabled=false;assert(axle_correction_apply(&rear,1,false));for(float v:out)assert(std::abs(v+float(60*end_centre::rad))<1e-6);for(float&v:out)v=-.4f;assert(axle_correction_apply(&rear,1,true));
 for(size_t r=0;r<8;++r)assert(out[r]==-.4f); // history warmup
 fake_tick+=110;mock_chassis.x=.02f;mock_chassis.z=-.2f;
 assert(axle_correction_apply(&rear,-1,true));
 for(size_t r=4;r<8;++r)assert(out[r]==-.4f);assert(std::abs(out[0]+.4f)>.001);
 const auto saved=out;common[0]=.8f;fake_tick+=110;assert(!axle_correction_apply(&rear,1,true));assert(out==saved);
 common[0]=-.4f;indices[0]=99;fake_tick+=110;assert(!axle_correction_apply(&rear,1,true));assert(out==saved);
 indices[0]=0;pose.q[0]=0;pose.q[2]=0;put(object,0x30,pose);fake_tick+=110;assert(!axle_correction_apply(&rear,1,true));assert(out==saved);
 puts("PASS: common eight-locator output, symmetric 60-degree endpoints/half-lock/neutral, disabled/mode/actor/map/table guards");}
