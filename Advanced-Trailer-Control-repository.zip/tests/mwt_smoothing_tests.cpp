#include "../main/Advanced-Trailer-Control/mwt_smoothing.h"
#include <cassert>
#include <cstdio>
using namespace mwt_wheels;
int main(){
 Smooth state;std::vector<float> measured(7,.1f);std::array<float,14> command{};command.fill(.5f);
 assert(smooth(state,command,measured,1000));for(float a:command)assert(a==.1f);
 command.fill(.5f);assert(smooth(state,command,measured,1016));assert(command[0]>.1f&&command[0]-.1f<=45*rad*.016+1e-7);
 const auto same=command;command.fill(.5f);assert(smooth(state,command,measured,1016));assert(command==same);
 for(int n=2;n<=100;++n){command.fill(.5f);assert(smooth(state,command,measured,1000+n*16));}
 assert(std::abs(command[0]-.5f)<1e-6);
 // 10 Hz steps become bounded frame updates; left/right remain rigidly paired.
 state={};measured.assign(7,0);float previous=0,largest=0;
 for(uint64_t t=0;t<=1000;t+=16){command.fill(float((t/100)*2.5*rad));assert(smooth(state,command,measured,1000+t));largest=std::max(largest,std::abs(command[0]-previous));assert(command[0]-previous<=45*rad*.016+1e-6);for(size_t g=0;g<7;++g)assert(command[g*2]==command[g*2+1]);previous=command[0];}
 assert(largest<1*rad&&command[0]>20*rad);
 // Clock/stall reset starts at measured model yaw, never an invented centre.
 command.fill(.5f);assert(smooth(state,command,measured,4000)&&command[0]==0);
 measured.assign(7,.2f);command.fill(.5f);assert(smooth(state,command,measured,3000)&&command[0]==.2f);
 auto old=state;command.fill(.3f);command[1]=.4f;assert(!smooth(state,command,measured,3016)&&state.tick==old.tick&&state.axle==old.axle);
 printf("PASS: frame smoothing, paired outputs, 45 deg/s bound, repeated-tick safety, steady convergence, history reset and invalid input; largest replay step %.3f deg\n",largest/rad);
}
