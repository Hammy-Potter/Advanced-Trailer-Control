#include "../main/Advanced-Trailer-Control/logging_policy.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
int main(){
 for(const char* s:{"[mwt-wheels] following","[steering] change","[bbm] correction","[axle-correction] output","[bridge-test] angle","[end-centre] pair","[geometry] capture","[bogie-motion] sample"}){
  atc_log::diagnostic_until=0;assert(!atc_log::allowed(0,s,1000));assert(atc_log::allowed(2,s,1000));
  atc_log::diagnostic_until=2000;assert(atc_log::allowed(0,s,1500));assert(!atc_log::allowed(0,s,2000));
 }
 assert(atc_log::allowed(0,"Plugin Loading",1000));assert(!atc_log::allowed(0,nullptr,1000));
 puts("PASS: quiet routine logging, bounded diagnostic window, warnings/errors retained");
}
