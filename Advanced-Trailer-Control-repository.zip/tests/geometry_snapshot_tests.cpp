#include "../main/Advanced-Trailer-Control/geometry_snapshot.h"
#include <cassert>
#include <cstring>
#include <cstdio>
#include <limits>
int main(){
 unsigned char memory[512]{};
 atc_geometry::Array a{0,128,2,2};atc_geometry::Vec3 p[2]{{-1,0,-7.3f},{1,0,7.4f}};
 std::memcpy(memory+32,&a,sizeof(a));std::memcpy(memory+128,p,sizeof(p));
 auto read=[&](uintptr_t address,void*out,size_t size){if(address>sizeof(memory)||size>sizeof(memory)-address)return false;std::memcpy(out,memory+address,size);return true;};
 std::vector<atc_geometry::Vec3> out;
 assert(atc_geometry::array(read,32,out)&&out.size()==2&&out[1].z==7.4f);
 assert(atc_geometry::local(out[0]));
 a.count=129;a.capacity=129;std::memcpy(memory+32,&a,sizeof(a));assert(!atc_geometry::array(read,32,out)&&out.empty());
 a.count=3;a.capacity=2;std::memcpy(memory+32,&a,sizeof(a));assert(!atc_geometry::array(read,32,out));
 a.count=2;a.capacity=2;a.pointer=500;std::memcpy(memory+32,&a,sizeof(a));assert(!atc_geometry::array(read,32,out));
 a.pointer=UINT64_MAX-4;std::memcpy(memory+32,&a,sizeof(a));assert(!atc_geometry::array(read,32,out));
 a.pointer=128;std::memcpy(memory+32,&a,sizeof(a));int calls=0;
 auto changed=[&](uintptr_t address,void* dest,size_t size){bool ok=read(address,dest,size);if(++calls==2){a.count=1;std::memcpy(memory+32,&a,sizeof(a));}return ok;};
 assert(!atc_geometry::array(changed,32,out));
 atc_geometry::Pose pose{1,2,3,0,0,{1,0,0,0}};assert(atc_geometry::pose(pose));
 pose.q[0]=0;assert(!atc_geometry::pose(pose));pose.q[0]=std::numeric_limits<float>::quiet_NaN();assert(!atc_geometry::pose(pose));
 assert(!atc_geometry::local({0,0,std::numeric_limits<float>::infinity()}));
 std::puts("PASS: snapshot reads, count/capacity bounds, unreadable payload, pointer overflow, changing metadata, position and quaternion plausibility");
}
