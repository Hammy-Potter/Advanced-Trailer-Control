#include <vector>
#include <string>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cassert>
#include <cmath>
#include <algorithm>
#include "../main/Advanced-Trailer-Control/geometry_snapshot.h"
using SIZE_T=size_t;
namespace prism {struct game_trailer_actor_u {char pad[0x30]{};void* object=nullptr;float steering=0;char tail[0x684]{};uintptr_t data=0;};}
struct Physics {uintptr_t* vt;atc_geometry::Pose pose;};
void getter(void*o,void*out){std::memcpy(out,&((Physics*)o)->pose,sizeof(atc_geometry::Pose));}
void* GetModuleHandleW(void*){return (void*)((uintptr_t)getter-0x166f5d0);}
int table_reads=0;
bool ReadProcessMemory(void*,const void*src,void*dst,size_t n,SIZE_T*got){if(n==1414*sizeof(float))++table_reads;std::memcpy(dst,src,n);*got=n;return true;}
void* GetCurrentProcess(){return nullptr;}
uint64_t clock_tick=1000;
uint64_t GetTickCount64(){return clock_tick;}
void scs_log(int,const char*,...){}
bool multi_module_mode=false,locked=false,temp=false;
std::vector<prism::game_trailer_actor_u*> chain;
auto get_trailer_chain(){return chain;}
prism::game_trailer_actor_u* locked_actor=nullptr;
bool isTrailerLocked(prism::game_trailer_actor_u* a){return locked||a==locked_actor;}
bool isTrailerTempLocked(prism::game_trailer_actor_u*){return temp;}
bool exe_supported=true;bool geometry_exe(){return exe_supported;}
#include "joint_mock.inc"
#include "../main/Advanced-Trailer-Control/bridge_mode.inc"

template<class T>void put(char* p,size_t offset,T value){std::memcpy(p+offset,&value,sizeof value);}
void yaw(Physics& p,double degrees){p.pose.q[0]=float(std::cos(degrees/2/57.29577951308232));p.pose.q[2]=float(std::sin(degrees/2/57.29577951308232));}
int main(){
 static_assert(offsetof(prism::game_trailer_actor_u,data)==0x6c0);
 uintptr_t vt[40]{};vt[0x130/8]=(uintptr_t)getter;Physics phys[3]{};prism::game_trailer_actor_u actors[3];
 for(size_t i=0;i<3;++i){phys[i].vt=vt;phys[i].pose.q[0]=1;actors[i].object=&phys[i];chain.push_back(&actors[i]);}
 char data[512]{};actors[2].data=uintptr_t(data);
 std::vector<float> table(1414),out(14,.0123f),common(7,.01f);std::vector<uint64_t> map(14);std::vector<int32_t> groups{2,3,4,5,6,7,8};
 const float negative[]={-42.7161522f,-50.f,-31.3752537f,-45.1903229f,-16.0569248f,-25.4138298f,1.6785647f,2.7695849f,18.9198704f,29.5024853f,33.6141739f,47.6579895f,44.7233353f,50.f};
 const float positive[]={50.f,42.7161522f,45.1903229f,31.3752537f,25.4138298f,16.0569248f,-2.7695849f,-1.6785647f,-29.5024853f,-18.9198704f,-47.6579895f,-33.6141739f,-50.f,-44.7233353f};
 for(size_t i=0;i<14;++i){map[i]=i;table[i*101]=negative[i];table[i*101+100]=positive[i];}
 auto arr=[](const auto& v){return atc_geometry::Array{0,uintptr_t(v.data()),v.size(),v.size()};};
 put(data,0,arr(table));put(data,0x28,50);put(data,0x30,arr(out));put(data,0xa0,arr(map));put(data,0x168,3.9374909f);
 char* a=reinterpret_cast<char*>(&actors[2]);put(a,0x3d8,arr(common));put(a,0x430,arr(groups));
 const auto original_table=table,original_out=out,original_common=common;
 float target=99;assert(mwt_matches(chain));const int initial_reads=table_reads;for(int i=0;i<100;++i)assert(mwt_matches(chain));assert(table_reads==initial_reads);assert(!bridge_target(&actors[2],target));
 mwt_mode=true;assert(bridge_target(&actors[2],target)&&target==0);assert(!bridge_target(&actors[1],target));assert(!bridge_basic_follower(2));
 assert(bridge_manual_sign(&actors[2])==-1&&bridge_manual_sign(&actors[0])==1);
 for(int i=0;i<80;++i){clock_tick+=100;phys[2].pose.z-=.1f;assert(bridge_target(&actors[2],target));}
 yaw(phys[0],30);assert(bridge_target(&actors[2],target)&&target<0&&target>=-.25f);
 yaw(phys[2],-18);assert(bridge_target(&actors[2],target)&&std::abs(target)<1e-5);
 // Mirror turns and use relative tower angles, rather than absolute world yaw.
 yaw(phys[0],-30);yaw(phys[2],18);assert(bridge_target(&actors[2],target)&&std::abs(target)<1e-5);
 yaw(phys[1],40);yaw(phys[0],10);yaw(phys[2],58);assert(bridge_target(&actors[2],target)&&std::abs(target)<1e-5);
 yaw(phys[2],40);assert(bridge_target(&actors[2],target)&&target>0&&target<=.25f);
 bridge_manual_input(&actors[2],-.4f);assert(bridge_target(&actors[2],target)&&target==-.4f);
 yaw(phys[2],52);clock_tick+=121;assert(bridge_target(&actors[2],target)&&std::abs(target)<1e-5&&bridge_hold.held);assert(std::abs(bridge_hold.angle-12)<.001);
 yaw(phys[0],40);assert(bridge_target(&actors[2],target)&&std::abs(target)<1e-5);
 yaw(phys[2],54);assert(bridge_target(&actors[2],target)&&target<0);bridge_auto_input(&actors[2]);assert(!bridge_hold.held);
 yaw(phys[0],10);yaw(phys[1],0);yaw(phys[2],0);bridge_hold.travel={};bridge_auto_input(&actors[2]);
 for(int i=0;i<120;++i){clock_tick+=16;phys[2].pose.z-=.01f;assert(bridge_target(&actors[2],target));}
 assert(target<0&&bridge_hold.travel.direction==1);
 for(int i=0;i<120;++i){clock_tick+=16;phys[2].pose.z+=.01f;assert(bridge_target(&actors[2],target));}
 assert(target==0&&bridge_hold.travel.direction==-1&&reverse_joint.owned);
 // Fingerprint changes fail closed; this mode never rewrites axle output/table/common arrays.
 clock_tick+=501;exe_supported=false;assert(!mwt_matches(chain));exe_supported=true;clock_tick+=501;
 clock_tick+=501;table[0]+=1;assert(!bridge_target(&actors[2],target));assert(bridge_manual_sign(&actors[2])==1);table[0]-=1;clock_tick+=501;
 clock_tick+=501;map[1]=0;assert(!mwt_matches(chain));map[1]=1;clock_tick+=501;
 clock_tick+=501;groups[6]=9;assert(!mwt_matches(chain));groups[6]=8;clock_tick+=501;
 clock_tick+=501;put(data,0x28,60);assert(!mwt_matches(chain));put(data,0x28,50);clock_tick+=501;
 yaw(phys[0],130);assert(!bridge_target(&actors[2],target));yaw(phys[0],40);
 multi_module_mode=true;assert(!bridge_target(&actors[2],target));multi_module_mode=false;
 mwt_mode=false;bridge_mode=true;assert(!bridge_target(&actors[2],target));bridge_mode=false;mwt_mode=true;
 chain.pop_back();assert(!bridge_target(&actors[1],target));chain.push_back(&actors[2]);
 assert(table==original_table&&out==original_out&&common==original_common);
 puts("PASS: MWT three-section routing, both turn directions, relative tower frame, 0.6 target, bounded demand, manual release/hold/Auto, profile/map/group/chain/mode/pose guards; native axle data unchanged");
}
