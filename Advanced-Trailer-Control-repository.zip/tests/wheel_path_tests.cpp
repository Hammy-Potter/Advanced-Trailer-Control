#include "../main/Advanced-Trailer-Control/wheel_path.h"
#include <cassert>
#include <cstdio>
#include <fstream>
#include <sstream>
atc_geometry::Pose pose(float x,float z,double yaw=0){return {x,0,z,0,0,{float(std::cos(yaw/2)),0,float(std::sin(yaw/2)),0}};}
int main(int argc,char**argv){
 wheel_path::State s{};auto a=pose(0,0),b=pose(0,0);
 assert(!wheel_path::sample(s,a,b,1000).valid);
 a=pose(0,-.2f);assert(wheel_path::sample(s,a,b,1100).valid);for(auto x:s.offsets)assert(std::abs(x)<1e-8);
 // Diagonal forward movement: wheel yaw turns towards travel; fixed input is irrelevant.
 for(int i=2;i<25;++i){a=pose(.02f*(i-1),-.2f*i);assert(wheel_path::sample(s,a,b,1000+i*100).valid);}
 assert(s.offsets[0]<-.08&&s.offsets[0]>-.11);
 const auto held=s.offsets;
 for(int i=0;i<30;++i)wheel_path::sample(s,a,b,3500+i*100);
 assert(std::abs(s.offsets[0])<std::abs(held[0])*.01);
 a.sector_x=1;assert(!wheel_path::sample(s,a,b,6600).valid);for(auto x:s.offsets)assert(x==0);
 a=pose(0,0);s={};wheel_path::sample(s,a,b,1000);a.z=.2f;assert(!wheel_path::sample(s,a,b,1100).valid); // reverse fade
 a.q[0]=100;assert(!wheel_path::sample(s,a,b,1200).valid&&!s.ready);
 // Replay the user's two full traces against the actual controller maths.
 if(argc>1){std::ifstream file(argv[1]);assert(file);std::string line;int prior=-1,count=0,valid=0;double lo=0,hi=0;
  while(std::getline(file,line)){
   std::replace(line.begin(),line.end(),',',' ');std::istringstream in(line);int c;uint64_t t;atc_geometry::Pose ap{},bp{};
   in>>c>>t>>ap.x>>ap.y>>ap.z>>ap.sector_x>>ap.sector_z;for(float& q:ap.q)in>>q;
   in>>bp.x>>bp.y>>bp.z>>bp.sector_x>>bp.sector_z;for(float&q:bp.q)in>>q;assert(in);
   if(c!=prior){s={};prior=c;}auto r=wheel_path::sample(s,ap,bp,t+1000);++count;valid+=r.valid;
   for(double x:s.offsets){assert(std::isfinite(x)&&std::abs(x)<=25*wheel_path::rad);lo=std::min(lo,x);hi=std::max(hi,x);}
  }
  assert(count>350&&valid>300&&lo<-.005&&hi>.005);
  printf("Replay: %d samples, %d forward-valid, smoothed wheel offsets %.3f..%.3f deg\n",count,valid,lo/wheel_path::rad,hi/wheel_path::rad);
 }
 puts("PASS: forward path, stationary/reverse fade, history and pose guards, replay bounds and direction changes");
}
