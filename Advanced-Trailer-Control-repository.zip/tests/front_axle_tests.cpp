#include <cassert>
#include <cstdio>
#include "../main/Advanced-Trailer-Control/front_axle_math.h"
int main(){
 for(double deg:{-60.,-30.,0.,30.,60.}){
  const double b=deg*front_axle::rad;
  for(size_t row=4;row<8;++row)assert(front_axle::angle(row,b,27.7040977)==0);
  for(size_t row=0;row<4;++row){
   const double a=front_axle::angle(row,b,27.7040977);
   assert(std::abs(a)<=25*front_axle::rad);
   assert(std::abs(a+front_axle::angle(row^1,-b,27.7040977))<1e-6);
   if(deg==0)assert(a==0);
   else assert(a*b>0); // retain previous steady-state sign
  }
 }
 const double b=30*front_axle::rad;
 assert(std::abs(front_axle::angle(0,b,27.7040977))>std::abs(front_axle::angle(2,b,27.7040977)));
 assert(std::abs(front_axle::angle(0,b,27.7040977))>std::abs(front_axle::angle(0,b/2,27.7040977)));
 assert(front_axle::angle(0,b,0)==0);
 puts("PASS: bogie-angle curve estimate, mirrored turns, per-axle geometry, centre return, rear rows unchanged, bounded angles");
}
