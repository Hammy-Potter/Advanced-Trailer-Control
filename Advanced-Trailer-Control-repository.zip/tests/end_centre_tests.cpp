#include "../main/Advanced-Trailer-Control/end_centre_math.h"
#include <cassert>
#include <cstdio>
#include <limits>
using namespace end_centre;
struct Fixture {std::vector<float> samples;std::vector<uint64_t> map;int steps=51;double lever=8;size_t rows=0;};
Fixture fixture(std::vector<double> lines,bool reverse=false){
 Fixture f;f.rows=lines.size()*2;const size_t stride=2*f.steps+1;f.samples.resize(f.rows*stride);
 for(size_t i=0;i<f.rows;++i){f.map.push_back(i);const double x=i%2?.96:-.96,z=lines[i/2];
  for(int k=-f.steps;k<=f.steps;++k){const double a=k?std::atan(z/(f.lever/std::tan(k*rad)-x)):0;
   f.samples[i*stride+f.steps+k]=float(a/rad*(reverse?-1:1));}
 }return f;
}
Module load(const Fixture&f,bool reverse=false){Module m;std::string why;const bool ok=recover(f.samples,f.rows,f.steps,f.map,f.lever,reverse,m,why);if(!ok)std::printf("Unexpected rejection: %s\n",why.c_str());assert(ok);return m;}
int main(){
 for(const auto& a:std::vector<std::vector<double>>{{-7.3,-5.7,-4.1,-2.5,-.9,.7,2.58,4.18,5.77,7.39},{-4.7,-3.1,-1.5,.1,1.7,3.3,4.9},{-2.4,-.8,.8,2.4}}){
  for(const auto& b:std::vector<std::vector<double>>{{-7.3,-5.7,-4.1,-2.5,-.9,.7,2.58,4.18,5.77,7.39},{-4.8,-3.2,-1.6,0,1.6,3.2,4.8},{-4,-2.4,-.8,.8,2.4,4},{-5.6,-4,-2.4,-.8,.8,2.4,4,5.6},{-1.6,0,1.6}}){
   auto front=load(fixture(a)),rear=load(fixture(b));
   for(size_t i=0;i<a.size();++i)assert(std::abs(front.wheels[2*i].z-a[i])<.0001);
   relocate(front,true);relocate(rear,false);
   assert(std::abs(front.centre-a.back()-0.7)<.0001);assert(std::abs(rear.centre-b.front()+0.7)<.0001);
   const double maxk=maximum_curvature(front,rear);
   for(double u:{-1.,-.25,0.,.25,1.})for(const Module*m:{&front,&rear})for(const auto&w:m->wheels){
    const double angle=wheel_angle(w,*m,u*maxk);assert(std::isfinite(angle)&&std::abs(angle)<=m->limit+.0001);
    if(u>0)assert(m==&front?angle<0:angle>0);
    if(u==0)assert(angle==0);
   }
  }
 }
 auto f=fixture({-2.4,-.8,.8,2.4},true);auto m=load(f,true);assert(std::abs(m.wheels[0].z+2.4)<.0001);
 // Native output row order may differ from physical wheel order.
 f=fixture({-2.4,-.8,.8,2.4});const size_t stride=2*f.steps+1;
 for(size_t row=0;row<f.rows/2;++row)for(size_t k=0;k<stride;++k)std::swap(f.samples[row*stride+k],f.samples[(f.rows-1-row)*stride+k]);
 for(size_t i=0;i<f.map.size();++i)f.map[i]=f.rows-1-i;
 m=load(f);assert(std::abs(m.wheels[0].z+2.4)<.0001);
 std::string why;
 f=fixture({-2.4,-.8,.8,2.4});f.samples[51+17]+=2;assert(!recover(f.samples,f.rows,f.steps,f.map,f.lever,false,m,why));
 f=fixture({-2.4,-.8,.8,2.4});f.map[0]=UINT64_MAX;assert(!recover(f.samples,f.rows,f.steps,f.map,f.lever,false,m,why));
 f=fixture({-2.4,-.8,.8,2.4});assert(!recover(f.samples,f.rows,f.steps,f.map,0,false,m,why));
 f.samples[51+15]=std::numeric_limits<float>::quiet_NaN();assert(!recover(f.samples,f.rows,f.steps,f.map,8,false,m,why));
 std::puts("PASS: uneven/unequal layouts, 14/16/20-line component counts, odd centre axle, table inversion, row permutation, 0.7m extension, opposite directions, angle limits, corrupt fit rejection, missing map and zero reference rejection");
}
