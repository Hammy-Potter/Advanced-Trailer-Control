# Advanced Trailer Control — Test 7: reverse joint hold

Experimental Windows x64 build for the supplied ETS2 1.61.1.9 executable. Applies to MWT Mode, Bridge Mode and Bridge Mode - Expert.

## Behaviour

When backward motion is first detected, the controller attempts to capture the rear bogie's current articulation using the actual PhysX joint. It changes only the verified near-vertical twist/yaw constraint, rebasing the joint's angular reference before locking it so that the requested lock is at the current angle rather than the original straight position. The local joint anchor position is preserved. Other joint axes retain their existing settings.

While held, MWT's seven axles continue movement-based following, without the unsuccessful reverse articulation-feedback correction. Both bridge modes use the game's native wheel-steering calculation while their rear articulation is constrained. Native wheel following under a locked bridge joint still needs in-game checking.

Active rear manual input temporarily releases the owned lock so the driver can change the angle. When that input expires, reverse joint hold can capture the new angle. Basic Bridge Mode's shared control follows the same rule. An already locked joint is respected rather than unlocked by this feature.

First detected forward movement releases the owned reverse hold and restores the original joint frame and angular motion setting. Changing modes or disabling the mode also attempts restoration, as does plugin shutdown while the same joint is still accessible. A stopped combination retains its reverse hold until forward travel or active manual input. Auto alone does not release a reverse joint hold while still reversing.

No new reverse toggle is added. The separate proposal to change manual persistence is still deferred; manual release-to-hold remains otherwise unchanged.

## Validation before changing a joint

The implementation accepts only the exact supplied EXE metadata, expected D6 joint vtable and the verified local-pose, relative-transform and motion methods. The native actor/joint wrapper chain is checked. Local and relative transforms must be finite and plausible; the twist axis must be near vertical, and the captured twist must be within 80 degrees.

The function signatures and 28-byte PxTransform layout were checked in the supplied executable. In particular, setLocalPose is slot 7, getLocalPose slot 8, relative transform slot 9, and motion setter/getter slots 29/30 of the verified D6 vtable. Frame orientation is read back before locking. An unsuccessful frame write must not proceed to lock.

Unknown joints or invalid axes are not modified. Diagnostics report 'Reverse joint hold unavailable' and capture the relevant joint metadata instead of resuming Test 6's unsuccessful reverse feedback. Restoration is attempted only for the same live joint and the frame owned by this feature; unrelated or replaced constraints are not written.

This changes an actual physics constraint, unlike the previous steering-only attempts. The game's constraint solver may still permit small positional/angular errors. Local mocked tests do not prove in-game solver stability.

## UI changes

- Removed the Reverse bridge correction checkbox.
- Alphabetical mode order: BBM, Bridge, Bridge - Expert, Multi-Module, MWT.

## Install and first test

Close ETS2 and back up Test 5 or the latest working DLL. Replace Advanced-Trailer-Control.dll in bin/win_x64/plugins. Keep only one ATC DLL installed. No EXE program, remote add-on, model edits or def changes are needed.

Start with a short, gentle reverse from a modest angle. Diagnostics should say 'Reverse joint hold'. Check that the rear keeps its angle relative to the tower/bridge while the axles steer. Then drive forwards and confirm the joint releases. Try a brief manual input while reversing, release it, and confirm the new angle is held. Repeat for MWT and both bridge modes.

If the lock is unavailable, starts to pull the combination unexpectedly, or does not release, stop the vehicle and disable the selected mode. Capture the geometry/log details and send game.log.txt with observations; a close-up clip is helpful for wheel behaviour. This build is a physical-joint experiment, not a release-ready guarantee of reversing stability.

## Local checks

Windows x64 Release cross-build passed. Tests cover current-angle rebasing, unchanged anchor, idempotent locking, restoration of free/limited motion, existing external locks, axis rejection, rejected pose/lock writes and stale-joint refusal. Actual bridge controller fixtures cover both bridge modes' reverse hold, manual release/relock and forward restoration. MWT, wheel/model alignment, smoothing, hook pipeline and BBM regression tests passed.

No ETS2 session was available locally. In-game joint-frame conventions, solver behaviour, axle tracking under constraint and restoration still require the tests above. Earlier test notes included with the source are historical; this file describes the current DLL.
