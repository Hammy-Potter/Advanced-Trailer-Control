#pragma once

namespace dllmain
{
    bool is_initialized();
	void render_tick();
	void main_tick();
}