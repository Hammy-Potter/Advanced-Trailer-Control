#pragma once
#include "geometry_snapshot.h"
#include <array>
namespace mwt {
// Fingerprint from captures 3/4 of the supplied three-section MWT combination.
// Read only. Retain all seven native axle groups and all native steering rows.
template<class Reader> bool rear_profile(Reader read,uintptr_t actor,uintptr_t data){
 int steps=0;float lever=0;uint8_t inverted=0;
 if(!data||!read(data+0x28,&steps,sizeof steps)||steps!=50
  ||!read(data+0x168,&lever,sizeof lever)||!std::isfinite(lever)||std::abs(lever-3.9374909f)>.002f
  ||!read(data+0x16c,&inverted,1)||inverted)return false;
 std::vector<uint64_t> map;std::vector<float> table,out,common;std::vector<int32_t> groups;
 if(!atc_geometry::array(read,data+0xa0,map,14)||map.size()!=14
  ||!atc_geometry::array(read,data,table,1414)||table.size()!=1414
  ||!atc_geometry::array(read,data+0x30,out,14)||out.size()!=14
  ||!atc_geometry::array(read,actor+0x3d8,common,7)||common.size()!=7
  ||!atc_geometry::array(read,actor+0x430,groups,7)||groups.size()!=7)return false;
 constexpr std::array<float,14> neg{{-42.7161522f,-50.f,-31.3752537f,-45.1903229f,-16.0569248f,-25.4138298f,1.6785647f,2.7695849f,18.9198704f,29.5024853f,33.6141739f,47.6579895f,44.7233353f,50.f}};
 constexpr std::array<float,14> pos{{50.f,42.7161522f,45.1903229f,31.3752537f,25.4138298f,16.0569248f,-2.7695849f,-1.6785647f,-29.5024853f,-18.9198704f,-47.6579895f,-33.6141739f,-50.f,-44.7233353f}};
 for(size_t i=0;i<14;++i){
  if(map[i]!=i||!std::isfinite(out[i])||std::abs(out[i])>1.5708f
   ||!std::isfinite(table[i*101])||!std::isfinite(table[i*101+100])
   ||std::abs(table[i*101]-neg[i])>.002f||std::abs(table[i*101+100]-pos[i])>.002f)return false;
 }
 for(size_t i=0;i<7;++i)if(groups[i]!=int(i+2)||!std::isfinite(common[i])||std::abs(common[i])>1.5708f)return false;
 return true;
}
}
