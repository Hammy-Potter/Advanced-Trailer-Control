﻿#include "dllmain.h"

#include <windows.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <chrono>
#include <cstddef>
#include <fstream>
#include <thread>
#include <mutex>
#include <atomic>
#include <cstring>
#include "response_math.h"
#include "remote_contract.h"
#include "runtime_mode.h"

#include "scs_sdk/scssdk_telemetry.h"
#include "rendering.h"
#include "imgui/imgui.h"

#include "globals.h"
#include "bmem.h"
#include "scs_logging.h"
#include "prism/prism.h"

#include "launch_arguments_manager.h"

#include "direct_input_manager.h"
#include <unordered_map>

#include "nlohmann/json.hpp"
using json = nlohmann::json;

#pragma comment(lib, "../Lib/minhook.x64.lib")

using namespace scs_logging;

RenderManager* renderer = nullptr;
std::atomic<bool> plugin_initialization_complete{false};
bool dllmain::is_initialized(){return plugin_initialization_complete.load(std::memory_order_acquire);}


std::vector<prism::game_trailer_actor_u*> locked_trailers;
std::vector<prism::game_trailer_actor_u*> temp_locked_trailers;

bool transparent_ui = false;
bool last_transparent_ui = false;
// Separate experimental branch: native geometry remains responsible for axle angles.
float bridge_manual_sign(prism::game_trailer_actor_u* actor);
extern bool bridge_mode, bridge_basic_mode, mwt_mode;
bool bridge_basic_follower(size_t index);
void bridge_manual_input(prism::game_trailer_actor_u*,float);
void bridge_auto_input(prism::game_trailer_actor_u*);
bool bridge_manual_base(prism::game_trailer_actor_u*,float&);
void bridge_sync();
extern std::string bridge_status;
bool multi_module_mode = false, last_multi_module_mode = false;
int multi_module_leader = 0, last_multi_module_leader = 0;
float steering_seconds = 5.0f;
float last_steering_seconds = 5.0f;
float suspension_seconds = 5.0f;
float last_suspension_seconds = 5.0f;
std::mutex response_mutex;
struct ManualTarget { prism::steering_data_t* data; float target; };
std::unordered_map<prism::game_trailer_actor_u*, ManualTarget> manual_targets;
std::atomic<bool> crab_enabled{false};
std::atomic<uint32_t> crab_members{0};
std::atomic<uint32_t> crab_reversed{0};
std::atomic<float> crab_command{0.0f};
bool crab_supported = false;
int crab_control_trailer = 0;
struct CrabTable { uintptr_t data, output, samples; uint64_t count, sample_count; int steps;
    std::array<bool, 40> steerable{}; float lock_radians = 0; };
std::unordered_map<prism::game_trailer_actor_u*, CrabTable> crab_tables;


uintptr_t game_ctrl_ptr;
uint32_t game_actor_offset;

// This build maps the attached-trailer actor layout in ETS2 1.61.1.9.
// Checked at startup against the scanned steering function before hooks/writes.
bool trailer_layout_verified = false;
constexpr size_t MAX_TRAILER_CHAIN = 16;
constexpr uintptr_t FIRST_TRAILER_OFFSET = 0xC8;

bool readable_memory(const void* address, size_t size)
{
    uintptr_t cursor = reinterpret_cast<uintptr_t>(address);
    if (!cursor || size > UINTPTR_MAX - cursor)
        return false;
    const uintptr_t end = cursor + size;
    while (cursor < end)
    {
        MEMORY_BASIC_INFORMATION region = {};
        if (!VirtualQuery(reinterpret_cast<const void*>(cursor), &region, sizeof(region))
            || region.State != MEM_COMMIT || (region.Protect & (PAGE_GUARD | PAGE_NOACCESS)))
            return false;
        const DWORD access = region.Protect & 0xFF;
        if (access != PAGE_READONLY && access != PAGE_READWRITE && access != PAGE_WRITECOPY
            && access != PAGE_EXECUTE_READ && access != PAGE_EXECUTE_READWRITE
            && access != PAGE_EXECUTE_WRITECOPY)
            return false;
        const uintptr_t next = reinterpret_cast<uintptr_t>(region.BaseAddress) + region.RegionSize;
        if (next <= cursor)
            return false;
        cursor = next;
    }
    return true;
}

float manual_target(prism::game_trailer_actor_u* actor)
{
    float base=0;if(bridge_manual_base(actor,base))return base;
    std::lock_guard<std::mutex> lock(response_mutex);
    auto it = manual_targets.find(actor);
    return it != manual_targets.end() && it->second.data == actor->steering_data ? it->second.target : actor->steering;
}
void set_manual_target(prism::game_trailer_actor_u* actor, float value)
{
    if (!std::isfinite(value)) return;
    bridge_manual_input(actor,value);
    std::lock_guard<std::mutex> lock(response_mutex);
    manual_targets[actor] = {actor->steering_data, std::clamp(value, -1.0f, 1.0f)};
}
bool read_crab_table(prism::steering_data_t* data, CrabTable& out)
{
    const uintptr_t base = reinterpret_cast<uintptr_t>(data);
    if (!readable_memory(data, 0x50)) return false;
    auto read64 = [base](size_t offset) { uint64_t v; std::memcpy(&v, reinterpret_cast<void*>(base + offset), 8); return v; };
    out = {}; out.data = base; out.samples = read64(8); out.sample_count = read64(0x10);
    out.output = read64(0x38); out.count = read64(0x40);
    std::memcpy(&out.steps, reinterpret_cast<void*>(base + 0x28), 4);
    if (out.steps < 2 || out.steps > 4096 || !out.count || out.count > 40) return false;
    const uint64_t stride = uint64_t(out.steps) * 2 + 1;
    if (out.sample_count < stride * out.count || out.sample_count > 1000000
        || !readable_memory(reinterpret_cast<void*>(out.samples), size_t(stride * out.count * sizeof(float)))
        || !readable_memory(reinterpret_cast<void*>(out.output), size_t(out.count * sizeof(float)))) return false;
    return response_math::crab_limits(reinterpret_cast<const float*>(out.samples), out.sample_count,
        out.count, out.steps, out.steerable.data(), out.lock_radians);
}
void parallel_outputs(const CrabTable& table, float angle)
{
    if (!readable_memory(reinterpret_cast<void*>(table.data), 0x50)
        || !readable_memory(reinterpret_cast<void*>(table.output), size_t(table.count * 4))) return;
    uintptr_t output = 0; uint64_t count = 0;
    std::memcpy(&output, reinterpret_cast<void*>(table.data + 0x38), 8);
    std::memcpy(&count, reinterpret_cast<void*>(table.data + 0x40), 8);
    if (output != table.output || count != table.count) return;
    auto values = reinterpret_cast<float*>(table.output);
    response_math::parallel_angles(values, table.steerable.data(), table.count, angle);
    // Crab motion has no single turning radius; prevent a stale conventional radius being reused.
    if (readable_memory(reinterpret_cast<void*>(table.data + 0x160), sizeof(float)))
        *reinterpret_cast<float*>(table.data + 0x160) = 0.0f;
}

std::vector<prism::game_trailer_actor_u*> get_trailer_chain()
{
    std::vector<prism::game_trailer_actor_u*> trailers;
    if (!trailer_layout_verified
        || !readable_memory(reinterpret_cast<void*>(game_ctrl_ptr), sizeof(void*)))
        return trailers;
    auto ctrl = *reinterpret_cast<uint8_t**>(game_ctrl_ptr);
    if (!ctrl || !readable_memory(ctrl + game_actor_offset, sizeof(void*)))
        return trailers;
    auto actor = *reinterpret_cast<uint8_t**>(ctrl + game_actor_offset);
    if (!actor || !readable_memory(actor + FIRST_TRAILER_OFFSET, sizeof(void*)))
        return trailers;
    auto trailer = *reinterpret_cast<prism::game_trailer_actor_u**>(actor + FIRST_TRAILER_OFFSET);
    while (trailer && trailers.size() < MAX_TRAILER_CHAIN)
    {
        if (!readable_memory(trailer, sizeof(*trailer))
            || std::find(trailers.begin(), trailers.end(), trailer) != trailers.end())
            break;
        trailers.push_back(trailer);
        trailer = trailer->slave;
    }
    return trailers;
}

void log_trailer_chain(const std::vector<prism::game_trailer_actor_u*>& trailers)
{
    static std::vector<prism::game_trailer_actor_u*> previous;
    static bool first = true;
    if (!first && trailers == previous)
        return;
    first = false;
    previous = trailers;
    scs_log(0, "[chain] Detected %u attached trailer(s); root offset=0xC8, next=0x1088",
        static_cast<unsigned>(trailers.size()));
    for (size_t i = 0; i < trailers.size(); ++i)
    {
        auto t = trailers[i];
        scs_log(0, "[chain] Trailer %u actor=%p next=%p steering_data=%p height=(%.4f, %.4f)",
            static_cast<unsigned>(i + 1), static_cast<void*>(t), static_cast<void*>(t->slave),
            static_cast<void*>(t->steering_data), t->suspention_height, t->suspension_height_other);
    }
}

struct suspension_readback_t
{
    prism::game_trailer_actor_u* actor;
    int trailer_number;
    float requested;
    ULONGLONG due;
};
std::vector<suspension_readback_t> suspension_readbacks;

void queue_suspension_readback(prism::game_trailer_actor_u* actor, int number, float requested)
{
    suspension_readbacks.erase(std::remove_if(suspension_readbacks.begin(), suspension_readbacks.end(),
        [actor](const suspension_readback_t& item) { return item.actor == actor; }), suspension_readbacks.end());
    suspension_readbacks.push_back({ actor, number, requested, GetTickCount64() + 500 });
}

void log_suspension_readbacks(const std::vector<prism::game_trailer_actor_u*>& trailers)
{
    const auto now = GetTickCount64();
    suspension_readbacks.erase(std::remove_if(suspension_readbacks.begin(), suspension_readbacks.end(),
        [&](const suspension_readback_t& item)
        {
            if (std::find(trailers.begin(), trailers.end(), item.actor) == trailers.end())
                return true;
            if (now < item.due)
                return false;
            scs_log(0, "[suspension] Delayed readback Trailer %d actor=%p requested=%.4f actual=(%.4f, %.4f)",
                item.trailer_number, static_cast<void*>(item.actor), item.requested,
                item.actor->suspention_height, item.actor->suspension_height_other);
            return true;
        }), suspension_readbacks.end());
}

bool is_fatal_error = false;
std::string error = "";

bool running_truckersmp = false;
bool shown_truckersmp_warning = false;

void SetupImGuiStyle()
{
    ImGui::StyleColorsDark();
    auto& style = ImGui::GetStyle();
    style.WindowPadding = ImVec2(12, 10);
    style.FramePadding = ImVec2(8, 4);
    style.ItemSpacing = ImVec2(8, 6);
    style.ItemInnerSpacing = ImVec2(6, 4);
    style.WindowRounding = 10;
    style.ChildRounding = 8;
    style.FrameRounding = 5;
    style.PopupRounding = 6;
    style.TabRounding = 5;
    style.GrabRounding = 4;
    style.WindowBorderSize = 1;
    style.FrameBorderSize = 0;
    style.ScrollbarSize = 12;
    auto* c = style.Colors;
    c[ImGuiCol_Text] = ImVec4(.91f, .94f, .97f, 1);
    c[ImGuiCol_TextDisabled] = ImVec4(.53f, .60f, .68f, 1);
    c[ImGuiCol_WindowBg] = ImVec4(.055f, .071f, .090f, .98f);
    c[ImGuiCol_ChildBg] = ImVec4(.085f, .106f, .130f, 1);
    c[ImGuiCol_PopupBg] = ImVec4(.085f, .106f, .130f, 1);
    c[ImGuiCol_Border] = ImVec4(.17f, .21f, .26f, 1);
    c[ImGuiCol_FrameBg] = ImVec4(.12f, .15f, .19f, 1);
    c[ImGuiCol_FrameBgHovered] = ImVec4(.18f, .22f, .27f, 1);
    c[ImGuiCol_FrameBgActive] = ImVec4(.22f, .27f, .32f, 1);
    c[ImGuiCol_TitleBg] = c[ImGuiCol_TitleBgActive] = ImVec4(.055f, .071f, .090f, 1);
    c[ImGuiCol_Button] = ImVec4(.16f, .20f, .25f, 1);
    c[ImGuiCol_ButtonHovered] = ImVec4(.24f, .29f, .35f, 1);
    c[ImGuiCol_ButtonActive] = ImVec4(.31f, .36f, .42f, 1);
    c[ImGuiCol_Header] = ImVec4(.12f, .15f, .19f, 1);
    c[ImGuiCol_HeaderHovered] = ImVec4(.18f, .22f, .27f, 1);
    c[ImGuiCol_HeaderActive] = ImVec4(.22f, .27f, .32f, 1);
    c[ImGuiCol_CheckMark] = c[ImGuiCol_SliderGrab] = ImVec4(1.0f, .63f, .30f, 1);
    c[ImGuiCol_SliderGrabActive] = ImVec4(1.0f, .76f, .48f, 1);
    c[ImGuiCol_Tab] = ImVec4(.085f, .106f, .130f, 1);
    c[ImGuiCol_TabHovered] = ImVec4(.25f, .28f, .31f, 1);
    c[ImGuiCol_TabSelected] = ImVec4(.22f, .25f, .28f, 1);
    c[ImGuiCol_TabSelectedOverline] = ImVec4(1.0f, .63f, .30f, 1);
    c[ImGuiCol_Separator] = ImVec4(.17f, .21f, .26f, 1);
}

bool isTrailerLocked(prism::game_trailer_actor_u* trailer)
{
    for (prism::game_trailer_actor_u* locked_trailer : locked_trailers) {
        if (locked_trailer == trailer)
            return true;
    }

    return false;
}

bool isTrailerTempLocked(prism::game_trailer_actor_u* trailer)
{
    for (prism::game_trailer_actor_u* temp_locked_trailer : temp_locked_trailers) {
        if (temp_locked_trailer == trailer)
            return true;
    }

    return false;
}


bool isTrailerSteerable(prism::game_trailer_actor_u* trailer)
{
    return trailer->steering_data != nullptr;
}

void render_error(std::string message) {
    ImGui::TextColored(ImVec4(1.f, 0.f, 0.f, 1.f), message.c_str());
}

void render_fatal(std::string message) {
    render_error("A fatal error has occured within this plugin!");
    ImGui::TextWrapped("Please make sure your game is fully loaded!");

    ImGui::Spacing();
    ImGui::Spacing();
    ImGui::Spacing();


    ImGui::Spacing();
    ImGui::Spacing();
    ImGui::Spacing();

#ifdef _DEBUG
    if (ImGui::CollapsingHeader("Developer Information"))
    {
        render_error("Error: " + message);
        ImGui::Separator();

        uint8_t* game_ctrl = *(uint8_t**)game_ctrl_ptr;

        ImGui::TextWrapped("game_ctrl_ptr: %p", game_ctrl_ptr);
        ImGui::TextWrapped("game_ctrl: %p", game_ctrl);

        if (game_ctrl) {
            uint8_t* game_actor = *(uint8_t**)(game_ctrl + game_actor_offset);
            ImGui::TextWrapped("game_actor: %p", game_actor);

            if (game_actor) {
                uint8_t* trailer_actor = *(uint8_t**)(game_actor + 0xc0);
                ImGui::TextWrapped("trailer_actor: %p", trailer_actor);


            }
        }

        ImGui::TextWrapped("game_actor_offset: %d", game_actor_offset);
    }
#endif

    ImGui::EndTabItem();
}

BOOL CALLBACK EnumAxesCallback(const DIDEVICEOBJECTINSTANCE* pdidoi, VOID* pContext)
{
    auto* axisList = reinterpret_cast<std::vector<DIDEVICEOBJECTINSTANCE>*>(pContext);

    if (pdidoi->dwType & DIDFT_AXIS)
    {
        axisList->push_back(*pdidoi);
    }

    return DIENUM_CONTINUE;
}

struct input_device
{
    std::string name;
    LPDIRECTINPUTDEVICE8 di8_device;
    std::unordered_map<std::string, float> joystates;
    DIJOYSTATE2 joystate;
};
std::vector<input_device> input_devices;

int axis_device_index = -1; // the index in the array ^ of the device thats being used for steering
int last_axis_device_index = -1;

std::string steering_axis_name = "None";
std::string last_steering_axis_name = "None";

int steer_button_device_index = -1;
int last_steer_button_device_index = -1;
constexpr int KEYBOARD_DEVICE_INDEX = -2;

constexpr int CONTROLLED_TRAILER_COUNT = 4;
// Manual steering rate is now measured in seconds from centre to lock.

enum TrailerButtonControl
{
    STEER_LEFT = 0,
    STEER_RIGHT = 1,
    ENABLE_AUTOSTEER = 2,
    TRAILER_BUTTON_CONTROL_COUNT = 3
};

using trailer_button_bindings_t =
    std::array<std::array<std::string, TRAILER_BUTTON_CONTROL_COUNT>, CONTROLLED_TRAILER_COUNT>;

trailer_button_bindings_t trailer_button_names = [] {
    trailer_button_bindings_t bindings{};
    for (auto& trailer : bindings)
        trailer.fill("None");
    return bindings;
}();
trailer_button_bindings_t last_trailer_button_names = trailer_button_names;

int current_controlled_trailer = 0; // the trailer you are currently controlling
int last_current_controlled_trailer = 0;

bool use_axis_steering = false;
bool last_use_axis_steering = false;
bool use_button_steering = false;
bool last_use_button_steering = false;

std::string get_next_button_input(int device_index)
{
    if (device_index == KEYBOARD_DEVICE_INDEX)
    {
        for (int virtual_key = VK_BACK; virtual_key <= 0xFE; ++virtual_key)
            if ((GetAsyncKeyState(virtual_key) & 0x8000) != 0)
                return std::to_string(virtual_key);

        return "";
    }

    if (device_index < 0 || device_index >= (int)input_devices.size())
        return "";

    input_device& device = input_devices[device_index];

    for (int i = 0; i < 128; ++i)
        if (device.joystate.rgbButtons[i] & 0x80)
            return std::to_string(i);

    return "";
}

bool is_button_pressed(int device_index, const std::string& button_name)
{
    if (button_name == "None")
        return false;

    try
    {
        const int button_index = std::stoi(button_name);

        if (device_index == KEYBOARD_DEVICE_INDEX)
            return button_index >= VK_BACK && button_index <= 0xFE
                && (GetAsyncKeyState(button_index) & 0x8000) != 0;

        if (device_index < 0 || device_index >= (int)input_devices.size())
            return false;

        return button_index >= 0 && button_index < 128
            && (input_devices[device_index].joystate.rgbButtons[button_index] & 0x80) != 0;
    }
    catch (...)
    {
        return false;
    }
}

// Shared suspension controls always traverse the whole currently attached chain.
int suspension_device = KEYBOARD_DEVICE_INDEX;
int last_suspension_device = KEYBOARD_DEVICE_INDEX;
std::array<std::string, 3> suspension_buttons = { "None", "None", "None" };
std::array<std::string, 3> last_suspension_buttons = suspension_buttons;
int suspension_capture = -1;
bool suspension_wait_release = false;
struct SuspensionReturn
{
    float first;
    float other;
};
std::unordered_map<prism::game_trailer_actor_u*, SuspensionReturn> suspension_returns;
void write_suspension_height(prism::game_trailer_actor_u* actor, float first, float other)
{
    actor->suspention_height = std::clamp(first, 0.25f, 5.0f);
    actor->suspension_height_other = std::clamp(other, 0.25f, 5.0f);
    actor->suspension_dirty = 1;
}
void update_all_trailer_suspension(const std::vector<prism::game_trailer_actor_u*>& trailers)
{
    using Clock = std::chrono::steady_clock;
    static auto last_tick = Clock::now();
    const auto now = Clock::now();
    const float elapsed = std::chrono::duration<float>(now - last_tick).count();
    last_tick = now;
    const float dt = response_math::elapsed_step(elapsed);
    static auto previous_chain = trailers;
    static bool reset_was_down = false;
    if (trailers != previous_chain)
    {
        suspension_returns.clear();
        previous_chain = trailers;
    }
    const bool raise = is_button_pressed(suspension_device, suspension_buttons[0]);
    const bool lower = is_button_pressed(suspension_device, suspension_buttons[1]);
    const bool reset = is_button_pressed(suspension_device, suspension_buttons[2]);
    if (suspension_capture >= 0 || suspension_wait_release)
    {
        if (suspension_capture < 0 && !raise && !lower && !reset)
            suspension_wait_release = false;
        reset_was_down = reset;
        return;
    }
    if (raise || lower)
    {
        // Opposing buttons cancel each other and cancel any active reset.
        suspension_returns.clear();
        const float delta = response_math::suspension_delta(raise, lower, suspension_seconds, dt);
        if (delta != 0.0f)
            for (auto* actor : trailers)
                if (std::isfinite(actor->suspention_height) && std::isfinite(actor->suspension_height_other))
                    write_suspension_height(actor, actor->suspention_height + delta,
                        actor->suspension_height_other + delta);
    }
    else
    {
        if (reset && !reset_was_down)
        {
            suspension_returns.clear();
            for (auto* actor : trailers)
                if (std::isfinite(actor->suspention_height) && std::isfinite(actor->suspension_height_other))
                    suspension_returns[actor] = { 1.0f, 1.0f };
            scs_log(0, "[suspension] Return ALL %u attached trailers at %.1f seconds per height unit",
                static_cast<unsigned>(suspension_returns.size()), suspension_seconds);
        }
        for (auto it = suspension_returns.begin(); it != suspension_returns.end(); )
        {
            auto& state = it->second;
            const auto actor = it->first;
            const float first = response_math::move(actor->suspention_height, state.first, suspension_seconds, dt);
            const float other = response_math::move(actor->suspension_height_other, state.other, suspension_seconds, dt);
            write_suspension_height(actor, first, other);
            if (std::abs(first - state.first) < .00001f && std::abs(other - state.other) < .00001f)
                it = suspension_returns.erase(it);
            else
                ++it;
        }
    }
    reset_was_down = reset;
}

void removeTrailerLock(prism::game_trailer_actor_u* trailer)
{
    bridge_auto_input(trailer);
    { std::lock_guard<std::mutex> lock(response_mutex); manual_targets.erase(trailer); }
    locked_trailers.erase(
        std::remove(locked_trailers.begin(), locked_trailers.end(), trailer),
        locked_trailers.end()
    );
    temp_locked_trailers.erase(
        std::remove(temp_locked_trailers.begin(), temp_locked_trailers.end(), trailer),
        temp_locked_trailers.end()
    );
}

#include "end_centre_runtime.inc"
#include "geometry_diagnostic.inc"
#include "axle_correction.inc"

// Only consecutive live actors may form a pair; no persistent actor addresses.
bool multi_module_follower(size_t index) {
    if (!multi_module_mode || !end_centre_pair_ready() || index != size_t(multi_module_leader + 1)) return false;
    const auto chain = get_trailer_chain();
    return index < chain.size() && index > 0
        && isTrailerSteerable(chain[index - 1]) && isTrailerSteerable(chain[index]);
}

void clear_duplicate_button_binding(const std::string& button_name, int except_trailer, int except_control)
{
    if (button_name == "None")
        return;

    for (int trailer = 0; trailer < CONTROLLED_TRAILER_COUNT; ++trailer)
    {
        for (int control = 0; control < TRAILER_BUTTON_CONTROL_COUNT; ++control)
        {
            if ((trailer != except_trailer || control != except_control)
                && trailer_button_names[trailer][control] == button_name)
            {
                trailer_button_names[trailer][control] = "None";
            }
        }
    }
}

std::string get_button_name_xbox(std::string index)
{
    int i = -1;
    try {
        i = std::stoi(index);
    }
    catch (...) {
        return index;
    }

    switch (i)
    {
        case 0: return "A";
        case 1: return "B";
        case 2: return "X";
        case 3: return "Y";
        case 4: return "Left Shoulder";
        case 5: return "Right Shoulder";
        case 6: return "Back";
        case 7: return "Start";
        case 8: return "Left Stick";
        case 9: return "Right Stick";
        default: return index + " (Unknown Key Name)";
    }
}

std::string get_button_name_ps(std::string index)
{
    int i = -1;
    try {
        i = std::stoi(index);
    }
    catch (...) {
        return index;
    }

    switch (i)
    {
        case 0: return "X";
        case 1: return "O";
        case 2: return "Sqare";
        case 3: return "Y";
        case 4: return "Left Shoulder";
        case 5: return "Right Shoulder";
        case 6: return "Select";
        case 7: return "Start";
        case 8: return "Left Stick";
        case 9: return "Right Stick";
        default: return index + " (Unknown Key Name)";
    }
}

std::string get_button_name_logi(std::string index)
{
    int i = -1;
    try {
        i = std::stoi(index);
    }
    catch (...) {
        return index;
    }

    switch (i)
    {
        case 0:  return "Cross";
        case 1:  return "Square";
        case 2:  return "Circle";
        case 3:  return "Triangle";
        case 4:  return "L1 / Paddle Left";
        case 5:  return "R1 / Paddle Right";
        case 6:  return "L2";
        case 7:  return "R2";
        case 8:  return "Share";
        case 9:  return "Options";
        case 10: return "R3";
        case 11: return "L3";
        case 19: return "+";
        case 20: return "-";
        case 21: return "Knob Right";
        case 22: return "Knob Left";
        case 23: return "Reset Car / Enter";
        case 24: return "PS Button (Home)";
        default: return index + " (Unknown Key Name)";
    }
}

std::string get_button_name(int device_index, std::string key)
{
    if (key == "None")
        return key;

    if (device_index == KEYBOARD_DEVICE_INDEX)
    {
        try
        {
            const UINT virtual_key = (UINT)std::stoi(key);
            UINT scan_code = MapVirtualKeyA(virtual_key, MAPVK_VK_TO_VSC);
            if (virtual_key == VK_LEFT || virtual_key == VK_UP || virtual_key == VK_RIGHT
                || virtual_key == VK_DOWN || virtual_key == VK_PRIOR || virtual_key == VK_NEXT
                || virtual_key == VK_END || virtual_key == VK_HOME || virtual_key == VK_INSERT
                || virtual_key == VK_DELETE || virtual_key == VK_DIVIDE || virtual_key == VK_NUMLOCK)
                scan_code |= 0x100;

            char key_name[64] = {};
            if (GetKeyNameTextA((LONG)(scan_code << 16), key_name, (int)sizeof(key_name)) > 0)
                return key_name;

            return "Key " + key;
        }
        catch (...)
        {
            return "Unknown Key";
        }
    }

    if (device_index < 0 || device_index >= (int)input_devices.size())
        return key;

    input_device& device = input_devices[device_index];

    std::string name = device.name;
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) { return std::tolower(c); });

    if (name.find("xbox") != std::string::npos)
    {
        return get_button_name_xbox(key);
    }

    if (name.find("playstation") != std::string::npos)
    {
        return get_button_name_ps(key);
    }

    if (name.find("g29") != std::string::npos)
    {
        return get_button_name_logi(key);
    }

    return key + " (Unknown Key Name)";
}

void render_keybinds()
{
    // Initalize the devices list
    std::vector<const char*> device_items; // No static here, rebuild every frame
    device_items.push_back("None");
    for (input_device& device : input_devices)
        device_items.push_back(device.name.c_str());

    std::vector<const char*> button_device_items;
    button_device_items.push_back("None");
    button_device_items.push_back("Keyboard");
    for (input_device& device : input_devices)
        button_device_items.push_back(device.name.c_str());

    ImGui::SliderFloat("Steering time (s)", &steering_seconds, 2.0f, 10.0f, "%.1f", ImGuiSliderFlags_AlwaysClamp);
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("One speed for manual steering and return to Auto. Centre to full lock takes this time; lock to lock takes twice as long. Auto returns to the game's calculated angle, which may not be straight ahead.");
    ImGui::TextDisabled("Centre to lock: %.1f s | Lock to lock: %.1f s", steering_seconds, steering_seconds * 2.0f);
    ImGui::SliderFloat("Suspension time (s per height unit)", &suspension_seconds, 2.0f, 10.0f, "%.1f", ImGuiSliderFlags_AlwaysClamp);
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("One speed for raising, lowering, height-slider changes and return to ride height. Height 1.00 to 2.00 takes this time; returning from 2.00 to 1.00 takes the same time.");
    ImGui::Spacing();

    ImGui::Separator();
    ImGui::TextWrapped("Suspension - ALL attached trailers");
    int suspension_selection = suspension_device == -1 ? 0
        : suspension_device == KEYBOARD_DEVICE_INDEX ? 1 : suspension_device + 2;
    if (ImGui::BeginCombo("Suspension device", button_device_items[suspension_selection]))
    {
        for (int n = 0; n < (int)button_device_items.size(); ++n)
            if (ImGui::Selectable(button_device_items[n], suspension_selection == n))
            {
                suspension_device = n == 0 ? -1 : n == 1 ? KEYBOARD_DEVICE_INDEX : n - 2;
                suspension_buttons = { "None", "None", "None" };
                suspension_capture = -1;
                suspension_wait_release = true;
            }
        ImGui::EndCombo();
    }
    const char* suspension_labels[] = { "Raise ALL (hold)", "Lower ALL (hold)", "Ride height ALL (press)" };
    if (suspension_device != -1)
    {
        if (suspension_capture >= 0)
        {
            const std::string next = get_next_button_input(suspension_device);
            if (!next.empty())
            {
                for (auto& binding : suspension_buttons)
                    if (binding == next) binding = "None";
                suspension_buttons[suspension_capture] = next;
                suspension_capture = -1;
                suspension_wait_release = true;
            }
        }
        for (int control = 0; control < 3; ++control)
        {
            ImGui::PushID(1000 + control);
            const std::string label = suspension_capture == control ? "Press a button..."
                : get_button_name(suspension_device, suspension_buttons[control]);
            if (ImGui::Button(label.c_str()))
                suspension_capture = suspension_capture == control ? -1 : control;
            ImGui::SameLine();
            ImGui::TextUnformatted(suspension_labels[control]);
            ImGui::SameLine();
            if (ImGui::SmallButton("Clear")) suspension_buttons[control] = "None";
            ImGui::PopID();
        }
    }
    ImGui::TextDisabled("Native suspension sound triggering is not included in this test.");
    ImGui::TextWrapped("Raise/Lower move every attached trailer together. Ride height returns both axle groups to 1.0. Choose bindings separate from steering and game controls.");
    ImGui::Separator();

    // Device selections from saved values
    int selected_device_axis = (axis_device_index == -1) ? 0 : axis_device_index + 1;
    int selected_device_button = steer_button_device_index == -1 ? 0
        : steer_button_device_index == KEYBOARD_DEVICE_INDEX ? 1
        : steer_button_device_index + 2;

    // ==========================
    // Steering Axis
    // ==========================
    ImGui::TextWrapped("Steering Axis:");
    ImGui::Separator();
    ImGui::Spacing();
    ImGui::Checkbox("Use Axis Steering?", &use_axis_steering);

    if (use_axis_steering)
    {
        use_button_steering = false;

        // Device combo
        if (ImGui::BeginCombo("Steering Device", device_items[selected_device_axis]))
        {
            for (int n = 0; n < (int)device_items.size(); n++)
            {
                bool is_selected = (selected_device_axis == n);
                if (ImGui::Selectable(device_items[n], is_selected))
                    selected_device_axis = n;
                if (is_selected)
                    ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Select the input device to use for steering.");
        axis_device_index = selected_device_axis - 1;

        if (axis_device_index != -1)
        {
            std::vector<const char*> axis_items;
            axis_items.push_back("None");
            for (const auto& [name, value] : input_devices[axis_device_index].joystates)
                axis_items.push_back(name.c_str());

            ImGui::TextWrapped("Using the table below, select which key you want to use for steering");
            ImGui::TextWrapped("The steering value should be: center = 0, full left = -1, full right = 1");

            if (ImGui::BeginTable("JoystickAxes", 2, ImGuiTableFlags_Borders))
            {
                for (const auto& [name, value] : input_devices[axis_device_index].joystates)
                {
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0);
                    ImGui::TextWrapped("%s", name.c_str());
                    ImGui::TableSetColumnIndex(1);
                    ImGui::TextWrapped("%f", value);
                }
                ImGui::EndTable();
            }

            // Find saved steering axis index
            int selected_axis = 0;
            for (size_t i = 1; i < axis_items.size(); i++)
            {
                if (steering_axis_name == axis_items[i])
                {
                    selected_axis = (int)i;
                    break;
                }
            }

            if (ImGui::BeginCombo("Inputs", axis_items[selected_axis]))
            {
                for (int n = 0; n < (int)axis_items.size(); n++)
                {
                    bool is_selected = (selected_axis == n);
                    if (ImGui::Selectable(axis_items[n], is_selected))
                        selected_axis = n;
                    if (is_selected)
                        ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            steering_axis_name = axis_items[selected_axis];

            if (steering_axis_name != "None")
            {
                ImGui::SliderFloat("Steering Preview",
                    &input_devices[axis_device_index].joystates[steering_axis_name],
                    -1.f, 1.f);

                if (ImGui::IsItemHovered())
                    ImGui::SetTooltip("The steering value should be: center = 0, full left = -1, full right = 1");
            }
        }
    }

    // ==========================
    // Button Steering
    // ==========================
    ImGui::Spacing(); ImGui::Spacing();
    ImGui::TextWrapped("Button Steering");
    ImGui::Separator();
    ImGui::Checkbox("Use Button Steering?", &use_button_steering);

    if (use_button_steering)
    {
        use_axis_steering = false;

        if (selected_device_button < 0 || selected_device_button >= (int)button_device_items.size())
            selected_device_button = 0;

        if (ImGui::BeginCombo("Steering Device", button_device_items[selected_device_button]))
        {
            for (int n = 0; n < (int)button_device_items.size(); n++)
            {
                bool is_selected = (selected_device_button == n);
                if (ImGui::Selectable(button_device_items[n], is_selected))
                    selected_device_button = n;
                if (is_selected)
                    ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Select the input device to use for steering.");
        steer_button_device_index = selected_device_button == 0 ? -1
            : selected_device_button == 1 ? KEYBOARD_DEVICE_INDEX
            : selected_device_button - 2;

        if (steer_button_device_index != -1)
        {
            static int capture_trailer = -1;
            static int capture_control = -1;
            const char* control_labels[TRAILER_BUTTON_CONTROL_COUNT] = {
                "Steer Left", "Steer Right", "Re-enable Autosteer"
            };

            if (capture_trailer >= 0 && capture_control >= 0)
            {
                const std::string new_button = get_next_button_input(steer_button_device_index);
                if (!new_button.empty())
                {
                    clear_duplicate_button_binding(new_button, capture_trailer, capture_control);
                    trailer_button_names[capture_trailer][capture_control] = new_button;
                    capture_trailer = -1;
                    capture_control = -1;
                }
            }

            ImGui::TextWrapped("Assign independent controls for trailers 1-4. Manual input locks only that trailer; Autosteer returns it to the game's steering calculation.");

            for (int trailer = 0; trailer < CONTROLLED_TRAILER_COUNT; ++trailer)
            {
                ImGui::PushID(trailer);
                ImGui::Separator();
                ImGui::Text("Trailer %d", trailer + 1);

                for (int control = 0; control < TRAILER_BUTTON_CONTROL_COUNT; ++control)
                {
                    ImGui::PushID(control);
                    const bool capturing = capture_trailer == trailer && capture_control == control;
                    const std::string button_text = capturing
                        ? "Press a button..."
                        : get_button_name(steer_button_device_index, trailer_button_names[trailer][control]);

                    if (ImGui::Button(button_text.c_str()))
                    {
                        if (capturing)
                        {
                            capture_trailer = -1;
                            capture_control = -1;
                        }
                        else
                        {
                            capture_trailer = trailer;
                            capture_control = control;
                        }
                    }
                    ImGui::SameLine();
                    ImGui::TextWrapped("%s", control_labels[control]);
                    ImGui::PopID();
                }

                ImGui::PopID();
            }
        }
    }



}

// Persist configuration only: no actor pointers, manual angles or joint ownership.
#include "mode_settings.inc"
std::string last_steering_mode = "normal";

void save_settings_if_changed()
{
    // check if the settings changed
    if (   selected_steering_mode() != last_steering_mode
        || multi_module_mode != last_multi_module_mode
        || multi_module_leader != last_multi_module_leader
        || transparent_ui != last_transparent_ui
        || axis_device_index != last_axis_device_index
        || steering_axis_name != last_steering_axis_name
        || steer_button_device_index != last_steer_button_device_index
        || trailer_button_names != last_trailer_button_names
        || current_controlled_trailer != last_current_controlled_trailer
        || use_axis_steering != last_use_axis_steering
        || use_button_steering != last_use_button_steering
        || steering_seconds != last_steering_seconds
        || suspension_seconds != last_suspension_seconds
        || suspension_device != last_suspension_device
        || suspension_buttons != last_suspension_buttons
    )
    {
        json settings = {
            {"version", 7},
            {"steering_mode", selected_steering_mode()},
            {"multi_module_mode", multi_module_mode},
            {"multi_module_leader", multi_module_leader},
            {"transparent_ui", transparent_ui},
            {"axis_device_index", axis_device_index},
            {"steering_axis_name", steering_axis_name},
            {"steer_button_device_index", steer_button_device_index},
            {"current_controlled_trailer", current_controlled_trailer},
            {"use_axis_steering", use_axis_steering},
            {"use_button_steering", use_button_steering},
            {"steering_seconds", steering_seconds},
            {"suspension_seconds", suspension_seconds},
            {"suspension_device", suspension_device},
            {"suspension_buttons", suspension_buttons}
        };

        settings["trailer_button_names"] = json::array();
        for (const auto& trailer : trailer_button_names)
            settings["trailer_button_names"].push_back({ trailer[STEER_LEFT], trailer[STEER_RIGHT], trailer[ENABLE_AUTOSTEER] });

        std::ofstream file("plugins/Advanced-Trailer-Control-Bridge-Experimental.json");
        file << settings.dump(4);
        file.flush();
        if (!file) { scs_log(2, "Failed to save settings; changes will be retried."); return; }
        file.close();

        last_steering_mode = selected_steering_mode();
        last_multi_module_mode = multi_module_mode;
        last_multi_module_leader = multi_module_leader;
        last_transparent_ui = transparent_ui;
        last_axis_device_index = axis_device_index;
        last_steering_axis_name = steering_axis_name;
        last_steer_button_device_index = steer_button_device_index;
        last_trailer_button_names = trailer_button_names;
        last_current_controlled_trailer = current_controlled_trailer;
        last_use_axis_steering = use_axis_steering;
        last_use_button_steering = use_button_steering;
        last_steering_seconds = steering_seconds;
        last_suspension_seconds = suspension_seconds;
        last_suspension_device = suspension_device;
        last_suspension_buttons = suspension_buttons;

        scs_log(0, "Settings saved");
    }
}

void render_trailers()
{
    const auto trailers = get_trailer_chain();
    if (trailers.empty())
    {
        ImGui::Spacing();
        ImGui::TextUnformatted("Ready when you are.");
        ImGui::TextDisabled("Attach a trailer to show steering and suspension controls.");
        locked_trailers.clear();
        ImGui::EndTabItem();
        return;
    }
    ImGui::Spacing();
    ImGui::BeginChild("AllSuspension", ImVec2(0, 132), ImGuiChildFlags_Borders);
    ImGui::TextUnformatted("ALL TRAILERS / SUSPENSION");
    ImGui::TextDisabled("%u attached  |  Suspension travel: %.1f s per height unit",
        static_cast<unsigned>(trailers.size()), suspension_seconds);
    const float button_width = (ImGui::GetContentRegionAvail().x - 20.0f) / 3.0f;
    ImGui::Button("Lower all", ImVec2(button_width, 36));
    const bool lower = ImGui::IsItemActive();
    ImGui::SameLine();
    ImGui::Button("Raise all", ImVec2(button_width, 36));
    const bool raise = ImGui::IsItemActive();
    ImGui::SameLine();
    if (ImGui::Button("Ride height", ImVec2(button_width, 36)))
    {
        suspension_returns.clear();
        for (auto* actor : trailers)
            if (std::isfinite(actor->suspention_height) && std::isfinite(actor->suspension_height_other))
                suspension_returns[actor] = { 1.0f, 1.0f };
    }
    if (lower || raise)
    {
        suspension_returns.clear();
        const float delta = response_math::suspension_delta(raise, lower, suspension_seconds, ImGui::GetIO().DeltaTime);
        for (auto* actor : trailers)
            if (std::isfinite(actor->suspention_height) && std::isfinite(actor->suspension_height_other))
                write_suspension_height(actor, actor->suspention_height + delta, actor->suspension_height_other + delta);
    }
    ImGui::TextDisabled("Hold to raise or lower. Press Ride height for a smooth reset.");
    ImGui::EndChild();
    ImGui::Spacing();
    for (size_t index = 0; index < trailers.size(); ++index)
    {
        auto* actor = trailers[index];
        if(bridge_basic_follower(index))continue;
        ImGui::PushID(static_cast<int>(index));
        const bool steerable = isTrailerSteerable(actor);
        bool manual = isTrailerLocked(actor);
        const bool temporary = isTrailerTempLocked(actor);
        std::string heading = "TRAILER " + std::to_string(index + 1);
        if (ImGui::CollapsingHeader(heading.c_str(), ImGuiTreeNodeFlags_DefaultOpen))
        {
            ImGui::BeginChild("TrailerCard", ImVec2(0, 0), ImGuiChildFlags_Borders | ImGuiChildFlags_AutoResizeY);
            const ImVec4 status_color = !steerable ? ImVec4(.53f,.60f,.68f,1)
                : manual || temporary ? ImVec4(1,.63f,.30f,1) : ImVec4(.38f,.82f,.65f,1);
            ImGui::TextColored(status_color, "%s", !steerable ? "FIXED AXLES" : manual || temporary ? "MANUAL STEERING" : "AUTO STEERING");
            ImGui::BeginDisabled(!steerable || (crab_enabled.load() && (crab_members.load() & (1u << index))));
            if (ImGui::Button(manual ? "Return to Auto" : "Hold manual angle"))
            {
                if (manual) removeTrailerLock(actor);
                else locked_trailers.push_back(actor);
                manual = isTrailerLocked(actor);
            }
            ImGui::SameLine();
            ImGui::TextDisabled("%.0f%%", actor->steering * 100.0f);
            ImGui::SetNextItemWidth(-1);
            float requested_angle = bridge_manual_sign(actor) * (manual || temporary ? manual_target(actor) : actor->steering);
            if (ImGui::SliderFloat("##Steering", &requested_angle, -1.0f, 1.0f, "Requested steering  %.2f")) set_manual_target(actor, bridge_manual_sign(actor) * requested_angle);
            if (ImGui::IsItemActive())
            {
                if (!manual && !temporary) temp_locked_trailers.push_back(actor);
            }
            else if (temporary) {
                temp_locked_trailers.erase(std::remove(temp_locked_trailers.begin(), temp_locked_trailers.end(), actor), temp_locked_trailers.end());
                std::lock_guard<std::mutex> lock(response_mutex); manual_targets.erase(actor);
            }
            ImGui::EndDisabled();
            ImGui::Spacing();
            ImGui::TextUnformatted("Suspension height");
            ImGui::SameLine();
            ImGui::TextDisabled("1.00 = ride height");
            const auto height_request = suspension_returns.find(actor);
            float height = height_request != suspension_returns.end() ? height_request->second.first : actor->suspention_height;
            ImGui::SetNextItemWidth(-1);
            if (ImGui::SliderFloat("##Height", &height, .25f, 5.0f, "Requested height  %.2f") && std::isfinite(height))
            {
                suspension_returns[actor] = { height, height };
            }
            if (ImGui::IsItemDeactivatedAfterEdit())
                queue_suspension_readback(actor, static_cast<int>(index + 1), height);
            if (ImGui::TreeNode("Advanced / diagnostics"))
            {
                ImGui::Text("Axle groups: %.3f / %.3f", actor->suspention_height, actor->suspension_height_other);
                ImGui::Text("Actor: %p | Next: %p", static_cast<void*>(actor), static_cast<void*>(actor->slave));
                if (actor->hook_joint && actor->hook_joint->physx_joint)
                {
                    const auto motion = actor->hook_joint->physx_joint->GetMotion(prism::PxD6Axis::Enum::eTWIST);
                    const bool joint_locked = motion == prism::PxD6Motion::Enum::eLOCKED;
                    const bool supported = joint_locked || motion == prism::PxD6Motion::Enum::eFREE;
                    ImGui::BeginDisabled(!supported);
                    if (ImGui::Button(joint_locked ? "Unlock joint" : "Lock joint"))
                        actor->hook_joint->physx_joint->SetMotion(prism::PxD6Axis::Enum::eTWIST,
                            joint_locked ? prism::PxD6Motion::Enum::eFREE : prism::PxD6Motion::Enum::eLOCKED);
                    ImGui::EndDisabled();
                }
                ImGui::TreePop();
            }
            ImGui::EndChild();
        }
        ImGui::PopID();
        ImGui::Spacing();
    }
    ImGui::EndTabItem();
}

void render_about()
{
    ImGui::TextUnformatted("ADVANCED TRAILER CONTROL");
    ImGui::Separator();
    ImGui::Spacing();
    ImGui::TextWrapped("Target game build: ETS2 1.61.1.9 (Also works in ATS)");
    ImGui::Spacing();
    ImGui::TextWrapped("Independent trailer steering, axle-model control and shared suspension controls.");
    ImGui::Spacing();
    ImGui::BulletText("Selectable steering modes for multiple combination types");
    ImGui::BulletText("Independent manual steering for trailers 1-4");
    ImGui::BulletText("Timed manual steering and smooth return to automatic steering");
    ImGui::BulletText("Raise, lower and reset all attached trailers");
    ImGui::BulletText("Keyboard and controller bindings");
    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextUnformatted("STEERING MODES");
    ImGui::TextWrapped("Multi-Module Mode: For two trailer modules connected using articulation-locked joint limits. Controls both modules together as one trailer.");
    ImGui::TextWrapped("Bridge Mode: For modular bridge trailers, including compatible combinations from Sigouss' Mega Wind Transport mod. Controls the bridge and rear module together using one steering input. Release steering to hold the chosen rear-module angle while its wheels adjust to follow the bridge's turning arc. Press Auto to resume automatic tracking.");
    ImGui::TextWrapped("Bridge Mode - Expert: Supports the same modular bridge combinations, including Sigouss' Mega Wind Transport mod, with independent control of each steerable section. Release rear-module steering to hold its chosen angle while its wheels adjust to follow the bridge's turning arc. Press Auto to resume automatic tracking.");
    ImGui::TextWrapped("Both bridge modes use a four-section combination: drawbar, front module, bridge and rear module.");
    ImGui::Spacing();
    ImGui::TextWrapped("BBM Mode: For supported trailers in BBM's ST3, ST4 and ST7 trailer line. Automatically selects the matching bogie steering setup, with up to 60 degrees of bogie rotation and movement-based wheel steering.");
    ImGui::BulletText("ST3: Front axle follows the bogie's movement");
    ImGui::BulletText("ST4: Front two axles follow the bogie's movement");
    ImGui::BulletText("ST7: All seven axles follow the bogie's movement");
    ImGui::TextWrapped("Works with automatic and manual bogie steering. Wheel adjustments respond to the path each controlled axle is taking, helping it follow through corners. Movement-based wheel following currently operates when travelling forward; the added adjustments return smoothly to neutral when stopped or reversing.");
    ImGui::Spacing();
    ImGui::TextWrapped("MWT Mode: For supported three-section combinations from Sigouss' Mega Wind Transport mod. Coordinates the front jeep, tower frame and rear bogie, with individual axle steering that follows the bogie's movement. Supports forward and reverse manoeuvring, with a powered rear joint that helps prevent unwanted swing while allowing smooth steering adjustments. Manually steer the rear bogie using Trailer 3 controls. Release steering to hold its current angle, or select Auto to resume automatic tracking.");
    ImGui::TextWrapped("Use one steering mode at a time. Change modes while stopped.");
    ImGui::Separator();
    ImGui::TextWrapped("\xC2\xA9 2026 Potter Customs. Copyright applies to original contributions by Potter Customs.");
    ImGui::Spacing();
    ImGui::TextWrapped("Advanced Trailer Control is an unofficial community plugin and is not affiliated with or endorsed by SCS Software.");
    ImGui::Spacing();
    ImGui::TextWrapped("This plugin is distributed for personal and non-commercial use. No warranties are provided. Use at your own risk. It is advised against to make any changes to this plugin as it may lose some or most of its functionality.");
}

#include "handset.inc"

bool styled = false;
void dllmain::render_tick()
{
    if(!dllmain::is_initialized())return;
    if (!styled)
    {
        SetupImGuiStyle();
        handset_art::style();
        styled = true;
    }

    if(handset_page==0){
        const float h=std::min(handset_art::height(handset_current_view()),ImGui::GetIO().DisplaySize.y*.92f);
        ImGui::SetNextWindowSize(ImVec2(320,h),ImGuiCond_Always);
    }else ImGui::SetNextWindowSize(handset_page==1?ImVec2(640,720):ImVec2(500,std::min(780.f,ImGui::GetIO().DisplaySize.y*.92f)),ImGuiCond_Always);
    ImGui::SetNextWindowSizeConstraints(ImVec2(300, 360), ImVec2(1400, 1400));
    ImGui::SetNextWindowBgAlpha(0.0f);
    // Only panel backgrounds fade; text, controls and input popups stay readable.
    const auto child_bg = ImGui::GetStyleColorVec4(ImGuiCol_ChildBg);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(child_bg.x, child_bg.y, child_bg.z, transparent_ui ? 0.30f : 1.0f));
    if (!ImGui::Begin("Advanced Trailer Control###AdvancedTrailerControl",nullptr,ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse))
    {
        ImGui::End();
        ImGui::PopStyleColor();
        return;
    }
    handset_art::shell(transparent_ui);
    const int last_page=handset_page;
    handset_art::header(handset_page);
    if(last_page!=handset_page)ImGui::SetNextWindowScroll(ImVec2(0,0));
    ImGui::PushID(handset_page);
    ImGui::BeginChild("handset_page",ImVec2(0,std::max(80.f,ImGui::GetContentRegionAvail().y-50.f)),ImGuiChildFlags_None,ImGuiWindowFlags_NoBackground);
    if (running_truckersmp && !shown_truckersmp_warning)
    {
        ImGui::TextWrapped("TruckersMP Warning");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextWrapped("You are currently running TruckersMP. This plugin is not supported on multiplayer servers (however it does work) and may result in a ban.");
        ImGui::TextWrapped("\nIf you do get banned whilst using this plugin, please try contact the Game Moderation Management and discuss your ban there");


        ImGui::TextWrapped("\n\nBy clicking 'I Understand', you acknowledge that you are using this plugin at your own risk.");
        if (ImGui::Button("I Understand"))
        {
            shown_truckersmp_warning = true;
        }
    }


    if (!is_fatal_error && (!running_truckersmp || shown_truckersmp_warning)) {

        if(handset_page==0)render_handset();
        else if(handset_page==1){
            for(int&i:ui_direction)i=0;ui_suspension=0;
            ImGui::Separator();
            if(ImGui::Checkbox("Multi-Module Mode", &multi_module_mode)&&multi_module_mode){mwt_mode=false;bridge_mode=false;bridge_basic_mode=false;front_axle_test_enabled=false;}
            const char* pairs[] = { "Trailer 1 -> Trailer 2", "Trailer 2 -> Trailer 3", "Trailer 3 -> Trailer 4" };
            ImGui::Combo("Connected modules", &multi_module_leader, pairs, 3);
            ImGui::TextWrapped("%s",end_centre_status.c_str());
            ImGui::Separator();
            if(ImGui::Checkbox("BBM Mode", &front_axle_test_enabled)&&front_axle_test_enabled){mwt_mode=false;axle_correction_enabled=false;multi_module_mode=false;bridge_mode=false;bridge_basic_mode=false;}
            if(front_axle_test_enabled)ImGui::TextWrapped("Automatic setup for supported BBM 3-, 4- and 7-axle bogies. Forward movement-based wheel following.");
            if(ImGui::Checkbox("Bridge Mode", &bridge_basic_mode)&&bridge_basic_mode){mwt_mode=false;bridge_mode=false;multi_module_mode=false;front_axle_test_enabled=false;}
            if(ImGui::Checkbox("Bridge Mode - Expert", &bridge_mode)&&bridge_mode){mwt_mode=false;bridge_basic_mode=false;multi_module_mode=false;front_axle_test_enabled=false;}
            if(ImGui::Checkbox("MWT Mode", &mwt_mode)&&mwt_mode){bridge_mode=false;bridge_basic_mode=false;multi_module_mode=false;front_axle_test_enabled=false;axle_correction_enabled=false;}
            ImGui::Separator();
            render_keybinds();
            ImGui::Separator();
            ImGui::Checkbox("Transparent background", &transparent_ui);
            if(ImGui::CollapsingHeader("Diagnostics")) {
                ImGui::TextUnformatted("Geometry and steering readings");
                if(ImGui::Button("Capture geometry / log details")){atc_log::diagnostic_until.store(GetTickCount64()+21000,std::memory_order_relaxed);geometry_capture_requested=true;end_centre_refresh_requested=true;}
                ImGui::TextWrapped("Capture also records 20 seconds of bogie movement. Drive forward through a turn, then straighten.");
                ImGui::TextWrapped("%s",geometry_capture_status.c_str());
                ImGui::Separator();
                ImGui::TextUnformatted("Multi-Module Mode");
                ImGui::TextWrapped("For two trailer modules connected using articulation-locked joint limits. Controls both modules together as one trailer.");
                ImGui::TextUnformatted("Bridge Mode - Expert");
                ImGui::TextWrapped("For modular bridge trailers. Each steerable section can be controlled individually, Release steering to hold the chosen rear-module angle while its wheels adjust to follow the bridge. Press Auto to resume automatic tracking.");
                ImGui::TextUnformatted("Bridge Mode");
                ImGui::TextWrapped("For modular bridge trailers with simplified controls. Steer the bridge and rear module using one control. Release steering to hold the chosen rear-module angle while its wheels adjust to follow the bridge. Press Auto to resume automatic tracking. Use Trailer 3 controls for the combined bridge and rear module.");
                ImGui::TextUnformatted("MWT Mode");
                ImGui::TextWrapped("For the three-section MWT jeep, tower and seven-axle rear bogie. Rear-module tracking with independent Trailer 3 manual control. Release to hold its angle; press Auto to resume following. Adds movement-based following to seven rigid axle models, with their wheels held aligned to each axle. Supports forward and reverse manoeuvring.");
                ImGui::Separator();
                ImGui::TextWrapped("Multi-module: %s",end_centre_status.c_str());
                ImGui::TextWrapped("Bridge steering: %s",bridge_status.c_str());
                ImGui::TextWrapped("Reverse powered joint: resists unwanted movement while Auto or manual steering changes the target angle. Forward movement restores the normal joint drive.");
                ImGui::TextWrapped("Front and rear values are measured pivot angles relative to the bridge. Target is the requested rear pivot angle. Demand is normalized steering input, not wheel degrees.");
            }
        } else {for(int&i:ui_direction)i=0;ui_suspension=0;render_about();}
    }
    else
        render_error(error);

    ImGui::EndChild();
    ImGui::PopID();
    handset_art::badge();
    save_settings_if_changed();
    ImGui::End();
    ImGui::PopStyleColor();
}



void dllmain::main_tick()
{
    if(!dllmain::is_initialized()||is_fatal_error)return;
    static auto last_response_tick = std::chrono::steady_clock::now();
    const auto response_now = std::chrono::steady_clock::now();
    const float response_dt = response_math::elapsed_step(std::chrono::duration<float>(response_now - last_response_tick).count());
    last_response_tick = response_now;
    const auto response_chain = get_trailer_chain();
    geometry_diagnostic_tick(response_chain);
    end_centre_refresh(response_chain);
    static std::vector<prism::game_trailer_actor_u*> old_response_chain;
    if (old_response_chain != response_chain) {
        crab_enabled.store(false); crab_command.store(0); crab_members.store(0); crab_reversed.store(0);
        std::lock_guard<std::mutex> lock(response_mutex); manual_targets.clear(); crab_tables.clear();
        old_response_chain = response_chain;
    }
    if (crab_supported && (crab_enabled.load() || crab_members.load())) {
        std::lock_guard<std::mutex> lock(response_mutex);
        for (auto* t : response_chain) {
            CrabTable table{};
            if (read_crab_table(t->steering_data, table)) crab_tables[t] = table;
            else crab_tables.erase(t);
        }
    }

    if (!is_fatal_error)
    {
        const auto trailers = get_trailer_chain();
        log_trailer_chain(trailers);
        log_suspension_readbacks(trailers);
    }
    static int last_link_status = -1;
    const bool link_ready = multi_module_follower(size_t(multi_module_leader + 1));
    const int link_status = (multi_module_mode ? 1 : 0) + multi_module_leader * 2 + (link_ready ? 8 : 0);
    if (link_status != last_link_status) {
        scs_log(0, "[multi-module] enabled=%d pair=%d->%d available=%d; validated end-axle geometry, extension=0.7m", int(multi_module_mode), multi_module_leader+1, multi_module_leader+2, int(link_ready));
        last_link_status = link_status;
    }
    // Remove latent follower commands while linked so disabling restores native Auto.
    if (link_ready)
        removeTrailerLock(response_chain[size_t(multi_module_leader + 1)]);
    bridge_sync();
    // Update devices
    for (input_device& device : input_devices)
    {
        DIJOYSTATE2 joystate = {};

        HRESULT hr = device.di8_device->Poll();
        if (FAILED(hr))
        {
            hr = device.di8_device->Acquire();
            while (hr == DIERR_INPUTLOST || hr == DIERR_NOTACQUIRED)
            {
                hr = device.di8_device->Acquire();
            }

            if (FAILED(hr))
            {
                ImGui::TextWrapped("Failed to acquire device: 0x%08X", hr);
                continue;
            }
        }

        hr = device.di8_device->GetDeviceState(sizeof(DIJOYSTATE2), &joystate);
        if (FAILED(hr))
        {
            ImGui::TextWrapped("Failed to get device state: 0x%08X", hr);
            continue;
        }

        device.joystates = {
            { "lX",  ((float)joystate.lX - 32767.5f) / 32767.5f },
            { "lY",  ((float)joystate.lY - 32767.5f) / 32767.5f },
            { "lZ",  ((float)joystate.lZ - 32767.5f) / 32767.5f },
            { "lRx",  ((float)joystate.lRx - 32767.5f) / 32767.5f },
            { "lRy",  ((float)joystate.lRy - 32767.5f) / 32767.5f },
            { "lRz",  ((float)joystate.lRz - 32767.5f) / 32767.5f },
        };

        device.joystate = joystate;

        /*
            // Print joystick axes values every frame
            ImGui::TextWrapped("lX: %ld", joystate.lX);
            ImGui::TextWrapped("lY: %ld", joystate.lY);
            ImGui::TextWrapped("lZ: %ld", joystate.lZ);
            ImGui::TextWrapped("lRx: %ld", joystate.lRx);
            ImGui::TextWrapped("lRy: %ld", joystate.lRy);
            ImGui::TextWrapped("lRz: %ld", joystate.lRz);

            ImGui::TextWrapped("Slider 0: %ld", joystate.rglSlider[0]);
            ImGui::TextWrapped("Slider 1: %ld", joystate.rglSlider[1]);

            for (int i = 0; i < 4; ++i)
                ImGui::TextWrapped("POV %d: %lu", i, joystate.rgdwPOV[i]);

            for (int i = 0; i < 128; ++i)
                if (joystate.rgbButtons[i] & 0x80)
                    ImGui::TextWrapped("Button %d pressed", i);
        */
    }


    if (!is_fatal_error && remote_tick(response_dt)) return;

    if (!is_fatal_error)
        update_all_trailer_suspension(get_trailer_chain());

    if (crab_enabled.load()) {
        const int source = std::clamp(crab_control_trailer, 0, 3);
        const auto& b = trailer_button_names[source];
        if (use_button_steering && is_button_pressed(steer_button_device_index, b[ENABLE_AUTOSTEER])) {
            crab_enabled.store(false); crab_command.store(0);
        } else {
            const bool left = use_button_steering && is_button_pressed(steer_button_device_index, b[STEER_LEFT]);
            const bool right = use_button_steering && is_button_pressed(steer_button_device_index, b[STEER_RIGHT]);
            if (left != right) crab_command.store(std::clamp(crab_command.load() + (left ? -1.f : 1.f) * response_dt / steering_seconds, -1.f, 1.f));
            if (use_axis_steering && axis_device_index >= 0 && axis_device_index < int(input_devices.size()) && steering_axis_name != "None") {
                const auto it = input_devices[axis_device_index].joystates.find(steering_axis_name);
                if (it != input_devices[axis_device_index].joystates.end() && std::isfinite(it->second)) crab_command.store(std::clamp(it->second, -1.f, 1.f));
            }
        }
    }
    // Handle keybinds
    if (use_button_steering || use_axis_steering)
    {
        uint8_t* game_ctrl = *(uint8_t**)game_ctrl_ptr;

        if (game_ctrl)
        {
            uint8_t* game_actor = *(uint8_t**)(game_ctrl + game_actor_offset);

            if (game_actor)
            {
                const auto trailers = get_trailer_chain();
                if (!trailers.empty())
                {
                    int trailerIndex = 0;
                    for (auto trailer_actor : trailers)
                    {
                        if (multi_module_follower(size_t(trailerIndex)) || bridge_basic_follower(size_t(trailerIndex))) { ++trailerIndex; continue; }
                        if (crab_enabled.load() && (crab_members.load() & (1u << trailerIndex))) { ++trailerIndex; continue; }
                        if (use_button_steering
                            && (steer_button_device_index == KEYBOARD_DEVICE_INDEX
                                || (steer_button_device_index >= 0
                                    && steer_button_device_index < (int)input_devices.size()))
                            && trailerIndex < CONTROLLED_TRAILER_COUNT)
                        {
                            const auto& bindings = trailer_button_names[trailerIndex];
                            const bool autosteer = is_button_pressed(
                                steer_button_device_index, bindings[ENABLE_AUTOSTEER]);

                            if (autosteer)
                            {
                                if (isTrailerLocked(trailer_actor) || isTrailerTempLocked(trailer_actor))
                                {
                                    scs_log(0, "[steering] Trailer %d ('%p') returned to autosteer", trailerIndex + 1, trailer_actor);
                                    removeTrailerLock(trailer_actor);
                                }
                            }
                            else if (trailer_actor->steering_data)
                            {
                                const bool steer_left = is_button_pressed(
                                    steer_button_device_index, bindings[STEER_LEFT]);
                                const bool steer_right = is_button_pressed(
                                    steer_button_device_index, bindings[STEER_RIGHT]);

                                // Opposing inputs cancel. A single direction locks and moves only this trailer.
                                if (steer_left != steer_right)
                                {
                                    if (!isTrailerLocked(trailer_actor))
                                    {
                                        scs_log(0, "[steering] Trailer %d ('%p') entered manual steering", trailerIndex + 1, trailer_actor);
                                        locked_trailers.push_back(trailer_actor);
                                    }

                                    const float direction = steer_left ? -1.0f : 1.0f;
                                    set_manual_target(trailer_actor, manual_target(trailer_actor) + bridge_manual_sign(trailer_actor) * direction * response_dt / steering_seconds);
                                }
                            }
                        }

                        if (!remote_permit && use_axis_steering
                            && trailerIndex == current_controlled_trailer
                            && axis_device_index >= 0
                            && axis_device_index < (int)input_devices.size()
                            && steering_axis_name != "None")
                        {
                            if (!isTrailerLocked(trailer_actor))
                            {
                                scs_log(0, "[steering] Trailer '%p' was added to the locked list, axis steering in use", trailer_actor);
                                locked_trailers.push_back(trailer_actor);
                            }

                            input_device& device = input_devices[axis_device_index];

                            float steering_position = device.joystates[steering_axis_name];

                            if (steering_position <= 1.f && steering_position >= -1.f)
                            {
                                set_manual_target(trailer_actor, bridge_manual_sign(trailer_actor) * steering_position);
                            }
                            else
                            {
                                steering_axis_name = "None";
                                use_axis_steering = false;
                            }
                        }

                        trailerIndex++;
                    }
                }
            }
        }
    }
}




// The setter must receive manual/blended input before downstream axle-model work.
using SteeringClock = std::chrono::steady_clock;
struct SteeringReturnState
{
    prism::steering_data_t* data;
    float value;
    SteeringClock::time_point updated;
};
thread_local std::unordered_map<prism::game_trailer_actor_u*, SteeringReturnState> steering_returns;
struct SteeringOverrideContext
{
    prism::game_trailer_actor_u* actor;
    float value;
    float max_step;
    bool manual;
    bool reached = false;
    float target = 0;
    bool crab = false;
    CrabTable table{};
    float crab_lock = 0;
    bool reverse = false;
    bool setter_seen = false;
    std::shared_ptr<const EndPair> end_geometry;
    int end_index = -1;
    bool native_auto = false;
};
thread_local SteeringOverrideContext* steering_override = nullptr;
#include "bridge_mode.inc"
#include "mwt_wheels.inc"
prism::g_set_vehicle_steering_t g_set_vehicle_steering_original;
void g_set_vehicle_steering_hook(prism::steering_data_t* data, float value)
{
    auto* context = steering_override;
    if (context && context->actor->steering_data == data)
    {
        context->setter_seen = true;
        if (context->native_auto) context->reached=true;
        else if (context->manual)
            value = context->value + std::clamp(context->target - context->value, -context->max_step, context->max_step);
        else
        {
            const float delta = value - context->value;
            context->reached = std::abs(delta) <= context->max_step;
            value = context->value + std::clamp(delta, -context->max_step, context->max_step);
        }
        context->value = value;
        context->actor->steering = value;
    }
    g_set_vehicle_steering_original(data, value);
    if(context&&context->actor->steering_data==data){axle_correction_apply(context->actor,value,false);mwt_wheels_prepare(context->actor);}
    if(context&&context->end_geometry&&context->actor->steering_data==data){
        if(!end_centre_apply(*context->end_geometry,context->end_index,context->value)){
            static thread_local uintptr_t last_failure=0;
            if(last_failure!=reinterpret_cast<uintptr_t>(data)){scs_log(0,"[end-centre] Output validation failed; native angles retained for data=%p",static_cast<void*>(data));last_failure=reinterpret_cast<uintptr_t>(data);}
        }
    }
    if (context && context->crab && context->actor->steering_data == data)
        parallel_outputs(context->table, context->value * context->crab_lock * (context->reverse ? -1.0f : 1.0f));
}

using get_wheel_angle_t = float (*)(prism::steering_data_t*, uint64_t);
get_wheel_angle_t get_wheel_angle_original = nullptr;
float get_wheel_angle_hook(prism::steering_data_t* data, uint64_t wheel)
{
    auto* c = steering_override;
    if (c && c->crab && c->actor->steering_data == data && readable_memory(reinterpret_cast<uint8_t*>(data) + 0xA0, 0x20)) {
        auto* bytes = reinterpret_cast<uint8_t*>(data);
        uint64_t count = 0; uintptr_t entries = 0;
        std::memcpy(&entries, bytes + 0xA8, 8); std::memcpy(&count, bytes + 0xB0, 8);
        if (wheel < count && count <= 40 && readable_memory(reinterpret_cast<void*>(entries), size_t(count * 8))) {
            const uint64_t row = reinterpret_cast<uint64_t*>(entries)[wheel];
            if (row < c->table.count && c->table.steerable[row])
                return c->value * c->crab_lock * (c->reverse ? -1.f : 1.f);
        }
    }
    return get_wheel_angle_original(data, wheel);
}

prism::g_advance_steering_t g_advance_steering_original;
__int64 g_advance_steering_hook(prism::game_trailer_actor_u* vehicle_actor)
{
    const auto now = SteeringClock::now();
    // Bound retained state and discard detached/recreated actors without dereferencing them.
    for (auto it = steering_returns.begin(); it != steering_returns.end(); )
    {
        if (it->first != vehicle_actor
            && std::chrono::duration<float>(now - it->second.updated).count() > 30.0f)
            it = steering_returns.erase(it);
        else
            ++it;
    }
    auto found = steering_returns.find(vehicle_actor);
    if (found != steering_returns.end() && found->second.data != vehicle_actor->steering_data)
    {
        steering_returns.erase(found);
        found = steering_returns.end();
    }
    bool crab_active = false, crab_reverse = false;
    CrabTable crab_table{}; float shared_lock = 0;
    if (crab_supported && crab_enabled.load()) {
        const auto chain = get_trailer_chain();
        const auto selected = crab_members.load();
        std::lock_guard<std::mutex> lock(response_mutex);
        float limit = 1000;
        for (size_t i = 0; i < chain.size(); ++i) if (selected & (1u << i)) {
            auto it = crab_tables.find(chain[i]);
            if (it == crab_tables.end() || it->second.data != reinterpret_cast<uintptr_t>(chain[i]->steering_data)) continue;
            limit = std::min(limit, it->second.lock_radians);
            if (chain[i] == vehicle_actor) { crab_active = true; crab_table = it->second; crab_reverse = (crab_reversed.load() & (1u << i)) != 0; }
        }
        if (limit != 1000) shared_lock = limit;
    }
    auto end_geometry=multi_module_mode?std::atomic_load(&end_pair):std::shared_ptr<const EndPair>{};
    int end_index=-1;
    prism::game_trailer_actor_u* linked_leader=nullptr;
    if(end_geometry){
        const auto chain=get_trailer_chain();const size_t lead=size_t(std::clamp(multi_module_leader,0,2));
        if(lead+1>=chain.size()||chain[lead]!=end_geometry->module[0].actor||chain[lead+1]!=end_geometry->module[1].actor
           ||reinterpret_cast<uintptr_t>(chain[lead]->steering_data)!=end_geometry->module[0].data
           ||reinterpret_cast<uintptr_t>(chain[lead+1]->steering_data)!=end_geometry->module[1].data)end_geometry.reset();
        else for(int j=0;j<2;++j)if(vehicle_actor==end_geometry->module[j].actor){end_index=j;if(j==1)linked_leader=chain[lead];}
    }
    const bool axle_fix=axle_correction_selected(vehicle_actor);
    float bridge_command=0;
    const bool bridge_active=vehicle_actor->steering_data && bridge_target(vehicle_actor,bridge_command);
    const bool manual = vehicle_actor->steering_data && (bridge_active || linked_leader
        ? true
        : crab_active || isTrailerLocked(vehicle_actor) || isTrailerTempLocked(vehicle_actor));
    if (!vehicle_actor->steering_data || (!manual && found == steering_returns.end() && end_index<0 && !axle_fix))
    {
        steering_returns.erase(vehicle_actor);
        return g_advance_steering_original(vehicle_actor);
    }

    float value = vehicle_actor->steering;
    float dt = 0.0f;
    if (found != steering_returns.end())
    {
        value = found->second.value;
        const float elapsed = std::chrono::duration<float>(now - found->second.updated).count();
        // Pauses/stalls must not consume the return interval and cause a jump.
        dt = response_math::elapsed_step(elapsed);
    }
    SteeringOverrideContext context{ vehicle_actor, value,
        dt / steering_seconds, manual };
    context.end_geometry=end_index>=0?end_geometry:nullptr;context.end_index=end_index;
    context.native_auto=bridge_native_wheel_follow||((end_index==0||axle_fix)&&!manual&&found==steering_returns.end());
    context.target = bridge_active ? bridge_command : linked_leader
        ? (isTrailerLocked(linked_leader) || isTrailerTempLocked(linked_leader)
            ? manual_target(linked_leader) : linked_leader->steering)
        : crab_active ? crab_command.load() : manual_target(vehicle_actor);
    context.crab = crab_active; context.table = crab_table; context.crab_lock = shared_lock; context.reverse = crab_reverse;
    auto* previous = steering_override;
    steering_override = &context;
    const auto result = g_advance_steering_original(vehicle_actor);
    // Native advance must finish choosing/moving the bogie before wheel-only offsets.
    if(front_axle_test_enabled&&context.setter_seen)axle_correction_apply(vehicle_actor,context.value,true);
    if(mwt_mode&&context.setter_seen)mwt_wheels_finish(vehicle_actor);
    if (context.crab) parallel_outputs(context.table, context.value * context.crab_lock * (context.reverse ? -1.f : 1.f));
    steering_override = previous;
    if (linked_leader && !context.setter_seen) {
        static thread_local prism::steering_data_t* last_missing_setter = nullptr;
        if (last_missing_setter != vehicle_actor->steering_data) {
            scs_log(0, "[multi-module] Native advance skipped setter for follower %p; shared demand not applied. Further override research required.", static_cast<void*>(vehicle_actor));
            last_missing_setter = vehicle_actor->steering_data;
        }
    }
    vehicle_actor->steering = context.value;
    if (!manual && context.reached)
        steering_returns.erase(vehicle_actor);
    else
        steering_returns[vehicle_actor] = { vehicle_actor->steering_data, context.value, now };
    return result;
}




std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
        [](unsigned char c) { return std::tolower(c); });
    return s;
}

#pragma comment( linker, "/export:scs_telemetry_init=scs_telemetry_init" )
SCSAPI_RESULT scs_telemetry_init(const scs_u32_t version, const scs_telemetry_init_params_t* const params)
{
    if(version!=SCS_TELEMETRY_VERSION_1_00&&version!=SCS_TELEMETRY_VERSION_1_01)return SCS_RESULT_unsupported;
    reverse_joint_release();
    plugin_initialization_complete.store(false,std::memory_order_release);
    // Render hooks can start immediately. Publish completion only after every
    // initialization return path has finished writing settings/devices/layout.
    struct PublishInitialization {~PublishInitialization(){plugin_initialization_complete.store(true,std::memory_order_release);}} publish_initialization;

	scs_logging::init(params, "Advanced Trailer Control");

	scs_log(0, "Advanced Trailer Control | Steering and suspension");
	scs_log(0, "Plugin Loading: Advanced Trailer Control | v1.0.1 | ETS2 1.61.1.9");

    HMODULE TruckersMP = GetModuleHandleA("core_ets2mp.dll");
	if (TruckersMP)
	{
		scs_log(1, "TruckersMP detected! This plugin is not supported on multiplayer servers and may result in a ban.");
		running_truckersmp = true;
	}



    //MH_Initialize();

    // Hook DX11
    scs_log(0, "Hooking rendering API...");

    // ETS2 1.61 uses the DirectX 11 path supported by this build. Keeping the
    // project DX11-only removes unnecessary Vulkan/OpenGL build dependencies.
    kiero::RenderType::Enum render_type = kiero::RenderType::D3D11;

    renderer = new RenderManager(render_type);

    switch (renderer->GetRenderDevice())
    {
    case kiero::RenderType::D3D11:
        scs_log(0, "Rendering API: D3D11");
        break;
    default:
        scs_log(1, "Unexpected rendering API");
        break;
    }

    scs_log(0, "Hooked!");

    uintptr_t game_ctrl_ptr_instruction = bmem::patternScan("48 8B 0D ?? ?? ?? ?? 0F 57 C0 48 8B D0");
    if (!bmem::isAddressValid(game_ctrl_ptr_instruction))
    {
        scs_log(2, "Failed to find the game_ctrl pointer instruction!");

        is_fatal_error = true;
        error = "Failed to find the game_ctrl pointer instruction!";

        return SCS_RESULT_ok;
    }
    game_ctrl_ptr = bmem::relativeToAbsolute(game_ctrl_ptr_instruction, 3, 7);
    scs_log(0, "Found pointer to 'prism::game_ctrl' at: %p", game_ctrl_ptr);


    uintptr_t game_actor_offset_instruction = bmem::patternScan("4C 8B 81 ?? ?? ?? ?? 48 8B DA 4C 8B F1");
    if (!bmem::isAddressValid(game_actor_offset_instruction))
    {
        scs_log(2, "Failed to find the game_actor offset instruction!");
        is_fatal_error = true;
        error = "Failed to find the game_actor offset instruction!";
        return SCS_RESULT_ok;
    }
    game_actor_offset = *reinterpret_cast<uint32_t*>(game_actor_offset_instruction + 3);
    scs_log(0, "Found 'game_ctrl->game_actor' offset ('%d')", game_actor_offset);
    scs_log(0, "Found pointer to 'prism::game_actor' at: %p", *(uint8_t**)game_ctrl_ptr + game_actor_offset);



    uintptr_t set_vehicle_steering_address = bmem::patternScan("48 89 5C 24 08 48 89 74 24 10 57 48 83 EC ?? 8B 41 ?? 48 8B D9 0F 29 74");
    if (!bmem::isAddressValid(set_vehicle_steering_address))
    {
        scs_log(2, "Failed to find the 'prism::g_set_vehicle_steering' function!");

        is_fatal_error = true;
        error = "Failed to find the 'prism::g_set_vehicle_steering' function!";

        return SCS_RESULT_ok;
    }
    scs_log(0, "Found 'prism::g_set_vehicle_steering' at: %p", set_vehicle_steering_address);
    prism::g_set_vehicle_steering = (prism::g_set_vehicle_steering_t)set_vehicle_steering_address;


    uintptr_t advance_steering_address = bmem::patternScan("48 8B C4 55 53 56 48 8D A8 ?? ?? ?? ?? 48 81 EC ?? ?? ?? ?? 80 B9");
    if (!bmem::isAddressValid(advance_steering_address))
    {
        scs_log(2, "Failed to find the 'prism::g_advance_steering' function!");

        is_fatal_error = true;
        error = "Failed to find the 'prism::g_advance_steering' function!";

        return SCS_RESULT_ok;
    }
    // In the supplied 1.61.1.9 EXE this function loads steering_data at +0x3E.
    // Reject older layouts instead of silently using this build's field offsets.
    const auto steering_code = reinterpret_cast<const uint8_t*>(advance_steering_address);
    if (steering_code[0x3E] != 0x48 || steering_code[0x3F] != 0x8B
        || steering_code[0x40] != 0x81
        || *reinterpret_cast<const uint32_t*>(steering_code + 0x41) != 0x6C0)
    {
        scs_log(2, "Trailer actor layout does not match the 1.61.1.9 build. Controls disabled.");
        is_fatal_error = true;
        error = "Advanced Trailer Control requires the ETS2 1.61.1.9 trailer layout.";
        return SCS_RESULT_ok;
    }
    trailer_layout_verified = true;
    scs_log(0, "Layout verified: steering=0x6B8 data=0x6C0 joint=0xFE0 next=0x1088 height=0x4D0/0x4D4");
    scs_log(0, "Found 'prism::g_advance_steering' at: %p", advance_steering_address);

    bmem::MH_Success(MH_CreateHook(
        (LPVOID)set_vehicle_steering_address,
        reinterpret_cast<LPVOID>(g_set_vehicle_steering_hook),
        (LPVOID*)&g_set_vehicle_steering_original));
    bmem::MH_Success(MH_EnableHook((LPVOID)set_vehicle_steering_address));

    bmem::MH_Success(MH_CreateHook(
        (LPVOID)advance_steering_address,
        reinterpret_cast<LPVOID>(g_advance_steering_hook),
        (LPVOID*)&g_advance_steering_original));
    bmem::MH_Success(MH_EnableHook((LPVOID)advance_steering_address));

    // Crab experiment shelved: do not install the wheel getter hook.
    dinput_manager::InitDirectInput();
    for (auto& device : dinput_manager::GetInputDevices())
    {
        std::wstring wstr(device.info.tszInstanceName);
        std::string str(wstr.begin(), wstr.end());

        input_device inputdevice;
        inputdevice.name = str;
        inputdevice.di8_device = device.device;

        scs_log(0, "Added input device '%s'", str.c_str());

        input_devices.emplace_back(inputdevice);
    }

    scs_log(0, "Reading settings...");

    try {
        bool loaded_legacy_settings = false;
        std::ifstream file("plugins/Advanced-Trailer-Control-Bridge-Experimental.json");
        if (!file && GetFileAttributesA("plugins/Advanced-Trailer-Control-Bridge-Experimental.json") == INVALID_FILE_ATTRIBUTES
            && GetLastError() == ERROR_FILE_NOT_FOUND) {
            file.clear();
            file.open("plugins/Advanced-Trailer-Control-PoC.json");
            if(!file){file.clear();file.open("plugins/Advanced-Trailer-Control.json");}
            loaded_legacy_settings = bool(file);
        }

        std::ostringstream ss;
        ss << file.rdbuf();
        std::string file_content = ss.str();

        json settings = json::parse(file_content);

        // Old files only remembered Multi-Module; preserve that selection on migration.
        const std::string fallback_mode = settings.value("multi_module_mode", false) ? "multi_module" : "normal";
        restore_steering_mode(settings.contains("steering_mode") && settings["steering_mode"].is_string()
            ? settings["steering_mode"].get<std::string>() : fallback_mode);
        last_steering_mode = selected_steering_mode();
        multi_module_leader = std::clamp(settings.value("multi_module_leader", 0), 0, 2);
        last_multi_module_mode = multi_module_mode;
        last_multi_module_leader = multi_module_leader;
        transparent_ui = settings.value("transparent_ui", false);
        last_transparent_ui = transparent_ui;
        axis_device_index          = settings.value("axis_device_index", -1);
        steering_axis_name         = settings.value("steering_axis_name", std::string("None"));
        steer_button_device_index  = settings.value("steer_button_device_index", -1);
        current_controlled_trailer = settings.value("current_controlled_trailer", 0);
        use_axis_steering          = settings.value("use_axis_steering", false);
        use_button_steering        = settings.value("use_button_steering", false);
        // Existing bindings survive migration; the new shared timing pair starts at 5 s.
        steering_seconds = settings.value("steering_seconds", 5.0f);
        suspension_seconds = settings.value("suspension_seconds", 5.0f);
        if (!std::isfinite(steering_seconds)) steering_seconds = 5.0f;
        if (!std::isfinite(suspension_seconds)) suspension_seconds = 5.0f;
        steering_seconds = std::clamp(steering_seconds, 2.0f, 10.0f);
        suspension_seconds = std::clamp(suspension_seconds, 2.0f, 10.0f);
        last_steering_seconds = steering_seconds;
        last_suspension_seconds = suspension_seconds;
        suspension_device = settings.value("suspension_device", KEYBOARD_DEVICE_INDEX);
        if (suspension_device != KEYBOARD_DEVICE_INDEX
            && (suspension_device < -1 || suspension_device >= (int)input_devices.size()))
            suspension_device = -1;
        if (settings.contains("suspension_buttons") && settings["suspension_buttons"].is_array())
            for (size_t i = 0; i < 3 && i < settings["suspension_buttons"].size(); ++i)
                if (settings["suspension_buttons"][i].is_string())
                    suspension_buttons[i] = settings["suspension_buttons"][i].get<std::string>();
        last_suspension_device = suspension_device;
        last_suspension_buttons = suspension_buttons;


        if (settings.contains("trailer_button_names") && settings["trailer_button_names"].is_array())
        {
            const auto& saved_bindings = settings["trailer_button_names"];
            for (int trailer = 0; trailer < CONTROLLED_TRAILER_COUNT && trailer < (int)saved_bindings.size(); ++trailer)
            {
                if (!saved_bindings[trailer].is_array())
                    continue;

                for (int control = 0;
                    control < TRAILER_BUTTON_CONTROL_COUNT && control < (int)saved_bindings[trailer].size();
                    ++control)
                {
                    trailer_button_names[trailer][control] =
                        saved_bindings[trailer][control].get<std::string>();
                }
            }
        }
        else
        {
            // Migrate the original single-trailer left/right bindings to Trailer 1.
            trailer_button_names[0][STEER_LEFT] =
                settings.value("steer_left_button_name", std::string("None"));
            trailer_button_names[0][STEER_RIGHT] =
                settings.value("steer_right_button_name", std::string("None"));
        }

        last_axis_device_index          = axis_device_index;
        last_steering_axis_name         = steering_axis_name;
        last_steer_button_device_index  = steer_button_device_index;
        last_trailer_button_names       = trailer_button_names;
        last_current_controlled_trailer = current_controlled_trailer;
        last_use_axis_steering          = use_axis_steering;
        last_use_button_steering        = use_button_steering;

        // Verify some values:
        if (axis_device_index < -1 || axis_device_index >= (int)input_devices.size()) {
			scs_log(1, "Warning: 'axis_device_index' is out of range, resetting to -1");
            axis_device_index = -1;
        }

		if ((steer_button_device_index < -1 && steer_button_device_index != KEYBOARD_DEVICE_INDEX)
            || steer_button_device_index >= (int)input_devices.size()) {
			scs_log(1, "Warning: 'steer_button_device_index' is out of range, resetting to -1");
			steer_button_device_index = -1;
		}

        file.close();
        if (loaded_legacy_settings) {
            std::ofstream migrated("plugins/Advanced-Trailer-Control-Bridge-Experimental.json");
            migrated << settings.dump(4);
            migrated.flush();
            scs_log(migrated ? 0 : 1, migrated ? "Imported previous ATC settings into Advanced-Trailer-Control-Bridge-Experimental.json" : "Loaded legacy settings but could not save the renamed settings file");
        }
    }
    catch (...)
    {
        scs_log(2, "Failed to read settings!");
    }
    scs_log(0, "Done");

    scs_log(0, "Plugin Loaded");

    return SCS_RESULT_ok;
}

#pragma comment( linker, "/export:scs_telemetry_shutdown=scs_telemetry_shutdown" )
SCSAPI_VOID scs_telemetry_shutdown()
{
    reverse_joint_release();
    plugin_initialization_complete.store(false,std::memory_order_release);
    dinput_manager::ShutdownDirectInput();

    delete renderer;
    renderer=nullptr;

    scs_log(0, "Plugin Unloaded");
}


BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    global::hModule = hinstDLL;

    return TRUE;
}
