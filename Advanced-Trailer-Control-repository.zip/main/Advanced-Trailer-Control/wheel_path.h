#pragma once
#include "bogie_motion.h"
#include <algorithm>
namespace wheel_path {
constexpr double rad=3.141592653589793/180.;
using V=std::array<double,3>;using Q=std::array<double,4>;
inline V rotate(Q q,V v){
 const V t{2*(q[2]*v[2]-q[3]*v[1]),2*(q[3]*v[0]-q[1]*v[2]),2*(q[1]*v[1]-q[2]*v[0])};
 return {v[0]+q[0]*t[0]+q[2]*t[2]-q[3]*t[1],v[1]+q[0]*t[1]+q[3]*t[0]-q[1]*t[2],v[2]+q[0]*t[2]+q[1]*t[1]-q[2]*t[0]};
}
inline Q multiply(Q a,Q b){return {a[0]*b[0]-a[1]*b[1]-a[2]*b[2]-a[3]*b[3],a[0]*b[1]+a[1]*b[0]+a[2]*b[3]-a[3]*b[2],a[0]*b[2]-a[1]*b[3]+a[2]*b[0]+a[3]*b[1],a[0]*b[3]+a[1]*b[2]-a[2]*b[1]+a[3]*b[0]};}
struct State {bool ready=false;uint64_t tick=0;int16_t sx=0,sz=0;size_t count=0;std::array<V,14> points{};std::array<double,14> offsets{};};
struct Result {bool valid=false;const char*reason="first sample";};
inline Result sample(State& s,const atc_geometry::Pose& actor,const atc_geometry::Pose& bogie,uint64_t tick,const std::array<V,14>& locators,size_t count,bool bidirectional=false){
 if(count<1||count>14){s={};return {false,"invalid locator count"};}
 if(!atc_geometry::pose(actor)||!atc_geometry::pose(bogie)||!atc_geometry::local({bogie.x,bogie.y,bogie.z})||bogie.sector_x||bogie.sector_z){s={};return {false,"invalid pose"};}
 const Q qa=bogie_motion::quaternion(actor),qb=bogie_motion::quaternion(bogie),world=multiply(qa,qb);
 Q inverse=world;for(size_t i=1;i<4;++i)inverse[i]=-inverse[i];
 const V base=rotate(qa,{bogie.x,bogie.y,bogie.z});
 std::array<V,14> points{};
 for(size_t r=0;r<count;++r){
  const V local=locators[r];
  const V offset=rotate(world,local);
  points[r]={actor.x+base[0]+offset[0],actor.y+base[1]+offset[1],actor.z+base[2]+offset[2]};
 }
 const auto previous=s;
 s.ready=true;s.tick=tick;s.sx=actor.sector_x;s.sz=actor.sector_z;s.points=points;s.count=count;
 if(!previous.ready||previous.count!=count||previous.sx!=s.sx||previous.sz!=s.sz||tick<=previous.tick||tick-previous.tick>500){s.offsets={};return {false,"history reset"};}
 const double dt=double(tick-previous.tick)/1000.;
 if(dt<.05){s=previous;return {false,"sample too soon"};}
 std::array<V,14> velocity{};bool usable=true;
 for(size_t r=0;r<count;++r){
  V v{};for(size_t k=0;k<3;++k)v[k]=(points[r][k]-previous.points[r][k])/dt;
  if(std::hypot(v[0],v[2])>30)usable=false;
  velocity[r]=rotate(inverse,v);
  // Model forward is -Z. Reverse/stationary readings do not drive the test.
  if(!bidirectional&&velocity[r][2]>-.3)usable=false;
 }
 const double alpha=1-std::exp(-dt/.35);
 for(size_t r=0;r<count;++r){
  // A wheel yaw rotates its -Z forward vector towards -X: atan(vx/vz).
  const bool moving=bidirectional?(velocity[r][2]<=-.3||velocity[r][2]>=.08):usable;
  double yaw=std::atan2(-velocity[r][0],-velocity[r][2]);
  // Wheels can roll in either direction: choose the nearest equivalent wheel
  // heading, never a 180-degree reverse target. Only MWT opts into this path.
  if(bidirectional)yaw=std::remainder(yaw,3.141592653589793);
  const double target=usable&&moving?std::clamp(yaw,-25*rad,25*rad):0.;
  const double change=std::clamp((target-s.offsets[r])*alpha,-25*rad*dt,25*rad*dt);
  s.offsets[r]+=change;
 }
 bool moving=usable;if(bidirectional){moving=false;for(size_t r=0;r<count;++r)moving|=usable&&(velocity[r][2]<=-.3||velocity[r][2]>=.08);}
 return {moving,moving?(bidirectional?"forward/reverse wheel path":"forward wheel path"):"slow/reverse/jump fade to zero"};
}
inline Result sample(State& s,const atc_geometry::Pose& actor,const atc_geometry::Pose& bogie,uint64_t tick){
 static const std::array<V,14> points{{{{-.820000,-.904427,-2.5559578}},{{.819999,-.904427,-2.5559578}},{{-.820000,-.904432,-.7596514}},{{.819999,-.904432,-.7596514}}}};
 return sample(s,actor,bogie,tick,points,4);
}
}
