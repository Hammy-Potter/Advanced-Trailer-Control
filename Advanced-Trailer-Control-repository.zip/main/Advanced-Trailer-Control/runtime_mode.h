#pragma once
#include <cstdint>
namespace atc_runtime {
enum class Mode { Starting, Local, RemoteBridge };
// No heartbeat, an expired heartbeat, or a future timestamp selects local mode.
inline Mode mode(bool initialized,uint64_t now,uint64_t last_exchange){
 if(!initialized)return Mode::Starting;
 return last_exchange!=0&&now>=last_exchange&&now-last_exchange<750?Mode::RemoteBridge:Mode::Local;
}
}
