#pragma once
#include <cstdint>
#include <cmath>
namespace atc {
constexpr uint32_t magic=0x41544352, version=1;
constexpr uint16_t port=48161;
struct Command { int32_t direction=0, auto_mode=0, axis=0; float target=0; };
struct Trailer { uint32_t present=0, steerable=0, manual=0; float angle=0, height=1; };
struct State { Trailer trailer[4]{}; uint32_t generation=0, permit=0; };
struct Input { uint32_t role=0, connected=0, approved=0, allow=0, generation=0; uint64_t tick=0; Command command[4]{}; int32_t suspension=0, ride=0; State host{}; char name[48]{}; };
struct Output { uint32_t release=0, session=0; State local{}; Command command[4]{}; int32_t suspension=0, ride=0; uint64_t tick=0; };
struct Shared { uint32_t signature=magic, protocol=version; Input input{}; Output output{}; };
struct Packet { uint32_t signature=magic, protocol=version, kind=0, approved=0, allow=0; char code[32]{}, name[48]{}; Command command[4]{}; int32_t suspension=0, ride=0; State state{}; };
static_assert(sizeof(Packet)==260,"Unexpected wire layout");
inline bool grant(uint32_t role,bool fresh,uint32_t connected,uint32_t approved,bool permit,uint32_t received_generation,uint32_t local_generation){return role==1&&fresh&&connected==1&&approved==1&&permit&&received_generation==local_generation;}
inline bool valid(const Command& c){return c.direction>=-1&&c.direction<=1 && (c.auto_mode==0||c.auto_mode==1) && (c.axis==0||c.axis==1) && std::isfinite(c.target)&&c.target>=-1&&c.target<=1;}
inline bool valid(const Packet& p){if(p.signature!=magic||p.protocol!=version||p.kind>3||p.approved>1||p.allow>1||p.suspension<-1||p.suspension>1||p.ride<0||p.ride>1)return false;for(auto&c:p.command)if(!valid(c))return false;for(auto&t:p.state.trailer)if(t.present>1||t.steerable>1||t.manual>1||!std::isfinite(t.angle)||t.angle < -1.01f||t.angle>1.01f||!std::isfinite(t.height))return false;return true;}
}
#ifdef _WIN32
#include <windows.h>
namespace atc {
constexpr wchar_t map_name[]=L"Local\\PotterATCRemotePoC1";
constexpr wchar_t mutex_name[]=L"Local\\PotterATCRemotePoC1Mutex";
using Exchange=uint32_t(__cdecl*)(const Input*,Output*,uint32_t);
struct IPC {
 HANDLE mapping=nullptr, mutex=nullptr; Shared* p=nullptr;
 bool open(bool create){mutex=CreateMutexW(nullptr,FALSE,mutex_name);mapping=create?CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(Shared),map_name):OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,map_name);if(!mapping||!mutex)return false;bool fresh=create&&GetLastError()!=ERROR_ALREADY_EXISTS;p=(Shared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared));if(!p)return false;if(fresh&&lock()){*p=Shared{};unlock();}return true;}
 bool lock(){if(!mutex)return false;DWORD r=WaitForSingleObject(mutex,5);return r==WAIT_OBJECT_0||r==WAIT_ABANDONED;}
 void unlock(){ReleaseMutex(mutex);}
 void close(){if(p)UnmapViewOfFile(p);if(mapping)CloseHandle(mapping);if(mutex)CloseHandle(mutex);p=nullptr;mapping=nullptr;mutex=nullptr;}
 ~IPC(){close();}
};
}
#endif
