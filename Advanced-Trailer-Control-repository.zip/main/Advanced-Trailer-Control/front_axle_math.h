#pragma once
#include <cstddef>
#include <algorithm>
#include <cmath>
#include "geometry_snapshot.h"
namespace front_axle {
constexpr double rad=3.141592653589793/180.;
// Native-driven LOCAL pose, verified against common angle in captures 5..7.
// Does not subtract the trailer WORLD heading. No physics pose is claimed.
template<class Reader>
bool bogie_angle(Reader read,uintptr_t actor,double& angle){
 std::vector<float> common;std::vector<int32_t> mapping;std::vector<uintptr_t> objects;
 if(!atc_geometry::array(read,actor+0x3d8,common,1)||common.size()!=1
  ||!atc_geometry::array(read,actor+0x430,mapping,1)||mapping.size()!=1
  ||!atc_geometry::array(read,actor+0x40,objects)||mapping[0]<0||size_t(mapping[0])>=objects.size())return false;
 const auto object=objects[size_t(mapping[0])];atc_geometry::Pose p{};
 if(!object||object>UINTPTR_MAX-0x50||!read(object+0x30,&p,sizeof p)||!atc_geometry::pose(p))return false;
 const double w=p.q[0],x=p.q[1],y=p.q[2],z=p.q[3];
 const double yaw=std::atan2(2*(w*y+x*z),1-2*(y*y+z*z));
 if(!std::isfinite(common[0])||std::abs(common[0])>60.1*rad||std::abs(yaw)>60.1*rad
  ||std::abs(std::remainder(yaw-common[0],2*3.141592653589793))>.1*rad)return false;
 angle=yaw;return true;
}
inline double angle(size_t row,double bogie,double lever){
 if(row>=4||!std::isfinite(bogie)||!std::isfinite(lever)||lever<=0)return 0;
 const double z=row<2?-2.5559578:-.7596514;
 const double x=row%2?.819999:-.820000;
 const double reference=(.9888420+2.3520622)/2;
 // Quasi-static curvature estimate, not measured path radius. Retain Test 3
 // steady-state sign; remove artificial input-rate kick entirely.
 const double curvature=std::tan(-std::clamp(bogie,-60.*rad,60.*rad))/lever;
 const double follow=std::atan((z-reference)*curvature/(1-x*curvature));
 return std::clamp(follow,-25.*rad,25.*rad);
}
}
