#pragma once
#include "wheel_path.h"
namespace atc_travel {
struct State {
 bool ready=false;atc_geometry::Pose previous{};
 uint64_t sampled=0,last=0;int direction=0,candidate=0,confirmations=0;
 double speed=0,gain=0,target=0;
};
inline double update(State& s,const atc_geometry::Pose& pose,uint64_t now){
 if(!atc_geometry::pose(pose)){s={};return 0;}
 if(!s.ready||now<s.last||now-s.sampled>500||pose.sector_x!=s.previous.sector_x||pose.sector_z!=s.previous.sector_z){
  s={};s.ready=true;s.previous=pose;s.sampled=s.last=now;return 0;
 }
 const double frame_dt=std::min(double(now-s.last)/1000.,.05);s.last=now;
 if(now-s.sampled>=100){
  const double dt=double(now-s.sampled)/1000.;
  wheel_path::V world{(pose.x-s.previous.x)/dt,(pose.y-s.previous.y)/dt,(pose.z-s.previous.z)/dt};
  auto inverse=bogie_motion::quaternion(pose);for(size_t i=1;i<4;++i)inverse[i]=-inverse[i];
  const auto local=wheel_path::rotate(inverse,world);s.previous=pose;s.sampled=now;
  if(std::hypot(world[0],world[2])>30){s={};return 0;}
  s.speed=-local[2]; // Native actor forward is -Z.
  const int observed=s.speed>.06?1:s.speed<-.06?-1:0;
  if(!observed){s.candidate=0;s.confirmations=0;s.target=0;}
  else{
   if(observed!=s.direction){
    // Never keep the old correction polarity after opposite movement is seen.
    s.target=0;s.gain=0;
    if(s.candidate==observed)++s.confirmations;else{s.candidate=observed;s.confirmations=1;}
    if(s.confirmations>=2){s.direction=observed;s.candidate=0;s.confirmations=0;}
   }
   if(observed==s.direction)s.target=s.direction*std::clamp((std::abs(s.speed)-.03)/.12,0.,1.);
  }
 }
 s.gain+=(s.target-s.gain)*(-std::expm1(-frame_dt/.12));
 return s.gain;
}
}
