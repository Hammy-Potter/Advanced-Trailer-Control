#pragma once
#include "wheel_path.h"
namespace atc_joint {
// PhysX PxTransform layout, verified in supplied EXE getLocalPose implementation.
struct Transform {float q[4];float p[3];}; // quaternion x,y,z,w, then position
static_assert(sizeof(Transform)==28);
inline bool sane(const Transform& t){double n=0;for(float v:t.q){if(!std::isfinite(v))return false;n+=v*v;}for(float v:t.p)if(!std::isfinite(v)||std::abs(v)>1000)return false;return n>.95&&n<1.05;}
inline bool same(const Transform& a,const Transform& b){for(int i=0;i<4;++i)if(std::abs(a.q[i]-b.q[i])>.001)return false;for(int i=0;i<3;++i)if(std::abs(a.p[i]-b.p[i])>.001)return false;return true;}
inline bool rebase(const Transform& original,const Transform& relative,const atc_geometry::Pose& parent,const atc_geometry::Pose& rear,Transform& result){
 if(!sane(original)||!sane(relative)||!atc_geometry::pose(parent)||!atc_geometry::pose(rear))return false;
 const wheel_path::Q q{original.q[3],original.q[0],original.q[1],original.q[2]};
 const auto local_axis=wheel_path::rotate(q,{1,0,0});
 const auto a=wheel_path::rotate(bogie_motion::quaternion(parent),local_axis),b=wheel_path::rotate(bogie_motion::quaternion(rear),local_axis);
 // Only lock a joint whose twist axis is the near-vertical articulation axis.
 if(std::max(std::abs(a[1]),std::abs(b[1]))<.94)return false;
 const double n=std::hypot(relative.q[0],relative.q[3]);if(n<.2)return false;
 double x=relative.q[0]/n,w=relative.q[3]/n;if(w<0){x=-x;w=-w;}
 const double angle=2*std::atan2(x,w);if(std::abs(angle)>80*wheel_path::rad)return false;
 const auto rotated=wheel_path::multiply(q,{w,x,0,0});result=original;
 for(int i=0;i<3;++i)result.q[i]=float(rotated[i+1]);result.q[3]=float(rotated[0]);
 return sane(result);
}
struct Handle {uintptr_t wrapper=0,joint=0;bool operator==(const Handle& h)const{return wrapper==h.wrapper&&joint==h.joint;}};
struct State {bool owned=false;uintptr_t actor=0;int mode=0,motion=0;Handle handle{};Transform original{},locked{};};
template<class Adapter> bool release(State& s,Adapter& api){
 if(!s.owned)return true;
 Handle current{};Transform frame{};bool restored=false;
 if(api.bind(s.actor,current)&&current==s.handle&&api.read_local(current,frame)&&same(frame,s.locked)){
  const int now=api.get_motion(current);
  if(now>=0&&now<=2){if(now==0)api.set_motion(current,s.motion);api.write_local(current,s.original);restored=true;}
 }
 s={};return restored;
}
template<class Adapter> bool lock(State& s,Adapter& api,uintptr_t actor,int mode,const atc_geometry::Pose& parent,const atc_geometry::Pose& rear){
 if(s.owned){Handle current{};Transform frame{};if(s.actor==actor&&s.mode==mode&&api.bind(actor,current)&&current==s.handle&&api.get_motion(current)==0&&api.read_local(current,frame)&&same(frame,s.locked))return true;release(s,api);}
 Handle h{};Transform original{},relative{},rebased{};
 if(!api.bind(actor,h))return false;const int motion=api.get_motion(h);
 if(motion==0)return true; // Respect an already locked joint; do not take ownership.
 if((motion!=1&&motion!=2)||!api.read_local(h,original)||!api.read_relative(h,relative)||!rebase(original,relative,parent,rear,rebased))return false;
 s={true,actor,mode,motion,h,original,rebased};
 api.write_local(h,rebased);
 Transform check{};if(!api.read_local(h,check)||!same(check,rebased)){api.write_local(h,original);s={};return false;}
 api.set_motion(h,0);
 if(api.get_motion(h)!=0){release(s,api);return false;}
 return true;
}
}
