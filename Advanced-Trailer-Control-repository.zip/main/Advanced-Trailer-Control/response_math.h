#pragma once
#include <algorithm>
#include <cmath>
namespace response_math {
inline float elapsed_step(float elapsed) { return std::isfinite(elapsed) && elapsed > 0 && elapsed <= .25f ? elapsed : 0.f; }
inline float move(float value, float target, float seconds, float dt) {
    if (!std::isfinite(value) || !std::isfinite(target)) return 0.f;
    const float step = elapsed_step(dt) / std::max(seconds, .25f);
    return value + std::clamp(target - value, -step, step);
}
inline float suspension_delta(bool raise, bool lower, float seconds_per_unit, float dt) {
    return raise == lower ? 0.f : (raise ? 1.f : -1.f) * elapsed_step(dt) / std::max(seconds_per_unit, .25f);
}
}
namespace response_math {
inline bool crab_limits(const float* table, unsigned long long samples, unsigned long long rows, int half_steps,
                        bool* steerable, float& lock_radians) {
    if (!table || !steerable || !rows || rows > 40 || half_steps < 2 || half_steps > 4096) return false;
    const auto stride = static_cast<unsigned long long>(half_steps) * 2 + 1;
    if (samples < stride * rows || samples > 1000000) return false;
    float common = 1000.f;
    for (unsigned long long row=0; row<rows; ++row) {
        steerable[row]=false;
        const auto* s=table+row*stride;
        const float left=s[1], right=s[2*half_steps-1], centre=s[half_steps];
        if (!std::isfinite(left)||!std::isfinite(right)||!std::isfinite(centre)
            || std::abs(left)>90 || std::abs(right)>90 || std::abs(centre)>.5f) return false;
        const float limit=std::min(std::abs(left),std::abs(right));
        if (limit>.01f && left*right<0) {steerable[row]=true;common=std::min(common,limit);}
    }
    if(common==1000.f)return false;
    lock_radians=common*.017453292519943295f;return true;
}
inline void parallel_angles(float* values,const bool* steerable,unsigned long long count,float angle) {
    if (!values || !steerable || !std::isfinite(angle) || count>40) return;
    for(unsigned long long i=0;i<count;++i)if(steerable[i])values[i]=angle;
}
}
