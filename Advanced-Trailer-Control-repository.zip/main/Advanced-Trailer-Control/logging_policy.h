#pragma once
#include <atomic>
#include <cstdint>
#include <cstring>
namespace atc_log {
inline std::atomic<uint64_t> diagnostic_until{0};
inline bool allowed(int severity,const char* format,uint64_t now){
 if(!format)return false;
 if(severity>0)return true;
 const char* prefixes[]={"[steering]","[mwt-wheels]","[bbm]","[axle-correction]","[bridge-test]","[end-centre]","[multi-module]","[chain]","[suspension]","[geometry]","[bogie-motion]"};
 for(const char* p:prefixes)if(std::strncmp(format,p,std::strlen(p))==0){
  const auto until=diagnostic_until.load(std::memory_order_relaxed);
  return until!=0&&now<until;
 }
 return true;
}
}
