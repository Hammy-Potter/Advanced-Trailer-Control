#pragma once
#include "reverse_joint.h"
namespace atc_power {
using atc_joint::Transform;using atc_joint::Handle;
struct Drive {float stiffness=0,damping=0,limit=0;uint32_t flags=0;};
struct Velocity {float linear[3]{},angular[3]{};};
static_assert(sizeof(Drive)==16&&sizeof(Velocity)==24);
inline bool valid(const Drive& d){return std::isfinite(d.stiffness)&&d.stiffness>=0&&std::isfinite(d.damping)&&d.damping>=0&&std::isfinite(d.limit)&&d.limit>=0&&(d.flags&~1u)==0;}
inline bool same(const Drive&a,const Drive&b){return a.stiffness==b.stiffness&&a.damping==b.damping&&a.limit==b.limit&&a.flags==b.flags;}
inline bool valid(const Velocity& v){for(float a:v.linear)if(!std::isfinite(a)||std::abs(a)>1000)return false;for(float a:v.angular)if(!std::isfinite(a)||std::abs(a)>1000)return false;return true;}
inline bool same(const Velocity&a,const Velocity&b){for(int i=0;i<3;++i)if(std::abs(a.linear[i]-b.linear[i])>1e-5||std::abs(a.angular[i]-b.angular[i])>1e-5)return false;return true;}
inline double twist(const Transform& p){return 2*std::atan2(double(p.q[0]),double(p.q[3]));}
inline Transform goal(const Transform& original,double angle){
 const double n=std::hypot(original.q[0],original.q[3]);
 const wheel_path::Q q{original.q[3],original.q[0],original.q[1],original.q[2]},old_inverse{original.q[3]/n,-original.q[0]/n,0,0};
 const auto out=wheel_path::multiply(wheel_path::multiply(q,old_inverse),{cos(angle/2),sin(angle/2),0,0});
 Transform result=original;result.q[0]=float(out[1]);result.q[1]=float(out[2]);result.q[2]=float(out[3]);result.q[3]=float(out[0]);return result;
}
struct State {
 bool owned=false;uintptr_t actor=0,parent=0;int mode=0;Handle handle{};uint64_t tick=0;
 Drive original_drive{},installed{64,16,1000000,1};Transform original_goal{},expected_goal{};
 Velocity original_velocity{},expected_velocity{};double base_world=0,base_twist=0,sign=0,world_target=0;
};
template<class Api> bool release(State& s,Api& api){
 if(!s.owned)return true;Handle h{};Drive current{};bool ok=false;
 if(api.bind(s.actor,h)&&h==s.handle&&api.read_drive(h,4,current)&&same(current,s.installed)){
  api.write_drive(h,4,s.original_drive);Transform p{};Velocity v{};
  if(api.read_goal(h,p)&&atc_joint::same(p,s.expected_goal))api.write_goal(h,s.original_goal);
  if(api.read_velocity(h,v)&&same(v,s.expected_velocity))api.write_velocity(h,s.original_velocity);
  ok=true;
 }
 s={};return ok;
}
template<class Api> bool apply(State& s,Api& api,uintptr_t actor,int mode,uintptr_t parent,const atc_geometry::Pose& parent_pose,const atc_geometry::Pose& rear_pose,double actual,double desired,bool manual,double command,uint64_t now,double rate){
 constexpr double rad=wheel_path::rad;
 if(!std::isfinite(actual)||!std::isfinite(desired)||!std::isfinite(command)||!std::isfinite(rate)||rate<=0||std::abs(actual)>75*rad||std::abs(desired)>75*rad||std::abs(command)>1.001){release(s,api);return false;}
 Handle h{};if(!api.bind(actor,h))return false;
 if(s.owned&&(s.actor!=actor||s.parent!=parent||s.mode!=mode||!(s.handle==h)||now<s.tick||now-s.tick>500))release(s,api);
 if(!s.owned){
  const int motion=api.get_motion(h);if(motion!=1&&motion!=2)return false; // Never unlock a fixed joint.
  State next;next.actor=actor;next.parent=parent;next.mode=mode;next.handle=h;next.tick=now;next.base_world=next.world_target=actual;
  Transform relative{};Drive swing{},slerp{};
  if(!api.read_drive(h,4,next.original_drive)||!valid(next.original_drive)
   ||!api.read_drive(h,3,swing)||!valid(swing)||swing.stiffness||swing.damping
   ||!api.read_drive(h,5,slerp)||!valid(slerp)||slerp.stiffness||slerp.damping
   ||!api.read_goal(h,next.original_goal)||!atc_joint::sane(next.original_goal)||std::hypot(next.original_goal.q[0],next.original_goal.q[3])<.2
   ||!api.read_velocity(h,next.original_velocity)||!valid(next.original_velocity)
   ||!api.read_relative(h,relative)||!atc_joint::sane(relative)
   ||!api.axis_sign(h,parent,actor,parent_pose,rear_pose,next.sign))return false;
  if(std::hypot(relative.q[0],relative.q[3])<.2)return false;
  next.base_twist=std::remainder(twist(relative),2*3.141592653589793);if(std::abs(next.base_twist)>80*rad)return false;
  next.expected_goal=goal(next.original_goal,next.base_twist);next.expected_velocity=next.original_velocity;next.expected_velocity.angular[0]=0;
  // Seed the drive at the CURRENT angle before adding stiffness: no zero-angle snap.
  api.write_goal(h,next.expected_goal);Transform check{};
  if(!api.read_goal(h,check)||!atc_joint::same(check,next.expected_goal)){api.write_goal(h,next.original_goal);return false;}
  api.write_velocity(h,next.expected_velocity);Velocity velocity_check{};
  if(!api.read_velocity(h,velocity_check)||!same(velocity_check,next.expected_velocity)){api.write_goal(h,next.original_goal);api.write_velocity(h,next.original_velocity);return false;}
  api.write_drive(h,4,next.installed);next.owned=true;s=next;
  Drive verify{};if(!api.read_drive(h,4,verify)||!same(verify,s.installed)){
   Handle still{};if(api.bind(actor,still)&&still==h){api.write_drive(h,4,s.original_drive);api.write_goal(h,s.original_goal);api.write_velocity(h,s.original_velocity);}
   s={};return false;
  }
 }
 Drive current{};if(api.get_motion(h)==0||!api.read_drive(h,4,current)||!same(current,s.installed)){release(s,api);return false;}
 const double dt=std::min(double(now-s.tick)/1000.,.05);s.tick=now;
 double next=s.world_target;
 if(manual)next+=command*rate*dt;
 else next+=std::clamp(desired-next,-rate*dt,rate*dt);
 s.world_target=std::clamp(next,-75*rad,75*rad);
 const double requested=std::clamp(s.base_twist+s.sign*(s.world_target-s.base_world),-80*rad,80*rad);
 s.expected_goal=goal(s.original_goal,requested);api.write_goal(h,s.expected_goal);
 return true;
}
}
