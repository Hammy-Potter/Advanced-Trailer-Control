#pragma once
#include "wheel_path.h"

// ST7 has steering on every axle. Preserve the common bogie command and add
// only the difference between each axle's path and the bogie centre's path.
// The native driven transform is an animation, not an independent physics
// body: hold its current local pose fixed across the two chassis samples so
// a change in commanded yaw cannot manufacture lateral wheel velocity.
namespace bbm_path {
struct State {
 bool ready=false; uint64_t tick=0; atc_geometry::Pose actor{};
 std::array<double,14> offsets{};
};
inline wheel_path::Result sample(State& s,const atc_geometry::Pose& actor,
 const atc_geometry::Pose& local,uint64_t tick,const std::array<wheel_path::V,14>& points,size_t count){
 using namespace wheel_path;
 if(count!=14||!atc_geometry::pose(actor)||!atc_geometry::pose(local)
  ||!atc_geometry::local({local.x,local.y,local.z})||local.sector_x||local.sector_z){s={};return {false,"invalid ST7 pose"};}
 const auto previous=s;
 if(previous.ready&&tick>previous.tick&&tick-previous.tick<50)return {false,"sample too soon"};
 s.ready=true;s.tick=tick;s.actor=actor;
 if(!previous.ready||tick<=previous.tick||tick-previous.tick>500
  ||actor.sector_x!=previous.actor.sector_x||actor.sector_z!=previous.actor.sector_z){s.offsets={};return {false,"ST7 history reset"};}
 const double dt=double(tick-previous.tick)/1000.;
 const Q qa=bogie_motion::quaternion(actor),qp=bogie_motion::quaternion(previous.actor),qb=bogie_motion::quaternion(local);
 Q inverse=multiply(qa,qb);for(size_t i=1;i<4;++i)inverse[i]=-inverse[i];
 Q inverse_actor=qa;for(size_t i=1;i<4;++i)inverse_actor[i]=-inverse_actor[i];
 auto velocity=[&](V point){
  V p=rotate(qb,point);p[0]+=local.x;p[1]+=local.y;p[2]+=local.z;
  const V a=rotate(qa,p),b=rotate(qp,p);
  return V{(double(actor.x)-previous.actor.x+a[0]-b[0])/dt,
           (double(actor.y)-previous.actor.y+a[1]-b[1])/dt,
           (double(actor.z)-previous.actor.z+a[2]-b[2])/dt};
 };
 V centre{};for(size_t i=0;i<count;++i)for(size_t k=0;k<3;++k)centre[k]+=points[i][k]/double(count);
 const V centre_world=velocity(centre),centre_local=rotate(inverse,centre_world),forward=rotate(inverse_actor,centre_world);
 const double speed=std::hypot(centre_world[0],centre_world[2]);
 bool usable=std::isfinite(speed)&&speed>=.3&&speed<=30&&forward[2]<=-.3;
 std::array<double,14> targets{};
 const double centre_yaw=std::atan2(-centre_local[0],-centre_local[2]);
 for(size_t i=0;i<count;++i){
  const V world=velocity(points[i]),v=rotate(inverse,world);
  if(!std::isfinite(v[0])||!std::isfinite(v[2])||std::hypot(world[0],world[2])>30||std::hypot(v[0],v[2])<.15)usable=false;
  targets[i]=std::clamp(std::remainder(std::atan2(-v[0],-v[2])-centre_yaw,3.141592653589793),-25*rad,25*rad);
 }
 const double alpha=1-std::exp(-dt/.35);
 for(size_t i=0;i<count;++i)s.offsets[i]+=std::clamp(((usable?targets[i]:0.)-s.offsets[i])*alpha,-25*rad*dt,25*rad*dt);
 return {usable,usable?"ST7 differential chassis path":"ST7 slow/reverse/jump fade"};
}
}
