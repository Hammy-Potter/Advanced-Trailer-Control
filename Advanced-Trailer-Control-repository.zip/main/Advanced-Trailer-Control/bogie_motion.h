#pragma once
#include "geometry_snapshot.h"
#include <array>
namespace bogie_motion {
struct State { bool ready=false;uint64_t tick=0;int16_t sx=0,sz=0;double x=0,z=0,yaw=0; };
struct Motion {bool valid=false,path=false;double speed=0,yaw_rate=0,curvature=0;const char* reason="first sample";};
inline std::array<double,4> quaternion(const atc_geometry::Pose& p){
 double norm=0;for(float v:p.q)norm+=double(v)*v;norm=std::sqrt(norm);
 return {p.q[0]/norm,p.q[1]/norm,p.q[2]/norm,p.q[3]/norm};
}
inline Motion sample(State& s,const atc_geometry::Pose& actor,const atc_geometry::Pose& local,uint64_t tick){
 Motion out;
 if(!atc_geometry::pose(actor)||!atc_geometry::pose(local)||!atc_geometry::local({local.x,local.y,local.z})||local.sector_x||local.sector_z){s={};out.reason="invalid pose";return out;}
 const auto a=quaternion(actor),b=quaternion(local);
 // Rotate local pivot by the full actor quaternion (including pitch/roll).
 const double tx=2*(a[2]*local.z-a[3]*local.y),ty=2*(a[3]*local.x-a[1]*local.z),tz=2*(a[1]*local.y-a[2]*local.x);
 const double x=actor.x+local.x+a[0]*tx+a[2]*tz-a[3]*ty;
 const double z=actor.z+local.z+a[0]*tz+a[1]*ty-a[2]*tx;
 const double w=a[0]*b[0]-a[1]*b[1]-a[2]*b[2]-a[3]*b[3];
 const double qx=a[0]*b[1]+a[1]*b[0]+a[2]*b[3]-a[3]*b[2];
 const double qy=a[0]*b[2]-a[1]*b[3]+a[2]*b[0]+a[3]*b[1];
 const double qz=a[0]*b[3]+a[1]*b[2]-a[2]*b[1]+a[3]*b[0];
 const double yaw=std::atan2(2*(w*qy+qx*qz),1-2*(qy*qy+qz*qz));
 const State next{true,tick,actor.sector_x,actor.sector_z,x,z,yaw};
 if(!s.ready){s=next;return out;}
 const State previous=s;s=next;
 if(actor.sector_x!=previous.sx||actor.sector_z!=previous.sz){out.reason="sector change";return out;}
 if(tick<=previous.tick||tick-previous.tick<50||tick-previous.tick>500){out.reason="time gap";return out;}
 const double dt=double(tick-previous.tick)/1000.;
 out.speed=std::hypot(x-previous.x,z-previous.z)/dt;
 out.yaw_rate=std::remainder(yaw-previous.yaw,6.283185307179586)/dt;
 if(out.speed>30||std::abs(out.yaw_rate)>2){out.reason="jump or excessive rate";return out;}
 out.valid=true;
 if(out.speed<.15){out.reason="too slow for curvature";return out;}
 out.path=true;out.curvature=out.yaw_rate/out.speed;out.reason="candidate forward path";
 return out;
}
}
