#pragma once
#include "wheel_path.h"
namespace mwt_wheels {
constexpr double rad=wheel_path::rad;
// Row order is the source model's wheel_0/wheel_1 within each axle group.
// Mounts are read from native trailer-local driven transforms. Only their
// translations are used: steering yaw must not feed back as wheel travel.
inline bool locators(const std::vector<atc_geometry::Pose>& mounts,std::array<wheel_path::V,14>& points){
 if(mounts.size()!=7)return false;
 constexpr double z[7]={-5.844203,-4.554170,-3.229162,-1.924160,-.634249,.690773,2.097464};
 constexpr double y[7]={-.548341,-.548341,-.508341,-.508341,-.508341,-.468343,-.508341};
 for(size_t g=0;g<7;++g){
  const auto& p=mounts[g];
  if(!atc_geometry::pose(p)||p.sector_x||p.sector_z||!atc_geometry::local({p.x,p.y,p.z})
   ||std::abs(p.x)>.05||std::abs(p.z-z[g])>.08)return false;
  points[g*2]={p.x-.812753,p.y+y[g],p.z+.262899};
  points[g*2+1]={p.x+.811141,p.y+y[g],p.z+.262899};
 }
 return true;
}
inline bool targets(const std::vector<float>& native,const wheel_path::State& path,std::array<float,14>& desired){
 if(native.size()!=14)return false;
 for(size_t r=0;r<14;++r){
  if(!std::isfinite(native[r])||std::abs(native[r])>1.5708||!std::isfinite(path.offsets[r])||std::abs(path.offsets[r])>25.01*rad)return false;
  // Movement is the feed-forward angle. Retain the articulation controller's
  // native per-wheel correction so following cannot remove steering authority.
  desired[r]=float(std::clamp(double(native[r])+path.offsets[r],-50*rad,50*rad));
 }
 // Each group is a rigid axle model, not two steering knuckles. Average the
 // two wheel-path/correction targets before native advance, so its wheels do
 // not demand different yaw angles within the same model.
 for(size_t g=0;g<7;++g){const float axle=(desired[g*2]+desired[g*2+1])*.5f;desired[g*2]=desired[g*2+1]=axle;}
 return true;
}
inline bool residuals(const std::array<float,14>& desired,const std::vector<float>& common,std::array<float,14>& wheel){
 if(common.size()!=7)return false;
 for(size_t r=0;r<14;++r){
  if(!std::isfinite(desired[r])||std::abs(desired[r])>50.01*rad||!std::isfinite(common[r/2])||std::abs(common[r/2])>50.01*rad)return false;
  // Wheel consumers build a separate steering rotation from the output
  // angle (e.g. supplied EXE RVA 0x879a39..0x879abd). This output is not a
  // wheel-local residual: keep absolute wheel steering equal to model yaw.
  // Refuse the write if native advance did not consume the shared target.
  if(std::abs(desired[r]-desired[(r/2)*2])>1e-6f
   ||std::abs(desired[r]-common[r/2])>.1*rad)return false;
  wheel[r]=common[r/2];
  if(!std::isfinite(wheel[r])||std::abs(wheel[r])>1.5708f)return false;
 }
 return true;
}
}
