#pragma once
#include "imgui/imgui.h"
#include <cstdint>
#include <cstring>
namespace handset_logo {
inline int slot=-1;
inline bool ready=false;
inline ImVec2 uv0{},uv1{};
// Rendered from the supplied SVG at build time; retain the original aspect ratio.
constexpr int crop_x=0,crop_y=0,crop_w=766,crop_h=316;
inline void reserve(ImFontAtlas*atlas,int w,int h){atlas->TexDesiredWidth=2048;slot=atlas->AddCustomRectRegular(w,h);ready=false;}
inline bool fill(ImFontAtlas*atlas,const uint8_t*pixels,int w,int h){
 if(slot<0||!pixels||w<crop_x+crop_w||h<crop_y+crop_h)return false;
 unsigned char*dest;int aw,ah;atlas->GetTexDataAsRGBA32(&dest,&aw,&ah);auto*r=atlas->GetCustomRectByIndex(slot);
 if(!r||!r->IsPacked()||r->Width!=w||r->Height!=h)return false;
 for(int y=0;y<h;++y)memcpy(dest+((r->Y+y)*aw+r->X)*4,pixels+y*w*4,size_t(w)*4);
 uv0={float(r->X+crop_x)/aw,float(r->Y+crop_y)/ah};uv1={float(r->X+crop_x+crop_w)/aw,float(r->Y+crop_y+crop_h)/ah};ready=true;return true;
}
}
