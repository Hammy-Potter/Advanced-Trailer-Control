#pragma once
#include <cmath>
#include <algorithm>
namespace bridge_math {
inline double wrap(double a){return std::atan2(std::sin(a),std::cos(a));}
inline double yaw(const float*q){double w=q[0],x=q[1],y=q[2],z=q[3];return std::atan2(2*(w*y+x*z),1-2*(y*y+z*z));}
inline float demand(double front,double rear,bool reverse=false){double e=-.6*front-rear;float u=std::abs(e)<.5?0.f:float(std::clamp(e*.02,-.25,.25));return reverse?-u:u;}
}
