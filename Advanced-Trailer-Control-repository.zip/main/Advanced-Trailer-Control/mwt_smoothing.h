#pragma once
#include "mwt_wheel_math.h"
namespace mwt_wheels {
struct Smooth {bool ready=false;uint64_t tick=0;std::array<float,7> axle{};};
inline bool smooth(Smooth& state,std::array<float,14>& desired,const std::vector<float>& measured,uint64_t now){
 if(measured.size()!=7)return false;
 for(size_t g=0;g<7;++g)if(!std::isfinite(measured[g])||std::abs(measured[g])>50.01*rad
  ||!std::isfinite(desired[g*2])||!std::isfinite(desired[g*2+1])
  ||std::abs(desired[g*2])>50.01*rad||desired[g*2]!=desired[g*2+1])return false;
 auto next=state;
 if(!next.ready||now<next.tick||now-next.tick>500){
  next.ready=true;next.tick=now;for(size_t g=0;g<7;++g)next.axle[g]=measured[g];
 }else{
  // Frame-rate independent easing of the full axle command, including native
  // correction. Repeated setter calls at the same tick must not double-step.
  const double dt=std::min(double(now-next.tick)/1000.,.05);next.tick=now;
  const double alpha=-std::expm1(-dt/.06),limit=45*rad*dt;
  for(size_t g=0;g<7;++g){const double change=std::clamp((double(desired[g*2])-next.axle[g])*alpha,-limit,limit);next.axle[g]+=float(change);}
 }
 for(size_t g=0;g<7;++g)desired[g*2]=desired[g*2+1]=next.axle[g];
 state=next;return true;
}
}
