#pragma once
// Native ImGui artwork: one continuous faceplate at every supported height.
// Native shell, plus the supplied PNG badge embedded in the font atlas.
#include "imgui/imgui.h"
#include "remote_contract.h"
#include "logo_atlas.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
namespace handset_art {
inline ImU32 rgb(int r,int g,int b,int a=255){return IM_COL32(r,g,b,a);}
inline void gradient(ImDrawList* d,ImVec2 a,ImVec2 b,ImU32 top,ImU32 bottom,float round=0){
 const int start=d->VtxBuffer.Size;d->AddRectFilled(a,b,top,round);
 for(int i=start;i<d->VtxBuffer.Size;++i){auto&v=d->VtxBuffer[i];float t=std::clamp((v.pos.y-a.y)/std::max(1.f,b.y-a.y),0.f,1.f);ImU32 c=0;for(int k=0;k<4;++k){int x=(top>>(k*8))&255,y=(bottom>>(k*8))&255;c|=ImU32(int(x+(y-x)*t))<<(k*8);}v.col=c;}
}
inline void centered(ImDrawList*d,ImVec2 c,const char*text,ImU32 col,float size=15){
 auto*f=ImGui::GetFont();ImVec2 t=f->CalcTextSizeA(size,10000,0,text);d->AddText(f,size,ImVec2(c.x-t.x/2,c.y-t.y/2),col,text);
}
inline void screw(ImDrawList*d,ImVec2 c){
 d->AddCircleFilled(ImVec2(c.x,c.y+1),5.8f,rgb(28,30,30),20);
 d->AddCircleFilled(c,4.5f,rgb(196,199,197),20);d->AddCircle(c,4.1f,rgb(244,245,241),20,1);
 d->AddLine(ImVec2(c.x-2,c.y-2),ImVec2(c.x+2,c.y+2),rgb(57,61,61),1.5f);
 d->AddLine(ImVec2(c.x-2,c.y+2),ImVec2(c.x+2,c.y-2),rgb(57,61,61),1.5f);
}
inline void shell(bool transparent){
 auto*d=ImGui::GetWindowDrawList();ImVec2 p=ImGui::GetWindowPos(),s=ImGui::GetWindowSize();
 const int alpha=transparent?150:255;
 gradient(d,p,ImVec2(p.x+s.x,p.y+s.y),rgb(45,48,48,alpha),rgb(14,17,17,alpha),29);
 d->AddRect(ImVec2(p.x+3,p.y+3),ImVec2(p.x+s.x-3,p.y+s.y-3),rgb(84,87,85,alpha),27,0,2);
 d->AddRect(ImVec2(p.x+9,p.y+9),ImVec2(p.x+s.x-9,p.y+s.y-9),rgb(5,7,7,alpha),23,0,3);
 // Fine molded texture stays in the rubber surround, never on the control labels.
 for(int j=19;j<s.y-17;j+=8)for(int i=7;i<s.x-6;i+=7){if(i>19&&i<s.x-20)continue;d->AddCircleFilled(ImVec2(p.x+i,p.y+j),.65f,rgb(110,114,109,transparent?20:35),4);}
 // Grip ribs are on the two outside edges; they are not module seams.
 for(float y=p.y+74;y<p.y+s.y-57;y+=37){
  gradient(d,ImVec2(p.x+1,y),ImVec2(p.x+13,y+21),rgb(59,63,62,alpha),rgb(20,23,23,alpha),4);
  gradient(d,ImVec2(p.x+s.x-13,y),ImVec2(p.x+s.x-1,y+21),rgb(59,63,62,alpha),rgb(20,23,23,alpha),4);
 }
 ImVec2 a(p.x+19,p.y+17),b(p.x+s.x-19,p.y+s.y-17);
 gradient(d,a,b,rgb(211,213,208,alpha),rgb(162,167,165,alpha),19);
 d->AddRect(a,b,rgb(11,15,15,alpha),19,0,2);d->AddRect(ImVec2(a.x+3,a.y+3),ImVec2(b.x-3,b.y-3),rgb(238,239,233,alpha),16,0,1);
 // Brushed finish drawn once over the whole continuous faceplate.
 d->PushClipRect(ImVec2(a.x+7,a.y+19),ImVec2(b.x-7,b.y-19),true);
 for(int y=int(a.y)+20;y<int(b.y)-19;y+=3){int tone=(((y*17)%13)<6)?255:0;d->AddLine(ImVec2(a.x+6,float(y)),ImVec2(b.x-6,float(y)),rgb(tone,tone,tone,transparent?3:6));}
 d->PopClipRect();
 screw(d,ImVec2(a.x+13,a.y+14));screw(d,ImVec2(b.x-13,a.y+14));screw(d,ImVec2(a.x+13,b.y-14));screw(d,ImVec2(b.x-13,b.y-14));
}
inline bool nav_button(const char*id,const char*label,bool selected,float width){
 ImVec2 p=ImGui::GetCursorScreenPos();ImGui::InvisibleButton(id,ImVec2(width,27));bool click=ImGui::IsItemClicked();bool down=ImGui::IsItemActive()&&ImGui::IsMouseDown(0);auto*d=ImGui::GetWindowDrawList();
 d->AddRectFilled(ImVec2(p.x,p.y+3),ImVec2(p.x+width,p.y+28),rgb(15,18,18),7);
 gradient(d,p,ImVec2(p.x+width,p.y+25),down?rgb(28,33,32):rgb(70,76,74),rgb(25,30,29),7);
 d->AddRect(p,ImVec2(p.x+width,p.y+25),selected?rgb(171,189,160):rgb(117,123,119),7,0,1);
 centered(d,ImVec2(p.x+width/2,p.y+12),label,rgb(239,241,229),11);
 return click;
}
inline void header(int& page){
 float width=ImGui::GetContentRegionAvail().x;ImVec2 p=ImGui::GetCursorScreenPos();auto*d=ImGui::GetWindowDrawList();
 centered(d,ImVec2(p.x+width/2,p.y+7),"ADVANCED TRAILER",rgb(22,29,28),15);
 centered(d,ImVec2(p.x+width/2,p.y+24),"CONTROL",rgb(22,29,28),15);
 ImGui::Dummy(ImVec2(width,38));float bw=(width-12)/3;
 if(nav_button("nav_controls","CONTROLS",page==0,bw))page=0;ImGui::SameLine(0,6);
 if(nav_button("nav_settings","SETTINGS",page==1,bw))page=1;ImGui::SameLine(0,6);
 if(nav_button("nav_info","INFO",page==2,bw))page=2;
 ImGui::Dummy(ImVec2(0,5));
}
inline void badge(){
 float width=ImGui::GetContentRegionAvail().x;ImVec2 p=ImGui::GetCursorScreenPos();auto*d=ImGui::GetWindowDrawList();float x=p.x+width/2;
 if(handset_logo::ready){
   const float w=92.f,h=w*handset_logo::crop_h/handset_logo::crop_w;
   d->AddImage(ImGui::GetIO().Fonts->TexID,ImVec2(x-w/2,p.y+4),ImVec2(x+w/2,p.y+4+h),handset_logo::uv0,handset_logo::uv1);
 }else centered(d,ImVec2(x,p.y+20),"POTTER TRAILERS",rgb(25,34,27),11);
 ImGui::Dummy(ImVec2(width,44));
}
inline void display(const char*text){
 float width=ImGui::GetContentRegionAvail().x;ImVec2 p=ImGui::GetCursorScreenPos();auto*d=ImGui::GetWindowDrawList();
 d->AddRectFilled(p,ImVec2(p.x+width,p.y+33),rgb(26,33,28),5);
 gradient(d,ImVec2(p.x+4,p.y+4),ImVec2(p.x+width-4,p.y+29),rgb(133,151,117),rgb(188,202,162),2);
 d->AddRect(ImVec2(p.x+4,p.y+4),ImVec2(p.x+width-4,p.y+29),rgb(84,100,77),2);
 centered(d,ImVec2(p.x+width/2,p.y+17),text,rgb(27,43,26),15);
 ImGui::Dummy(ImVec2(width,36));
}
// The arrow follows the same sign convention as the Left/Right controls.
// Values that round to zero have no direction arrow.
inline void steering_display(bool manual,float angle){
 ImVec2 p=ImGui::GetCursorScreenPos();float width=ImGui::GetContentRegionAvail().x;
 display("");auto*d=ImGui::GetWindowDrawList();auto*f=ImGui::GetFont();
 float value=std::isfinite(angle)?std::clamp(angle,-1.f,1.f):0.f;
 int percent=int(std::round(std::fabs(value)*100));int direction=percent==0?0:(value<0?-1:1);
 const char*mode=manual?"MANUAL":"AUTO";char magnitude[16];snprintf(magnitude,sizeof(magnitude),"%d%%",percent);
 const float font=15,mode_width=f->CalcTextSizeA(font,10000,0,mode).x;
 float total=mode_width+10+(direction?22:0)+f->CalcTextSizeA(font,10000,0,magnitude).x;
 float x=p.x+(width-total)/2,y=p.y+17;ImU32 ink=rgb(27,43,26);
 d->AddText(f,font,ImVec2(x,y-font/2),ink,mode);x+=mode_width+10;
 if(direction){float cx=x+7,cy=y;
  if(direction<0)d->AddTriangleFilled(ImVec2(cx-6,cy),ImVec2(cx+5,cy-5),ImVec2(cx+5,cy+5),ink);
  else d->AddTriangleFilled(ImVec2(cx+6,cy),ImVec2(cx-5,cy+5),ImVec2(cx-5,cy-5),ink);
  x+=22;
 }
 d->AddText(f,font,ImVec2(x,y-font/2),ink,magnitude);
}
enum class Symbol{Left,Right,Down,Up,Text};
inline bool round_button(const char*id,const char*label,Symbol symbol,float size){
 ImVec2 p=ImGui::GetCursorScreenPos();ImGui::InvisibleButton(id,ImVec2(size,size+3));bool down=ImGui::IsItemActive()&&ImGui::IsMouseDown(0);bool hit=down||ImGui::IsItemClicked();auto*d=ImGui::GetWindowDrawList();ImVec2 c(p.x+size/2,p.y+size/2),fc(c.x,c.y+(down?1:-1));float r=size/2;
 d->AddCircleFilled(ImVec2(c.x,c.y+3),r,rgb(66,72,68),48);
 d->AddCircleFilled(c,r-1,rgb(14,19,17),48);
 d->AddCircle(c,r-3,rgb(170,175,166),48,1);
 // Concentric shading gives the rubber key a raised dome, without another image.
 for(int i=int(r)-5;i>0;--i){int n=int(30+(down?12:28)*(float(i)/(r-5)));d->AddCircleFilled(fc,float(i),rgb(n,n+4,n+2),48);}
 d->AddCircle(fc,r-6,down?rgb(91,102,88):rgb(112,122,109),48,1);
 ImU32 white=rgb(238,242,224);float a=size*.14f;
 if(symbol==Symbol::Text)centered(d,fc,label,white,label[0]=='A'?13:12);
 else{ImVec2 tip,b1,b2;switch(symbol){case Symbol::Left:tip={fc.x-a,fc.y};b1={fc.x+a,fc.y-a};b2={fc.x+a,fc.y+a};break;case Symbol::Right:tip={fc.x+a,fc.y};b1={fc.x-a,fc.y+a};b2={fc.x-a,fc.y-a};break;case Symbol::Up:tip={fc.x,fc.y-a};b1={fc.x-a,fc.y+a};b2={fc.x+a,fc.y+a};break;default:tip={fc.x,fc.y+a};b1={fc.x+a,fc.y-a};b2={fc.x-a,fc.y-a};break;}d->AddTriangleFilled(tip,b1,b2,white);}
 return hit;
}
inline void label(const char*text){ImVec2 p=ImGui::GetCursorScreenPos();float w=ImGui::GetContentRegionAvail().x;centered(ImGui::GetWindowDrawList(),ImVec2(p.x+w/2,p.y+8),text,rgb(24,32,28),13);ImGui::Dummy(ImVec2(w,22));}
struct View {bool bridge_pair=false;int linked_follower=-1;atc::State state{};bool client=false,host=false,connected=false,permitted=false;const char*name="";};
struct Actions {int direction[4]{};bool automatic[4]{};int suspension=0;bool ride=false,release=false,takeover=false;};
inline int count(const View&v){int n=0;for(int i=0;i<4;++i)if(i!=v.linked_follower&&v.state.trailer[i].present&&v.state.trailer[i].steerable)++n;return n;}
inline float height(const View&v){return 390.f+std::max(1,count(v))*146.f+(v.client?58.f:(v.host?32.f:0.f));}
inline void status(const View&v){
 ImVec2 p=ImGui::GetCursorScreenPos();float width=ImGui::GetContentRegionAvail().x;auto*d=ImGui::GetWindowDrawList();bool good=!v.client||(v.connected&&v.permitted);ImVec2 c(p.x+8,p.y+9);
 d->AddCircleFilled(c,6,rgb(43,50,42),20);d->AddCircleFilled(c,4,good?rgb(68,194,55):rgb(210,143,37),20);d->AddCircleFilled(ImVec2(c.x-1,c.y-1),1.4f,rgb(200,244,187),12);
 const char*text=v.client?(v.connected?(v.permitted?"REMOTE CONTROL":"REMOTE / CONTROL DISABLED"):"REMOTE DISCONNECTED"):(v.permitted?"HOST / REMOTE ENABLED":"LOCAL CONTROL");centered(d,ImVec2(p.x+width/2+6,p.y+9),text,rgb(35,53,34),11);ImGui::Dummy(ImVec2(width,24));
 if(v.client){char name[80];snprintf(name,sizeof(name),"Host: %.32s",v.name);label(name);}
}
inline Actions controls(const View&v){
 Actions result{};status(v);int n=0;float width=ImGui::GetContentRegionAvail().x;float size=std::min(60.f,(width-20)/3),gap=(width-3*size)/2;
 for(int i=0;i<4;++i){const auto&t=v.state.trailer[i];if(!t.present||!t.steerable||i==v.linked_follower)continue;++n;ImGui::PushID(i);char text[90];snprintf(text,sizeof(text),"%sTRAILER %d",v.client?"HOST ":"",i+1);if(i+1==v.linked_follower)snprintf(text,sizeof(text),v.bridge_pair?"BRIDGE + REAR MODULE":"TRAILER %d / MULTI-MODULE",i+1);label(text);steering_display(t.manual,t.angle);
 ImGui::BeginDisabled(i==v.linked_follower);
 if(round_button("left","",Symbol::Left,size))result.direction[i]=-1;ImGui::SameLine(0,gap);
 if(round_button("auto","AUTO",Symbol::Text,size))result.automatic[i]=true;ImGui::SameLine(0,gap);
 if(round_button("right","",Symbol::Right,size))result.direction[i]=1;
 ImGui::EndDisabled();
 ImGui::Dummy(ImVec2(0,9));ImGui::PopID();}
 if(!n){ImGui::TextWrapped(v.client?"Waiting for steerable host trailers.":"No steerable trailers detected yet.");ImGui::Dummy(ImVec2(0,65));}
 label(v.client?"ALL HOST TRAILERS":"ALL TRAILERS / SUSPENSION");bool have=false,mixed=false;float h=1;for(auto&t:v.state.trailer)if(t.present){if(!have){h=t.height;have=true;}else if(fabs(t.height-h)>.01f)mixed=true;}
 char text[64];if(mixed)snprintf(text,sizeof(text),"HEIGHT: MIXED");else snprintf(text,sizeof(text),"HEIGHT %.2f",h);display(text);
 if(round_button("lower","",Symbol::Down,size))result.suspension=-1;ImGui::SameLine(0,gap);
 if(round_button("ride","RIDE",Symbol::Text,size))result.ride=true;ImGui::SameLine(0,gap);
 if(round_button("raise","",Symbol::Up,size))result.suspension=1;
 ImGui::Dummy(ImVec2(0,5));
 if(v.client)result.release=nav_button("release","RELEASE REMOTE CONTROL",false,width);
 else if(v.host)result.takeover=nav_button("takeover","TAKE BACK CONTROL",false,width);
 ImGui::Dummy(ImVec2(0,5));return result;
}
inline void style(){auto&s=ImGui::GetStyle();s.WindowPadding=ImVec2(38,34);s.WindowRounding=29;s.WindowBorderSize=0;s.ItemSpacing=ImVec2(8,4);s.FramePadding=ImVec2(7,5);s.Colors[ImGuiCol_WindowBg]=ImVec4(0,0,0,0);s.Colors[ImGuiCol_Text]=ImVec4(.09f,.12f,.1f,1);s.Colors[ImGuiCol_TextDisabled]=ImVec4(.26f,.31f,.27f,1);s.Colors[ImGuiCol_PopupBg]=ImVec4(.82f,.84f,.80f,1);s.Colors[ImGuiCol_FrameBg]=s.Colors[ImGuiCol_Button]=ImVec4(.64f,.68f,.63f,1);s.Colors[ImGuiCol_ButtonHovered]=s.Colors[ImGuiCol_FrameBgHovered]=ImVec4(.80f,.84f,.78f,1);s.Colors[ImGuiCol_ButtonActive]=ImVec4(.54f,.60f,.53f,1);s.Colors[ImGuiCol_Header]=ImVec4(.65f,.70f,.64f,1);s.Colors[ImGuiCol_HeaderHovered]=ImVec4(.84f,.88f,.81f,1);s.Colors[ImGuiCol_HeaderActive]=ImVec4(.52f,.61f,.50f,1);s.Colors[ImGuiCol_CheckMark]=ImVec4(.12f,.30f,.14f,1);s.Colors[ImGuiCol_SliderGrab]=ImVec4(.28f,.43f,.26f,1);s.Colors[ImGuiCol_SliderGrabActive]=ImVec4(.14f,.30f,.12f,1);s.Colors[ImGuiCol_ScrollbarBg]=ImVec4(.14f,.18f,.15f,.3f);s.Colors[ImGuiCol_ScrollbarGrab]=ImVec4(.35f,.42f,.36f,1);}
}
