#pragma once
#include "physics.h"
#include <cstddef>

#pragma pack(push, 1)
namespace prism
{
	class steering_data_t // Size: 0x0050 mapped prefix
	{
	public:
		array_dyn_t<float> steps;
		char pad_0020[8];
		int32_t total_steps; //0x0028 (0x04)
		int32_t N00003996; //0x002C (0x04)
		array_dyn_t<float> model_steering_pos; //0x0030 (0x20)
	};
	static_assert(sizeof(steering_data_t) == 0x50);

	// Mapped prefix only: ETS2 1.61.1.9, supplied EXE 05126873bfae600294ce6dc4469a0edb8a06726a.
	// Do not infer the full actor allocation size from this partial declaration.
	class game_trailer_actor_u : public unit_t
	{
	public:
		char pad_0010[0x1F0];
		class vehicle_u* vehicle; // 0x0200
		char pad_0208[0x50];
		uint8_t suspension_dirty; // 0x0258: game marks this after changing height
		char pad_0259[0x277];
		float suspention_height; // 0x04D0: first axle group
		float suspension_height_other; // 0x04D4: other axle group
		char pad_04D8[0x1E0];
		float steering; // 0x06B8
		char pad_06BC[4];
		class steering_data_t* steering_data; // 0x06C0
		char pad_06C8[0x918];
		class physics_joint_physx_t* hook_joint; // 0x0FE0 (old 0x0FB8 + 0x28)
		char pad_0FE8[0xA0];
		game_trailer_actor_u* slave; // 0x1088
	};
	static_assert(sizeof(game_trailer_actor_u) == 0x1090);
	static_assert(offsetof(game_trailer_actor_u, vehicle) == 0x200);
	static_assert(offsetof(game_trailer_actor_u, suspension_dirty) == 0x258);
	static_assert(offsetof(game_trailer_actor_u, suspention_height) == 0x4D0);
	static_assert(offsetof(game_trailer_actor_u, suspension_height_other) == 0x4D4);
	static_assert(offsetof(game_trailer_actor_u, steering) == 0x6B8);
	static_assert(offsetof(game_trailer_actor_u, steering_data) == 0x6C0);
	static_assert(offsetof(game_trailer_actor_u, hook_joint) == 0xFE0);
	static_assert(offsetof(game_trailer_actor_u, slave) == 0x1088);
}
#pragma pack(pop)
