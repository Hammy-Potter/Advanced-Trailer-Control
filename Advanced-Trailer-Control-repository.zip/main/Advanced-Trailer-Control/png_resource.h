#pragma once
#ifdef _WIN32
#include <windows.h>
#include <wincodec.h>
#include <vector>
#include <cstdint>
namespace potter_png {
struct Image{UINT width=0,height=0;std::vector<uint8_t>rgba;};
inline Image load(HMODULE module,int id=211){
 Image out;HRSRC resource=FindResourceW(module,MAKEINTRESOURCEW(id),MAKEINTRESOURCEW(10));if(!resource)return out;
 DWORD bytes=SizeofResource(module,resource);auto data=(BYTE*)LockResource(LoadResource(module,resource));if(!data||!bytes)return out;
 HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
 if(FAILED(com)&&com!=RPC_E_CHANGED_MODE)return out;
 IWICImagingFactory*factory=nullptr;IWICStream*stream=nullptr;IWICBitmapDecoder*decoder=nullptr;IWICBitmapFrameDecode*frame=nullptr;IWICFormatConverter*convert=nullptr;
 HRESULT hr=CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&factory));
 if(SUCCEEDED(hr))hr=factory->CreateStream(&stream);
 if(SUCCEEDED(hr))hr=stream->InitializeFromMemory(data,bytes);
 if(SUCCEEDED(hr))hr=factory->CreateDecoderFromStream(stream,nullptr,WICDecodeMetadataCacheOnLoad,&decoder);
 if(SUCCEEDED(hr))hr=decoder->GetFrame(0,&frame);
 if(SUCCEEDED(hr))hr=frame->GetSize(&out.width,&out.height);
 if(SUCCEEDED(hr)&&(out.width>2048||out.height>2048||!out.width||!out.height))hr=E_FAIL;
 if(SUCCEEDED(hr))hr=factory->CreateFormatConverter(&convert);
 if(SUCCEEDED(hr))hr=convert->Initialize(frame,GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom);
 if(SUCCEEDED(hr)){out.rgba.resize(size_t(out.width)*out.height*4);hr=convert->CopyPixels(nullptr,out.width*4,UINT(out.rgba.size()),out.rgba.data());}
 if(FAILED(hr))out=Image{};
 if(convert)convert->Release();if(frame)frame->Release();if(decoder)decoder->Release();if(stream)stream->Release();if(factory)factory->Release();if(SUCCEEDED(com))CoUninitialize();return out;
}
}
#endif
