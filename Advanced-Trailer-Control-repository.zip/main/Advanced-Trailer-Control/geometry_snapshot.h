#pragma once
#include <cstdint>
#include <cmath>
#include <vector>
#include <cstring>
namespace atc_geometry {
struct Vec3 { float x,y,z; };
struct Array { uint64_t owner, pointer, count, capacity; };
struct Pose { float x,y,z; int16_t sector_x,sector_z; float q[4]; };
static_assert(sizeof(Array)==32 && sizeof(Pose)==32 && sizeof(Vec3)==12);
template<class T,class Reader>
bool array(Reader read,uintptr_t address,std::vector<T>& out,uint64_t limit=128) {
 out.clear();Array a{},again{};
 if(!read(address,&a,sizeof(a)) || a.count>limit || a.count>a.capacity
    || (a.count && (!a.pointer || a.count>SIZE_MAX/sizeof(T) || a.pointer>UINTPTR_MAX-a.count*sizeof(T))))return false;
 std::vector<T> temp(size_t(a.count));
 if(a.count && !read(uintptr_t(a.pointer),temp.data(),temp.size()*sizeof(T)))return false;
 if(!read(address,&again,sizeof(again)) || std::memcmp(&a,&again,sizeof(a)))return false;
 out.swap(temp);return true;
}
inline bool local(Vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&std::abs(v.x)<1000&&std::abs(v.y)<1000&&std::abs(v.z)<1000;}
inline bool pose(const Pose& p){
 if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z)||std::abs(p.x)>1000000||std::abs(p.y)>1000000||std::abs(p.z)>1000000)return false;
 float norm=0;for(float x:p.q){if(!std::isfinite(x))return false;norm+=x*x;}
 return norm>.95f&&norm<1.05f;
}
}
