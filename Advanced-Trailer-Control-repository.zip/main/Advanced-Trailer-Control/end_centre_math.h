#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>
#include <string>
namespace end_centre {
constexpr double rad=3.14159265358979323846/180.0;
struct Wheel { double x=0,z=0;size_t row=0; };
struct Module {std::vector<Wheel> wheels;double centre=0,limit=45*rad,max_error=0,lever=0;};
// Recover native Ackermann coordinates relative to the OLD centre. Absolute
// origin translation is unnecessary: this mode uses the connection-end axle.
inline bool recover(const std::vector<float>& samples,size_t rows,int steps,
 const std::vector<uint64_t>& mapping,double lever,bool reverse,Module& m,std::string& why){
 m=Module{};m.lever=lever;auto fail=[&](const char*reason){why=reason;return false;};
 if(steps<8||steps>512||rows<2||rows>128||mapping.size()<4||mapping.size()>128||mapping.size()%2
    ||!std::isfinite(lever)||std::abs(lever)<.1||std::abs(lever)>200)return fail("unsupported native table dimensions/reference length");
 const size_t stride=size_t(steps)*2+1;
 if(samples.size()!=rows*stride)return fail("native table sample count mismatch");
 const int k=std::min(15,(steps-1)/2);
 auto angle=[&](size_t row,int offset){return double(samples[row*stride+steps+offset])*rad*(reverse?-1:1);};
 const double R=lever/std::tan(k*rad);std::vector<Wheel> fitted(rows);std::vector<bool> zero(rows);
 double track_sum=0;size_t track_n=0;double native_max=0;
 for(size_t row=0;row<rows;++row){
  const double a=angle(row,k),b=angle(row,-k);
  if(!std::isfinite(a)||!std::isfinite(b)||std::abs(a)>85*rad||std::abs(b)>85*rad)return fail("nonfinite or excessive native angle");
  fitted[row].row=row;
  if(std::abs(a)<1e-6&&std::abs(b)<1e-6){zero[row]=true;continue;}
  if(std::abs(a)<1e-6||std::abs(b)<1e-6)return fail("asymmetric zero native samples");
  const double ca=1/std::tan(a),cb=1/std::tan(b),den=ca-cb;
  if(!std::isfinite(den)||std::abs(den)<1e-7)return fail("degenerate native angle samples");
  auto&w=fitted[row];w.z=2*R/den;w.x=-.5*w.z*(ca+cb);
  if(!std::isfinite(w.x)||!std::isfinite(w.z)||std::abs(w.x)>8||std::abs(w.z)>200)return fail("recovered position outside trailer bounds");
  track_sum+=std::abs(w.x);++track_n;
 }
 if(!track_n)return fail("all mapped native angles are zero");
 const double track=track_sum/track_n;
 if(track<.1||track>4)return fail("implausible recovered half-track");
 m.wheels.reserve(mapping.size());
 for(size_t i=0;i<mapping.size();++i){
  if(mapping[i]>=rows)return fail("fixed/unmapped wheels not supported in this trial");
  Wheel w=fitted[size_t(mapping[i])];
  // A wheel exactly on the old centre has zero angle at every radius. Its X
  // cannot be recovered from steering alone; infer side from other wheel pairs.
  if(zero[w.row]){bool side_found=false;for(size_t j=i%2;j<mapping.size();j+=2){
   if(mapping[j]<rows&&!zero[size_t(mapping[j])]){w.x=std::copysign(track,fitted[size_t(mapping[j])].x);side_found=true;break;}}
   if(!side_found)return fail("cannot establish side for an old-centre wheel");
  }
  m.wheels.push_back(w);
 }
 // Validate at DIFFERENT sample points, not the two used to fit the coordinates.
 // Tight tolerance deliberately rejects geometry which is not a native Ackermann table.
 for(const auto&w:m.wheels){
  for(int offset:{-k-2,-k/2,k/2,k+2}){
   if(!offset||std::abs(offset)>=steps)continue;
   const double radius=lever/std::tan(offset*rad);
   const double predicted=std::atan(w.z/(radius-w.x)),actual=angle(w.row,offset);
   if(!std::isfinite(actual))return fail("nonfinite validation sample");
   m.max_error=std::max(m.max_error,std::abs(predicted-actual));
   if(std::abs(predicted-actual)>.08*rad)return fail("recovered geometry does not reproduce native samples");
  }
  native_max=std::max(native_max,std::abs(angle(w.row,steps-1)));
 }
 const double first=(m.wheels[0].z+m.wheels[1].z)/2;
 const size_t n=m.wheels.size();const double last=(m.wheels[n-2].z+m.wheels[n-1].z)/2;
 if(std::abs(last-first)<.5)return fail("no usable longitudinal wheel span");
 const double direction=std::copysign(1.0,last-first);
 for(size_t i=0;i<n;i+=2){
  if(std::abs(m.wheels[i].z-m.wheels[i+1].z)>.03||m.wheels[i].x*m.wheels[i+1].x>=0)return fail("wheel mapping is not ordered left/right axle pairs");
  if(i&&direction*(m.wheels[i].z-m.wheels[i-2].z)<-.03)return fail("wheel pair order is not monotonic along chassis");
 }
 // A row shared by several wheels cannot represent different side angles.
 // Reject rather than overwrite it with whichever wheel happened to be last.
 for(size_t i=0;i<n;++i)for(size_t j=0;j<i;++j)if(m.wheels[i].row==m.wheels[j].row
   &&(std::abs(m.wheels[i].x-m.wheels[j].x)>.01||std::abs(m.wheels[i].z-m.wheels[j].z)>.01))return fail("steering row shared by incompatible wheels");
 m.limit=std::min(45*rad,native_max);
 if(m.limit<5*rad)return fail("insufficient native steering lock");
 why="native geometry fit validated";return true;
}
inline constexpr double centre_extension=0.7;
inline void relocate(Module& m,bool front,double extension=centre_extension){
 const auto n=m.wheels.size();
 const double first=(m.wheels[0].z+m.wheels[1].z)/2,last=(m.wheels[n-2].z+m.wheels[n-1].z)/2;
 const double direction=std::copysign(1.0,last-first);
 m.centre=front?last+direction*extension:first-direction*extension;
}
inline double maximum_curvature(const Module&a,const Module&b){
 double result=1;
 for(const Module*m:{&a,&b})for(const auto&w:m->wheels){
  const double t=std::tan(m->limit);
  result=std::min(result,t/(std::abs(w.z-m->centre)+std::abs(w.x)*t));
 }
 return result;
}
inline double wheel_angle(const Wheel&w,const Module&m,double curvature){
 return std::atan((w.z-m.centre)*curvature/(1-w.x*curvature));
}
}
