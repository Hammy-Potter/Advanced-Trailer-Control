#include "response_math.h"
#include <cassert>
#include <limits>
#include <vector>
#include <iostream>
using namespace response_math;
int main(){
 for(int hz:{20,30,60,144,240}) {
  float v=0,clock=0;const float dt=1.f/hz;
  for(int i=0;i<hz*10;++i){v=move(v,1,10,dt);clock+=dt;}
  assert(std::abs(v-1)<.0003f);
  for(int i=0;i<hz*20;++i)v=move(v,-1,10,dt);
  assert(std::abs(v+1)<.0003f);
  float height=1;for(int i=0;i<hz*5;++i)height+=suspension_delta(true,false,5,dt);
  assert(std::abs(height-2)<.001f);
 }
 assert(move(.25f,1,10,2)==.25f);assert(suspension_delta(true,true,2,.02f)==0);
 assert(suspension_delta(false,false,2,.02f)==0);
 assert(elapsed_step(std::numeric_limits<float>::quiet_NaN())==0);
 // Opposing original row directions, differing locks, one fixed row, and a +/- pair.
 const int half=3;const int stride=7;std::vector<float> table(4*stride,0);
 table[1]=-55;table[5]=55;table[8]=45;table[12]=-45;
 table[22]=-35;table[26]=35;
 bool flags[40]{};float lock=0;
 assert(crab_limits(table.data(),table.size(),4,half,flags,lock));
 assert(flags[0]&&flags[1]&&!flags[2]&&flags[3]);
 assert(std::abs(lock-35*.017453292519943295f)<1e-6f);
 float out[]={-.4f,.3f,0,-.2f};parallel_angles(out,flags,4,.25f);
 assert(out[0]==.25f&&out[1]==.25f&&out[2]==0&&out[3]==.25f);
 parallel_angles(out,flags,4,-.25f);assert(out[0]==-.25f&&out[1]==-.25f&&out[2]==0);
 parallel_angles(out,flags,4,0);for(auto value:out)assert(value==0);
 assert(!crab_limits(table.data(),3,4,half,flags,lock));
 table[3]=1;assert(!crab_limits(table.data(),table.size(),4,half,flags,lock));
 std::cout<<"PASS: timing at 20/30/60/144/240 Hz, lock-to-lock, pause, suspension, crab directions/limits/fixed rows and malformed tables\n";
}
