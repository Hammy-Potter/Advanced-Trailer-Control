#include "response_math.h"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace response_math;
int main() {
 for (float seconds : {2.f, 5.f, 10.f}) for (int hz : {20,30,60,144,240}) {
  const float dt=1.f/hz; const int frames=int(seconds*hz);
  float steering=0, suspension=1;
  for(int i=0;i<frames;++i){steering=move(steering,1,seconds,dt);suspension+=suspension_delta(true,false,seconds,dt);}
  assert(std::abs(steering-1)<.0005f);assert(std::abs(suspension-2)<.001f);
  for(int i=0;i<frames;++i){steering=move(steering,0,seconds,dt);suspension=move(suspension,1,seconds,dt);}
  assert(std::abs(steering)<.0005f);assert(std::abs(suspension-1)<.001f);
  float lower=1;for(int i=0;i<frames;++i)lower+=suspension_delta(false,true,seconds,dt);
  assert(std::abs(lower)<.001f); // unconstrained rate; actor write clamps actual height to .25
 }
 assert(move(1,2,5,.1f)>1 && move(1,2,5,.1f)<1.1f);
 assert(move(1,2,5,1)==1); // stalls do not consume travel time
 float front=.5f,rear=2.f;
 for(int i=0;i<300;++i){front=move(front,1,5,1.f/60);rear=move(rear,1,5,1.f/60);}
 assert(std::abs(front-1)<.0005f&&std::abs(rear-1)<.0005f);
 std::cout<<"PASS: shared outward/return rates at 2/5/10 seconds, 20-240 Hz, height targets, unequal axle groups and stall handling\n";
}
