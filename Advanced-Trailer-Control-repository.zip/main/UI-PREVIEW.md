# Trailer Control — UI preview, 20 October 2026

Working name: Trailer Control. Dark slate/amber appearance, Control panel / Inputs & response / About navigation. Default 740x780 resizable window, minimum 620x420. All-trailer suspension controls at the top; individual steering and height cards below with readable Auto/Manual states. Advanced diagnostics and joint control are tucked away. Fixed axles retain suspension controls while steering widgets are disabled. Inputs use the new theme and existing saved settings. DLL/JSON filenames remain compatible with the working build.

Added mouse controls for Lower all, Raise all (hold), and Ride height (press). These use the same height fields, limits and smooth reset queue as the keybind feature. Only free/locked joints can be toggled; unsupported joint modes are disabled.

The steering hook, keybind processing and suspension update loop were compared byte-for-byte with the user-confirmed TEST 4 source and remain unchanged. The actual ImGui theme and trailer panel compiled and rendered headlessly using the bundled ImGui library with simulated two-trailer data; the separate PNG shows this render, not a running game. Visual layout inspected at the default size. The complete Windows DLL has not been built or tested here.

Build Release/x64 in Visual Studio 2022, retain the JSON, and keep the working DLL as a rollback. Verify mouse controls, bindings, smooth returns, fixed-axle cards, window resizing, and the joint controls if used.


