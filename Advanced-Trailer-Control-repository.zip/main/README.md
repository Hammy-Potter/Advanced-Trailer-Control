# Advanced Trailer Control 1.0.0

Build Release/x64 using Advanced-Trailer-Control.sln, or CMake with MINHOOK_SOURCE_DIR pointing to vendor/minhook. See the release package README-FIRST.txt for current installation, modes and limitations. Original and dependency notices are retained.
