# Advanced Trailer Control — MWT Test 5

Experimental ETS2 1.61.1.9 Windows x64 build for the supplied three-section MWT combination.

## Change from Test 4

The user reports that Test 4 tracks much better, but axle steering appears notchy. Its capture confirms wheel/model target agreement. Movement estimates update every 100 ms, and Test 4 applied the resulting new axle command immediately. This is a plausible source of visible steps; the capture is not a frame-by-frame visual measurement.

Test 5 eases the final combined axle command every steering advance, including both the movement-following component and native articulation correction. It uses a frame-rate independent 0.06-second exponential response and a 45-degrees/second maximum change. A stalled frame can consume at most 50 ms of smoothing time. Repeated setter calls at the same clock tick cannot advance the smoothing twice.

Each axle's left and right targets remain identical. After native model advance, wheel output remains equal to that model's measured steering angle, retaining the alignment improvement from Test 4. All seven axles retain independent following angles. Initialisation and invalid/expired history start from the measured axle-model angles rather than inventing a centred position.

The movement estimation still runs at 10 Hz. No additional pose reads are required for the frame smoothing. Test 4's cached profile checks and reduced diagnostic output are retained. The new filter adds a small response delay; in-game tracking and the amount of smoothing need checking.

No mode labels, controls, module target ratio, manual/hold/Auto behaviour, steering tables, suspension animations or joint limits have been changed. Earlier test documents are historical; this file describes the current DLL.

## Install and test

Close ETS2 and back up the Test 4 DLL. Replace Advanced-Trailer-Control.dll in bin/win_x64/plugins with this package's DLL. Keep only one ATC DLL installed, then enable MWT Mode - Experimental with the same polarity setting as before.

Crawl forwards through short left/right turns and straighten, initially without starting a capture. Check whether axle motion looks smoother, wheels remain aligned, and the rear still responds promptly enough. Briefly check Trailer 3 manual steering, release-to-hold and Auto. Then capture a manoeuvre if further diagnosis is needed.

No EXE program, remote add-on, model edits or def changes are required.

## Local validation

Windows x64 Release cross-build passed. Tests cover per-frame rate limits, paired outputs, same-tick safety, steady convergence, stall/clock reset, invalid-input rejection and the actual pre/post wheel writer. An artificial 10 Hz stepped target sampled at 16 ms frames had a largest output step of 0.720 degrees. This tests the smoothing maths, not the game's rendered frames.

The existing 183-sample captured turn-in replay still passes the target-direction and angle-bound checks. That replay does not simulate feedback from this newly smoothed steering into vehicle motion. No in-game smoothness or handling result is claimed before the driving test.
