# Advanced Trailer Control — Test 8: powered reverse joint

Experimental Windows x64 build for the supplied ETS2 1.61.1.9 executable. Applies to MWT Mode, Bridge Mode and Bridge Mode - Expert. This replaces Test 7's rigid reverse lock with a moving-target spring drive.

## Intended behaviour

While reversing, the rear joint remains in its original free or limited state. A twist/yaw spring drive resists unwanted movement and follows a changing angle target. The feature does not lock/unlock the joint during steering and does not change either local joint frame, anchor, articulation limit or suspension axis.

On activation the drive goal starts at the current joint angle. Auto then moves that goal gradually towards the existing front-derived articulation target. Manual steering moves the goal directly without releasing the spring drive. Releasing manual input captures the rear module's actual current articulation for hold; Auto resumes front-derived targeting. Forward movement restores the original drive parameters, goal and velocity when the same joint and owned settings are still accessible. Mode changes and shutdown also attempt restoration.

Goal movement is limited by the existing steering-time setting: 60 degrees divided by that setting per second, with a maximum 50 ms advance consumed after a stalled frame. World articulation targets are bounded to +/-75 degrees and joint-twist goals to +/-80 degrees, while the original physical joint limits remain in effect. Repeated calls at the same tick cannot advance the goal twice.

MWT retains seven separate axle-following calculations, wheel/model alignment and smoothing. Both bridge modes retain native wheel calculations while the rear joint drive is active. There is no extra reverse mode or checkbox. The alphabetical mode order, removed reverse-correction checkbox and Info-tab text changes from Test 7 are retained.

## Initial tuning

The experimental twist drive uses acceleration-mode spring stiffness 64, damping 16 and a finite force/impulse limit of 1,000,000. The interpretation of the limit depends on the joint's existing PhysX constraint flags; this build does not change those flags. These are initial test values, not verified hydraulic characteristics. The drive can yield or lag under load and is not an absolute angle lock.

Only the twist drive is changed. Original drive target translation and swing orientation are preserved. Original linear and non-twist angular target velocities are preserved; twist target velocity is set to zero while positional following is active. Existing swing/SLERP drives cause refusal rather than being silently replaced. An already locked yaw axis is not unlocked.

## Native interface checks

Exact EXE metadata, D6 vtable and method addresses must match the supplied executable. Drive setter/getter slots 40/41, position setter/getter 42/43 and velocity setter/getter 44/45 were inspected in that executable, including the 16-byte drive, 28-byte transform and six-float velocity layouts and Windows x64 calling conventions.

The joint's two PhysX actors must match the tower/bridge and rear module's native body pointers. Their order and the joint's near-vertical local twist axis determine the sign mapping between world articulation and joint twist. Invalid/mismatched actors, axes, poses or drive settings decline activation. Diagnostics report 'Powered joint unavailable' and capture native joint/drive information.

API references used alongside executable inspection:
- https://nvidiagameworks.github.io/PhysX/3.4/PhysXAPI/files/classPxD6Joint.html
- https://nvidiagameworks.github.io/PhysX/3.4/PhysXAPI/files/classPxD6JointDrive.html

## Install and first test

1. Close ETS2 completely and back up your working DLL (Test 5 is the last build you reported as working well).
2. Replace Advanced-Trailer-Control.dll in bin/win_x64/plugins. Keep only one ATC DLL installed.
3. Select the appropriate existing mode: MWT, Bridge or Bridge - Expert.
4. Start at a modest articulation and reverse gently. Diagnostics should show 'Reverse powered joint' and a moving target angle.
5. Briefly steer manually while reversing: the target should change while the drive stays engaged. Release and check hold, then select Auto. Finally drive forwards and check that normal behaviour returns.
6. Repeat with the other relevant combinations. Capture geometry/log details if the joint is unavailable, yields too much, oscillates, or the steering direction is wrong. A close-up clip is helpful.

No EXE program, remote add-on, model edits or def changes are required. If the combination is pulled unexpectedly, stop and disable the selected mode. This is the first powered-joint physics test, so begin with short crawling manoeuvres.

## Validation and limits

Windows x64 Release cross-build passed. New tests cover current-angle seeding, finite drive settings, target slew limits, continuous drive during manual steering, hold and Auto, same-tick behaviour, unchanged free/limited motion, preservation/restoration of original drive goals/velocities, rejected writes and stale-identity guards. Both actual bridge controller fixtures exercise reverse drive activation, manual target changes and forward restoration. MWT, writer/alignment, smoothing, hook ordering and BBM regressions passed.

These tests use mocked game functions for runtime operations. They do not prove the real joint's force response, solver stability, loaded handling or wheel tracking. Physical spring strength, damping and force cap require in-game testing. The existing signed-movement detector has a short detection delay and cannot infer reverse intent before the trailer moves.

Earlier test notes and rigid-lock tests retained in the source are historical. The active reverse controller in this DLL uses powered_joint.h, not Test 7's lock/rebase routine. Source and third-party notices remain included.
