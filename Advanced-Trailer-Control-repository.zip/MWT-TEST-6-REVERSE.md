# Advanced Trailer Control — Test 6: automatic reversing

Experimental Windows x64 build for the supplied ETS2 1.61.1.9 layout. Reversing changes apply to MWT Mode, Bridge Mode and Bridge Mode - Expert. There is no additional reversing mode or switch.

## Changed

All three modes estimate signed movement from the rear module's existing world-pose readings. Native actor forward is -Z. Forward and reverse must be confirmed by two movement samples above 0.06 m/s; stopped/noisy readings do not repeatedly change the detected direction. The automatic articulation feedback is blended towards the appropriate sign for that direction, with reduced authority near a stop. Opposite movement clears the previous correction polarity before the new sign is blended in.

The desired articulation remains the same: opposite the front section's articulation relative to the bridge/tower, at the existing 0.6 ratio, or the manually captured articulation while in hold. Only the automatic steering correction changes with movement direction. Active manual steering commands are not inverted on changing direction.

MWT's per-axle movement following now also accepts reverse travel. The calculation chooses an equivalent wheel line rather than requesting a 180-degree wheel turn. Backward following starts when a reference point's longitudinal movement reaches 0.08 m/s; the existing 0.3 m/s forward threshold is retained. Individual points below their threshold fade their following towards zero. Existing 25-degree movement limits, 50-degree combined axle limits, rigid wheel/axle alignment and Test 5's per-frame smoothing remain.

Both bridge modes retain native axle steering geometry; MWT's seven-axle movement follower is not applied to other trailers. BBM and Multi-Module controls have not been given new reverse behaviour in this test.

Manual control behaviour is unchanged: release still captures/holds the rear-module articulation; Auto resumes front-derived following. This build does not implement the deferred request to change manual mode persistence or hold the wheel lock instead.

## Install and test

1. Close ETS2 and back up the Test 5 DLL.
2. Replace Advanced-Trailer-Control.dll in bin/win_x64/plugins. Keep only one ATC DLL installed.
3. Choose the existing mode appropriate to the combination, keeping the previous correction-polarity setting. There is no new reverse checkbox.
4. Start straight, stop and reverse gently. Then try a modest articulation, stop and reverse again. Check the transition back to forward travel too.
5. Repeat with MWT Mode, Bridge Mode and Bridge Mode - Expert. Check manual steer, release-to-hold and Auto as before.
6. First drive without a capture. If it still kicks out, capture a short forward/stop/reverse transition and send game.log.txt with a short clip if possible. Diagnostics now show travel direction, signed speed and correction gain.

No model/def changes, remote add-on or EXE program are required.

## Validation and limits

Windows x64 Release cross-build passed. Actual controller fixtures verify reverse feedback polarity for MWT and both bridge modes, while retaining manual command polarity, release-to-hold and Auto. The real reverse capture replay contains 80 rear poses; all 25 samples in the checked reverse interval detect reverse and accept reverse wheel following, and eight later samples detect resumed forward travel.

Math tests cover equivalent wheel headings when rolling backwards, stationary noise/hysteresis, sector/clock/pose resets and the unchanged default forward-only path used by BBM. Existing MWT writer/alignment, smoothing, hook-pipeline, BBM and geometry-capture regressions passed.

Replay is not a vehicle-physics simulation. No in-game success is claimed before testing this DLL. Reverse combinations can still jackknife, and smoothing/steering-response delay or insufficient wheel grip can prevent exact articulation tracking. Test at crawling speed first; these changes are not validated for high-speed reverse travel. Motion confidence is deliberately low at a stop and immediately after a direction change.

Earlier test notes in the source archive are historical; this document describes the current DLL.
