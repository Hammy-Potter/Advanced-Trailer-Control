ADVANCED TRAILER CONTROL — ST7 TRACKING FIX TEST 1
Private test build for ETS2 1.61.1.9 / Windows x64 / DirectX 11.

INSTALL
Close the game. Back up the existing DLL, then replace:
Euro Truck Simulator 2/bin/win_x64/plugins/Advanced-Trailer-Control.dll
Keep your JSON settings and bindings. Do not load two copies of the plugin.

TEST
Use BBM Mode and the same ST7 combination from the report. Select Auto for its steering. Drive the same roundabout and exit, then continue straight. Check both turning directions and manual steering/Auto.

If the bogie still swings or tracks sideways, use Settings > Diagnostics > Capture geometry / log details just before reproducing it and send the new game.log.txt and a short clip.

CHANGE
ST7 only: retain the main 60-degree bogie steering command and calculate per-wheel differences relative to the bogie's centre path. Ignore apparent wheel displacement caused solely by changes to the native driven steering animation. Existing filtering, bounds, identity checks and forward-only operation remain.
ST3/ST4, MWT and both bridge modes retain their existing steering calculations.

VALIDATION
Windows x64 DLL builds. Eight focused automated checks pass. Replayed 183 samples from the supplied report: correction magnitude peaked at 19.23 degrees instead of 24.99 degrees; wheel readings above 24 degrees fell from 251 to zero. This demonstrates reduced saturation on recorded movement, not an in-game proof of the fix. New tests cover animation-only yaw changes and mirrored turns.

No GitHub release has been changed. Please confirm in-game handling before public distribution.
