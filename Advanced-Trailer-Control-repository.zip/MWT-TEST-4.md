# Advanced Trailer Control — MWT Test 4

Experimental Windows x64 DLL for the supplied ETS2 1.61.1.9 three-section MWT jeep / tower / seven-axle rear-bogie combination.

## Why another change was needed

The Test 3 capture confirms its post-advance writer ran, model angles matched their targets, and zero was written to the steering output. Despite that, the user still observed wheels steering separately from their axle models. The assumption that this output was an axle-relative residual was not valid for the observed behaviour.

Inspection of the supplied game executable confirms the wheel-angle getter at RVA 0x85C380 reads the mapped steering output directly. Wheel-transform routines, including the path around RVA 0x879A39..0x879ABD, build a separate steering quaternion from that value. Simply zeroing the output is therefore not a reliable way to align the wheels with a steered axle model.

Test 4 keeps each pair's final wheel steering output equal to that axle model's measured common steering angle. It does not subtract the model angle and does not zero the output. Pre-advance targets remain one shared angle per rigid axle; the seven axle groups retain their independent movement-based following. Model/target agreement is still validated before writing.

No new wheel getter hook is installed. No axle-model pose, suspension animation, joint limit or steering table is rewritten. The module target ratio, movement filter, manual override and release/hold/Auto behaviour remain as in Test 3.

## Performance changes

- Full MWT table fingerprints are cached for up to 500 ms per thread, instead of being copied and checked several times each frame. Chain identity, steering-data identity and native array headers are still checked on every use. Header/pointer changes invalidate the cache immediately; payload changes are revalidated at the next full check.
- Seven-axle diagnostic captures sample at 250 ms intervals rather than 100 ms, and omit the redundant per-group derivative log line. Raw chassis and seven model poses remain available for analysis.
- The actual movement-following controller still samples at 100 ms. Its responsiveness has not been intentionally reduced.
- Other single-bogie captures retain the previous 100 ms cadence. Routine logging remains quiet outside the requested capture window.

The reported lag is not proven to originate from logging or profile checks. The supplied trace intervals were 109–141 ms with no interval over 200 ms; that is not an FPS measurement. These changes reduce avoidable diagnostic/controller overhead but do not claim a measured FPS improvement.

## Install and test

1. Close ETS2, back up the working DLL and replace Advanced-Trailer-Control.dll in bin/win_x64/plugins. Keep only one ATC DLL installed.
2. Enable MWT Mode - Experimental, retaining your previous correction polarity.
3. First drive gently forwards through short left/right turns without starting a capture. Watch whether wheels now keep the same angle as their axle models, and whether the lag remains.
4. Then use Diagnostics > Capture geometry / log details for a short turn and straightening. Send game.log.txt with your observations. A close-up clip is especially useful if the wheels still appear to pivot separately.
5. Briefly test Trailer 3 manual steer, release-to-hold and Auto as before.

No model/def changes, EXE program or remote add-on are needed. Earlier test notes included in the source are historical; this document describes the current DLL.

## Validation and limits

Windows x64 Release cross-build and local regression tests passed. Tests cover equal left/right targets, final outputs equal to each axle model's common angle, target/model agreement guards, actual pre/post writer stages, movement-history retention, unchanged turn-in replay, profile-cache reuse, seven-group capture throttling, old bridge modes, BBM profiles, hook ordering and quiet logging.

These tests exercise code and mocked game functions, not in-game rendering or physics. The corrected angle convention and reported lag still need the driving test above. Movement-derived following remains an approximation; tyre contact/slip and high-speed/reverse behaviour are not validated.
