# Advanced Trailer Control — MWT Test 3

Experimental Windows x64 build for the supplied ETS2 1.61.1.9 MWT jeep / tower / seven-axle rear-bogie combination.

## Fix from Test 2

Test 2 used separate left/right wheel targets and then wrote a wheel-local residual after native axle-model advance. The user reported that axle following improved, but the wheels visibly pivoted relative to their axle models.

Test 3 treats each separate axle model as one rigid steering unit:

- Calculate both wheel-reference movement angles and retain the existing articulation-control correction.
- Average the two targets for each axle, then supply the same angle to both native steering rows before the axle model advances.
- Once native advance has produced the matching axle-model rotation, write zero additional wheel-local steering for both wheels.
- Keep seven independent axle angles. Do not force the seven axle models to one common angle.

The post-advance writer validates that the actual model rotation matches the shared target within 0.1 degree. Invalid poses, changed mappings/buffers, an unmatched model profile or an unexpected angle decline the new wheel write. Existing bounded movement sampling and fallback behaviour remain.

No axle-model poses, suspension animation, joint limits or steering tables are rewritten. Rear-module target ratio, manual override, release-to-hold and Auto remain as in Test 2. Changes are limited to MWT Mode.

## Install and test

1. Close ETS2 and back up the working DLL.
2. Replace Advanced-Trailer-Control.dll in bin/win_x64/plugins with this package's DLL. Keep only one ATC DLL installed.
3. Enable MWT Mode - Experimental, retaining the correction-polarity setting used in your previous drive.
4. Crawl forwards through a short left turn, straighten, then repeat right. Watch whether each wheel stays aligned with its axle model during the outward swing and return.
5. Briefly test Trailer 3 manual steering, release-to-hold and Auto.
6. Capture Diagnostics > Capture geometry / log details before a manoeuvre and send game.log.txt with your observations. A close-up clip is helpful if the wheels still pivot separately.

No EXE, remote add-on, model edits or def changes are required.

## Validation and limits

The Windows x64 Release build and local regression checks passed. Actual writer tests verify equal left/right pre-advance targets and zero post-advance wheel-local outputs for all seven groups, as well as guards, stage ordering and retained motion history. The original 183-sample capture replay still produces turn-in countersteering; combined axle targets were approximately -15.9 to +17.2 degrees.

Local tests use mocked native advance to exercise the writer. They do not prove the game's visual/physics behaviour. An in-game driving test is still required, especially whether the wheels now stay with the axle models.

Movement following remains a filtered, forward-only approximation from chassis movement and model-derived reference positions. It does not measure independent tyre contact or slip. Following fades near a stop or in reverse, and resets on invalid history. Limits remain +/-25 degrees for movement following and +/-50 degrees for the combined axle target.

Diagnostic logging remains quiet outside requested capture windows; successful Test 3 wheel records include wheel-local=ZERO. The included Test 1/Test 2 documents are historical; this document describes the current DLL.
